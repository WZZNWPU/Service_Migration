import argparse
import random

import numpy as np
from matplotlib import pyplot as plt
from torch import nn, autograd
import torch
import torch.nn.functional as F
from torch.nn import init
from torch.optim.lr_scheduler import ExponentialLR
from torch.utils.data import DataLoader, IterableDataset, SubsetRandomSampler, BatchSampler
from tqdm import tqdm
import torch_geometric.nn as geo_nn
from collections import deque
from torch_geometric.data import Data, Batch

from imitation_learning.PPO_test import PPO
from imitation_learning.run_PPO import train_on_policy_agent


# 定义图神经网络模块
class GraphNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, device):
        super(GraphNetwork, self).__init__()

        self.conv1 = geo_nn.GCNConv(input_dim, hidden_dim).to(device)
        self.relu = nn.LeakyReLU().to(device)
        self.conv2 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv3 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        # self.conv4 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv5 = geo_nn.GCNConv(128, output_dim).to(device)
        self.init_parameters()

    def init_parameters(self):
        # Xavier初始化conv1的权重和偏置
        init.orthogonal_(self.conv1.lin.weight)
        init.zeros_(self.conv1.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv2.lin.weight)
        init.zeros_(self.conv2.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv3.lin.weight)
        init.zeros_(self.conv3.bias)
        #
        # # Xavier初始化conv2的权重和偏置
        # init.xavier_uniform_(self.conv4.lin.weight)
        # init.zeros_(self.conv4.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv5.lin.weight)
        init.zeros_(self.conv5.bias)

    def forward(self, x, edge_index, edge_attr):
        residual = x  # 保存原始输入作为残差连接
        x = self.conv1(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv2(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv3(x, edge_index, edge_attr)
        x = self.relu(x)
        # x = self.conv4(x, edge_index, edge_attr)
        # x = self.relu(x)
        x = self.conv5(x, edge_index, edge_attr)
        x += residual  # 添加残差连接
        return x


class Discriminator(nn.Module):
    def __init__(self, en_graph_dim, user_information_dim, state_dim, action_dim, device):
        super(Discriminator, self).__init__()
        # 对状态信息进行特征提取
        self.gcn = GraphNetwork(en_graph_dim, hidden_dim=128, output_dim=5, device=device)  # 采用图卷积提取边缘节点的特征

        # self.feature_extractor = nn.Sequential(  # 采用全连接神经网络提取用户的信息特征
        #     nn.Linear(user_information_dim, 128).to(device),
        #     nn.LeakyReLU(),
        #     nn.Linear(128, 4).to(device)
        # )
        #
        self.feature_extractor2 = nn.Sequential(  # 采用全连接神经网络提取图卷积后的信息特征
            nn.Linear(25 * 5, 256).to(device),
            nn.LeakyReLU(),
            nn.Linear(256, 128).to(device),
            nn.LeakyReLU(),
            nn.Linear(128, 64).to(device),
            nn.LeakyReLU(),
            nn.Linear(64, 32).to(device),
        )

        self.fc1 = torch.nn.Linear(32 + 8 + action_dim, 128)
        self.fc2 = torch.nn.Linear(128, 128)
        self.fc3 = torch.nn.Linear(128, 128)
        # self.fc4 = torch.nn.Linear(128, 128)
        # self.fc4 = torch.nn.Linear(256, 256)
        # self.fc5 = torch.nn.Linear(256, 256)
        # self.fc6 = torch.nn.Linear(256, 256)
        # self.fc7 = torch.nn.Linear(256, 256)
        self.fc8 = torch.nn.Linear(128,1)

        # 初始化参数
        self.init_parameters()

    def init_parameters(self):
        def init_weights(m):
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

        self.apply(init_weights)

    def forward(self, x, a):
        graph_data, user_information = x[0], x[1]
        nodes_ferature, edge_index, edge_attr = graph_data.x, graph_data.edge_index, graph_data.edge_attr
        batchsize = int(nodes_ferature.shape[0] / 25)
        # print(f'nodes_ferature-->{nodes_ferature}')
        # print(f'edge_index-->{edge_index}')
        # print(f'edge_attr-->{edge_attr}')
        # print(f'batchsize-->{batchsize}')

        output1 = self.gcn(nodes_ferature, edge_index, edge_attr)  # output1-->torch.Size([25, 64])
        # print(f'output1-->{output1.shape}')
        # output2 = self.feature_extractor(user_information)  # output2-->torch.Size([64])

        # 将特征图展品 3300*16--->52800
        output6 = output1.clone().view(batchsize, -1)
        # print(f'output6-->{output6.shape}')
        # output3 = output6.clone().view(batchsize,-1)  # output1-->torch.Size([1600])
        output3 = output6.clone()  # output1-->torch.Size([1600])

        # 对展平后的向量提取特征
        output4 = self.feature_extractor2(output3.clone())
        # print(f'output4-->{output4.shape}')
        # print(f'output2-->{output2.shape}')
        # 进行向量拼接 (192,)
        # output5 = torch.cat((output3, output2), dim=-1)  # 特征融合后的状态信息 torch.Size([192])
        output5 = torch.cat((output4, user_information), dim=-1)  # 特征融合后的状态信息 torch.Size([192])
        # print(f'output5-->{output5.shape}')
        # print(output5.shape)
        # print(a.shape)
        # breakpoint()
        cat = torch.cat([output5, a], dim=1)

        x = F.leaky_relu(self.fc1(cat))  # ReLU激活函数
        x = F.leaky_relu(self.fc2(x))
        x = F.leaky_relu(self.fc3(x))
        # x = F.relu(self.fc4(x))
        # x = F.relu(self.fc5(x))
        # x = F.relu(self.fc6(x))
        # x = F.relu(self.fc7(x))
        return torch.sigmoid(self.fc8(x))


class RandomBatchIterableDataset(IterableDataset):
    def __init__(self, data, batch_size):
        self.data = data
        self.batch_size = batch_size

    def __iter__(self):
        while True:
            indices = np.random.choice(len(self.data), self.batch_size, replace=len(self.data) < self.batch_size)
            batch = [self.data[i] for i in indices]
            yield batch


class GAIL:
    def __init__(self, agent, args, device):
        self.discriminator = Discriminator(args.en_graph_dim, args.user_information_dim, args.state_dim, args.action_dim,
                                           device).to(device)
        self.discriminator_optimizer = torch.optim.Adam(self.discriminator.parameters(), lr=args.discriminator_lr, )
        self.agent = agent
        self.device = device
        self.disc_scheduler = ExponentialLR(self.discriminator_optimizer, gamma=0.98)

    # def learn(self, expert_s_user, expert_s_graph, expert_s_en_bw, expert_a, expert_s_edge_indexs,
    #           agent_s_user, agent_s_graph, agent_s_en_bw, agent_a,
    #           next_s_user,next_s_graph,next_s_en_bw, dones):
    def learn(self, expert_s_user, expert_s_graph, expert_s_en_bw, expert_a, expert_s_edge_indexs,
              replay_buffer,count_special):
        expert_states_user = torch.tensor(expert_s_user, dtype=torch.float).to(self.device)
        expert_states_graph = torch.tensor(expert_s_graph, dtype=torch.float).to(self.device)
        expert_states_en_bw = torch.tensor(expert_s_en_bw, dtype=torch.float).to(self.device)
        expert_actions = torch.tensor(expert_a, dtype=torch.int64).to(self.device)

        state_user, state_graph, state_en_bw, action, action_logprob, reward, next_state_user, next_state_graph, next_state_en_bw, dw, done, mask, edge_index = replay_buffer.numpy_to_tensor()  # Get training data
        agent_states_user = state_user
        agent_states_graph = state_graph
        agent_states_en_bw = state_en_bw
        # print(expert_s_edge_indexs[0])
        # breakpoint()
        edge_index = torch.tensor(expert_s_edge_indexs[0], dtype=torch.long).to(self.device)  # torch.Size([114, 2])
        edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([2, 114])
        agent_actions = action.squeeze()

        expert_actions = F.one_hot(expert_actions, num_classes=26).float()
        agent_actions = F.one_hot(agent_actions, num_classes=26).float()

        states_graph_data_list = []
        for state_id in range(expert_states_user.shape[0]):
            # edge_nodes_feature = torch.tensor(data=expert_states_graph[state_id], dtype=torch.float).to(
            # self.device)  # torch.Size([25, 5])
            edge_nodes_feature = expert_states_graph[state_id].clone().detach().to(torch.float).to(self.device)

            edge_attr = expert_states_en_bw[state_id].clone().detach().to(torch.float).to(self.device)

            # edge_attr = torch.tensor(expert_states_en_bw[state_id], dtype=torch.float).to(self.device)  # 边权重,带宽

            en_graph_data = Data(x=edge_nodes_feature, edge_index=edge_index_,
                                 edge_attr=edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
            en_graph_data = en_graph_data.to(self.device)
            states_graph_data_list.append(en_graph_data)
        # expert_states_batch = Batch.from_data_list(states_graph_data_list)
        # expert_states = [expert_states_batch, expert_states_user]

        agent_states_graph_data_list = []
        for state_id in range(agent_states_user.shape[0]):
            agent_edge_nodes_feature = agent_states_graph[state_id].clone().detach().to(torch.float).to(self.device)

            agent_edge_attr = agent_states_en_bw[state_id].clone().detach().to(torch.float).to(self.device)
            # agent_edge_nodes_feature = torch.tensor(data=agent_states_graph[state_id], dtype=torch.float).to(
            #     self.device)  # torch.Size([25, 5])

            # agent_edge_attr = torch.tensor(agent_states_en_bw[state_id], dtype=torch.float).to(self.device)  # 边权重,带宽

            agent_en_graph_data = Data(x=agent_edge_nodes_feature, edge_index=edge_index_,
                                       edge_attr=agent_edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
            agent_en_graph_data = agent_en_graph_data.to(self.device)
            agent_states_graph_data_list.append(agent_en_graph_data)
        agent_states_batch = Batch.from_data_list(agent_states_graph_data_list)
        agent_states = [agent_states_batch, agent_states_user]

        # # 设置所需的小批量大小
        # self.mini_batch_size = 2048

        # # 创建智能体数据集的随机采样器和批量采样器
        # agent_sampler = SubsetRandomSampler(range(agent_states_user.shape[0]))
        # agent_batch_sampler = BatchSampler(agent_sampler, self.mini_batch_size, drop_last=False)
        #
        # # 创建专家数据集的随机采样器和批量采样器
        # expert_sampler = SubsetRandomSampler(range(agent_states_user.shape[0]))
        # expert_batch_sampler = BatchSampler(expert_sampler, self.mini_batch_size, drop_last=False)
        #
        # # 在训练过程中同时使用智能体数据和专家数据
        # for agent_batch_index, expert_batch_index in zip(agent_batch_sampler, expert_batch_sampler):
        # expert_state_batch = Batch.from_data_list(expert_states_batch[expert_batch_index])
        # expert_state = [expert_state_batch, expert_states_user[expert_batch_index]]
        #
        # agent_state_batch = Batch.from_data_list(agent_states_batch[agent_batch_index])
        # agent_state = [agent_state_batch, agent_states_user[agent_batch_index]]
        if count_special > 80:
            update_times1 = 2
        else:
            update_times1 = 2
        for _ in range(update_times1): # 默认更新次数是判别器2，生成器1
            # 使用标签平滑的二进制交叉熵损失
            random_index = random.sample(range(expert_states_user.shape[0]), 256)
            print(f"索引：{random_index}")
            filtered_states_graph_data_list = [data for i, data in enumerate(states_graph_data_list) if i in random_index]
            expert_states_batch = Batch.from_data_list(filtered_states_graph_data_list)
            expert_states = [expert_states_batch, expert_states_user[random_index]]
            expert_prob = self.discriminator(expert_states, expert_actions[random_index])
            agent_prob = self.discriminator(agent_states, agent_actions)
            print(f"判别器概率：{torch.mean(agent_prob)}")

            # self.discriminator_optimizer.zero_grad(set_to_none=True)
            # # expert_loss =  F.binary_cross_entropy_with_logits(expert_prob, torch.ones_like(expert_prob))  # Loss on "real" (expert) data
            # expert_loss =  F.binary_cross_entropy_with_logits(expert_prob, torch.zeros_like(expert_prob))  # Loss on "real" (expert) data
            # autograd.backward(expert_loss, create_graph=True)
            # r1_reg = 0
            # for param in self.discriminator.parameters():
            #     if param.grad is not None:
            #         r1_reg += param.grad.norm()  # R1 gradient penalty
            #
            # # policy_loss = F.binary_cross_entropy_with_logits(agent_prob,torch.zeros_like(agent_prob))  # Loss on "fake" (policy) data
            # policy_loss = F.binary_cross_entropy_with_logits(agent_prob,torch.ones_like(agent_prob))  # Loss on "fake" (policy) data
            #
            # (policy_loss + 1.0 * r1_reg).backward()

            # expert_prob = self.discriminator(expert_states, expert_actions)
            # agent_prob = self.discriminator(agent_states, agent_actions)
            #
            # smooth_real_labels = torch.rand_like(expert_prob) * 0.05 # 将真实标签调整到[0, 0.1]之间
            # smooth_fake_labels = 1 - torch.rand_like(agent_prob) * 0.05  # 将虚假标签调整到[0.9, 1]之间
            # self.discriminator_loss = nn.BCELoss()(expert_prob, smooth_real_labels) + nn.BCELoss()(agent_prob, smooth_fake_labels)

            self.discriminator_loss = nn.BCELoss()(expert_prob, torch.zeros_like(expert_prob)) + nn.BCELoss()(agent_prob,
                                                                                                              torch.ones_like(
                                                                                                                  agent_prob))
            # 计算L2正则化项
            l2_regularization = 0.0
            for param in self.discriminator.parameters():
                l2_regularization += torch.norm(param, p=2)  # 这里的p=2表示L2范数

            # 将正则化项添加到损失中
            self.discriminator_loss += 0.01 * l2_regularization  # 原来是0.01
            print(f"判别器损失{self.discriminator_loss}")

            self.discriminator_optimizer.zero_grad()
            self.discriminator_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.discriminator.parameters(), 0.5)  # 对梯度进行裁剪
            self.discriminator_optimizer.step()

            # rewards = -torch.log(agent_prob).detach().cpu().numpy()
        rewards = -torch.log(agent_prob + 1e-10).detach().cpu().numpy()
        # np.set_printoptions(threshold=np.inf)
        # print(np.array(rewards))
        # breakpoint()
        replay_buffer.reward = rewards
        # self.agent.update(transition_dict)
        if count_special > 85:
            update_times2 = 2
        else:
            update_times2 = 1
        for _ in range(update_times2):
            self.agent.update(replay_buffer)
        self.disc_scheduler.step()
