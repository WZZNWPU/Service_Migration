import argparse
import csv
import math
import random

import matplotlib
import numpy as np
import torch
import torch.nn.functional as F
from matplotlib import pyplot as plt
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from StableMatch.Gale_Shapley.GS_test2 import GaleShapleyUser
from StableMatch import utils
from StableMatch.utils import generate_network_bandwidth
from dijkstra import dijkstra
from imitation_learning.PPO_eval import evaluate_policy
from imitation_learning.PPO_test import PPO

from gail import GAIL
from imitation_learning.normalization import RewardScaling
from imitation_learning.processdata import StandardScaler, MinMaxScaler

# 获取环境的状态特征
from imitation_learning.replaybuffer import ReplayBuffer
from sample_expert_data import sample_expert_data

user_file = '../StableMatch/user.csv'
en_file = '../StableMatch/en.csv'
num_file = '../StableMatch/num.csv'
traj_file = '../Trajectory.csv'

gs = GaleShapleyUser(user_file, en_file, num_file, traj_file)
print('\n\n\n\n')

'''读取用户信息，并对用户信息进行归一化'''


def read_users_dataset():
    # 定义节点特征
    users_feature = []
    with open(user_file, 'r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        # 将读文件的信息写入列表里存放)
        i = 0
        for row in reader:
            # print(i)
            if (i < 10):
                loc = (float(row['loc_x']), float(row['loc_y']))
                u_id = int(row['u_id'])
                cpu_circle = float(row['cpu_circle'])
                class_for_del = int(row['class_for_del'])
                satisfied_serv_del = float(row['satisfied_serv_del'])
                max_serv_del = float(row['max_serv_del'])
                data_size = float(row['input_size'])
                result_size = float(row['result_size'])
                p = float(row['p'])
                user_node_feature = [float(row['loc_x']),
                                     float(row['loc_y']),
                                     cpu_circle,
                                     satisfied_serv_del,
                                     max_serv_del,
                                     data_size,
                                     # data_size,
                                     result_size,
                                     # p,
                                     class_for_del]
                # with open(traj_file, 'r', encoding='utf-8') as csvfile:
                #     reader2 = csv.DictReader(csvfile)
                #     for row2 in reader2:
                #         if int(row2['#Node']) == u_id:
                #             # 将对应的用户轨迹写到对应的用户
                #             user_node_feature.append(float(row2['X']))
                #             user_node_feature.append(float(row2['Y']))
                users_feature.append(user_node_feature)
                i += 1
            else:
                break
    # 使用StandardScaler记录标准化参数
    users_feature = np.array(users_feature, dtype=float)
    # 获取均值和标准差
    scaler = MinMaxScaler()
    scaler.fit(users_feature)
    scaler.min[0] = 100
    scaler.min[1] = 100
    scaler.max[0] = 3000
    scaler.max[1] = 3000
    # print(scaler.min)
    # print(scaler.max)
    # breakpoint()
    users_data = scaler.transform(users_feature)
    return scaler, users_data


'''
1.读取各边缘服务器的特征，将其转换为numpy
  每个边缘服务器的各个属性用list存储
  转换为张量
  定义边的索引
'''


def read_graph_dataset():
    # 定义节点特征
    edge_nodes_feature = []
    for en_id in range(gs.en_num):
        node_feature = [gs.EN_group[en_id].loc[0],
                        gs.EN_group[en_id].loc[1],
                        # gs.EN_group[en_id].clock_frequency,
                        # gs.EN_group[en_id].radius,
                        gs.EN_group[en_id].comp_power,
                        # gs.EN_group[en_id].p,
                        # gs.EN_group[en_id].h,
                        gs.EN_group[en_id].curConsumeResources + 1e5,
                        gs.EN_group[en_id].bw]
        edge_nodes_feature.append(node_feature)
    edge_nodes_feature = np.array(edge_nodes_feature, dtype=float)  # shape([25, 5])
    # print(f'边缘节点特征数组:{edge_nodes_feature}')

    # 按列进行标准化
    scaler_en = MinMaxScaler()
    scaler_en.fit(edge_nodes_feature)
    scaler_en.min[3] = 1e4
    scaler_en.max[3] = 5e8

    edge_nodes_feature = scaler_en.transform(edge_nodes_feature)

    # print(f'标准化之后的边缘节点特征数组:{edge_nodes_feature}')
    # print(f'边缘节点特征张量:{edge_nodes_feature}')
    # breakpoint()

    edge_index = []
    edge_attr = []
    # 定义边索引,判断两个边缘服务器之间是否有连接,若有连接,获取两个边缘服务器间的带宽矩阵
    k = 0
    for i in range(1, gs.en_num):
        for j in range(i):
            distance_ap_to_ap = np.linalg.norm(x=np.array(gs.EN_group[i].loc) - np.array(gs.EN_group[j].loc), ord=2)
            if distance_ap_to_ap < (gs.EN_group[i].radius + gs.EN_group[j].radius):
                bandwidth = gs.en_bw[k] * 1e6
                edge_attr.append(bandwidth)  # 边权重,带宽
                edge_index.append([i, j])
                edge_attr.append(bandwidth)  # 边权重,带宽
                edge_index.append([j, i])
            k = k + 1
    # edge_index = torch.tensor(edge_index, dtype=torch.long).to(device)  # torch.Size([114, 2])
    # edge_index = edge_index.t().contiguous()  # 边索引 torch.Size([2, 114])

    edge_attr = np.array(edge_attr, dtype=float)  # 边权重,带宽

    # print(f'前edge_attr-->{edge_attr}')
    # 对边权值按列进行标准化
    scaler_edge = MinMaxScaler()
    # scaler_edge.fit(edge_attr)
    scaler_edge.min, scaler_edge.max = 5e6, 1e8
    edge_attr = scaler_edge.transform(edge_attr)
    edge_attr = edge_attr.reshape(-1, 1)
    # print(f'后edge_attr-->{edge_attr}')
    # breakpoint()
    return edge_nodes_feature, scaler_en, edge_index, edge_attr, scaler_edge


'''
2.思考用户的特征信息包含几个维度（用户坐标，用户请求的CPU周期，用户的服务类型，用户的两个延迟，用户的发射功率，用户的数据大小和结果大小和初始数据大小，用户当前的ap,用户的卸载延迟，用户的移动轨迹）
'''


def train_on_gail(gail, agent, args, device, expert_s_user, expert_s_graph, expert_s_en_bw, expert_a, expert_s_edge_indexs):
    count_special = 0
    evaluate_num = 0
    evaluate_rewards = []
    evaluate_reward = -1000
    return_list = []
    replay_buffer = ReplayBuffer(args, device)
    one_trajectory = ReplayBuffer(args, device)
    if args.use_reward_scaling:  # Trick 4:reward scaling
        reward_scaling = RewardScaling(shape=1, gamma=args.gamma)

    for i in range(args.epochs):
        with tqdm(total=int(args.num_episodes / 10), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(args.num_episodes / 10)):
                # 每个回合重新读取用户信息和边缘服务器信息
                edge_nodes_feature, scaler_en, edge_index, edge_attr, scaler_edge = read_graph_dataset()
                scaler_for_user, users_data = read_users_dataset()
                gs = GaleShapleyUser(user_file, en_file, num_file, traj_file)
                print('\n\n\n\n')

                # 用一个列表存储所有用户的服务是否完成:t = 0时，默认所有都未完成
                is_complete = [False for i in range(gs.u_num)]

                time_slot = 100
                match_num = 1  # 当前匹配次数
                system_time = 0  # 记录当前的系统时间

                '''
                用户按泊松分布到达
                '''
                arrival_rate = 0.005  # 用户到达的平均频率
                start_time = 200  # 区间的起始时间
                end_time = 1000  # 区间的结束时间

                interval_length = end_time - start_time  # 区间的长度

                expected_arrivals = arrival_rate * interval_length  # 期望到达次数

                arrivals = np.random.poisson(expected_arrivals)  # 生成到达次数
                arrival_times = np.sort(
                    np.random.uniform(start_time, end_time, arrivals))  # [333.00916808 340.35106544 983.32026072]
                arrival_index = 0

                episode_return = 0
                transition_dict = {"states_graph": [], "states_user": [], "actions": [], "next_states_graph": [],
                                   "next_states_user": [], "rewards": [], "dones": [],
                                   "mask": [], "states_en_bw": [], "next_states_en_bw": [], "edge_index": []}

                # 获取初始状态
                state_graph = edge_nodes_feature
                state_user = users_data[0]
                state_en_bw = edge_attr

                # 当有用户的服务没有完成时，不断循环
                # while not all(is_complete):
                done = False
                while not done:
                    for user_id in range(gs.u_num):
                        is_take = False
                        # 初始时对所有边缘服务器进行掩码
                        mask = np.ones(gs.en_num + 1, dtype=bool)
                        # print(mask)

                        if gs.user_group[user_id].t == 0:
                            gs.generate_user_favorite_list(user_id)
                            # print(gs.user_group[user_id].favorNum)
                            for en_id in range(gs.en_num):
                                if en_id in gs.user_group[user_id].favorNum:
                                    # 会导致用户超出延迟要求的边缘服务器不可选,对于用户请求资源 > 边缘服务器当前可用资源, 这些边缘服务器不能选
                                    if (gs.EN_group[en_id].Capacity - gs.EN_group[en_id].curConsumeResources) >= \
                                            gs.user_group[
                                                user_id].cpu_circle:
                                        mask[en_id] = False
                            is_take = True
                            mask = torch.tensor(mask, dtype=torch.bool).to(device).detach()
                            # print(agent.take_action(state_graph, state_user, state_en_bw, edge_index,
                            #                                            mask.clone()))

                            action, action_logprob = agent.take_action(state_graph, state_user, state_en_bw, edge_index,
                                                                       mask.clone())  # 为用户选择边缘服务器

                        else:
                            # gs.generate_user_favor_list_ignore_onload_latency(user_id,time_slot)
                            # print(gs.user_group[user_id].favorNum)
                            if gs.user_group[user_id].status:
                                mask[:] = True

                            else:
                                for en_id in range(gs.en_num):
                                    if en_id in gs.user_group[user_id].favorNum:
                                        # 会导致用户超出延迟要求的边缘服务器不可选,对于用户请求资源 > 边缘服务器当前可用资源, 这些边缘服务器不能选
                                        if (gs.EN_group[en_id].Capacity - gs.EN_group[en_id].curConsumeResources) >= \
                                                gs.user_group[
                                                    user_id].cpu_circle:
                                            mask[en_id] = False
                                is_take = True
                                mask = torch.tensor(mask, dtype=torch.bool).to(device).detach()
                                # print(agent.take_action(state_graph, state_user, state_en_bw, edge_index,
                                #                                            mask.clone()))

                                action, action_logprob = agent.take_action(state_graph, state_user, state_en_bw, edge_index,
                                                                           mask.clone())  # 为用户选择边缘服务器

                        mask = torch.tensor(mask, dtype=torch.bool).to(device).detach()
                        # print(agent.take_action(state_graph, state_user, state_en_bw, edge_index,
                        #                                            mask.clone()))

                        # action, action_logprob = agent.take_action(state_graph, state_user, state_en_bw, edge_index,
                        #                                            mask.clone())  # 为用户选择边缘服务器
                        # if action == 25:
                        #     print("shazi")

                        # 更新边缘服务器的状态信息
                        if not torch.all(mask):
                            print(f'action--> {action}')
                            gs.user_group[user_id].onload_del = gs.temp_onload_del[user_id][action]  # 更新用户卸载延迟
                            gs.user_group[user_id].cur_en = action  # 更新用户en
                            gs.user_group[user_id].status = True  # 用户当前状态更新为True
                            gs.EN_group[action].currentUsers.append(gs.user_group[user_id])
                            gs.EN_group[action].currentUserNum += 1
                            gs.EN_group[action].curConsumeResources += gs.user_group[user_id].cpu_circle
                            origin_info = scaler_en.inverse_transform(edge_nodes_feature[action])
                            origin_info[3] += gs.user_group[user_id].cpu_circle
                            edge_nodes_feature[action] = scaler_en.transform(origin_info)

                        # TODO:更新Env状态信息
                        '''
                        TODO:更新Env状态信息
                        更新边缘服务器的信息，比如占用资源啥的
                        '''

                        # 对边缘服务器信息和用户信息进行特征提取和特征融合
                        if user_id < gs.u_num:
                            next_state_graph = edge_nodes_feature
                            next_state_user = users_data[user_id + 1]
                            next_state_en_bw = edge_attr

                        if all(is_complete):
                            done = True
                            total_del_list = []
                            for u in range(gs.u_num):
                                total_del_list.append(gs.user_group[u].total_del)
                            reward = -np.mean(np.array(total_del_list))
                            episode_return += reward
                            reward = 1000 + reward
                        # else:
                        #     reward = 0
                        #     done = False
                        else:
                            if action != args.action_dim - 1:
                                reward = -(gs.temp_total_del[user_id][action] - gs.user_group[
                                    user_id].max_serv_del) / 20
                                # if gs.temp_total_del[user_id][action] > gs.user_group[user_id].max_serv_del:  # 如果用户超出规定的延迟，要给予惩罚
                                #     reward = - min(
                                #         0.5 * (gs.temp_total_del[user_id][action] - gs.user_group[user_id].max_serv_del),
                                #         50)
                                # else:
                                #     reward = 0
                            else:
                                reward = 0
                            done = False
                        if args.use_reward_scaling:
                            reward = reward_scaling(reward)

                        transition_dict["states_user"].append(state_user)
                        transition_dict["states_graph"].append(state_graph)
                        transition_dict["states_en_bw"].append(state_en_bw)
                        transition_dict["actions"].append(action)
                        transition_dict["next_states_user"].append(next_state_user)
                        transition_dict["next_states_graph"].append(next_state_graph)
                        transition_dict["next_states_en_bw"].append(next_state_en_bw)
                        transition_dict["rewards"].append(reward)
                        transition_dict["dones"].append(done)
                        transition_dict["mask"].append(mask.clone())
                        transition_dict["edge_index"].append(edge_index)

                        # When dead or win or reaching the max_episode_steps, done will be Ture, we need to distinguish them;
                        # dw means dead or win,there is no next state s';
                        # but when reaching the max_episode_steps,there is a next state s' actually.
                        if done:
                            dw = True
                        else:
                            dw = False

                        # 采取动作才记录轨迹
                        if is_take == True:
                            one_trajectory.store(state_user, state_graph, state_en_bw, action, action_logprob, reward / 100,
                                                 next_state_user, next_state_graph, next_state_en_bw, dw, done,
                                                 mask, edge_index)

                        if done:
                            # print(one_trajectory.count)
                            # breakpoint()
                            if episode_return >= (evaluate_reward - 35):
                                print(f"芜湖{evaluate_reward}")
                                # replay_buffer.copy_one_by_one_from(one_trajectory)
                                replay_buffer.copy_from(one_trajectory)
                                print(f"经验池{replay_buffer.count}")
                            one_trajectory.count = 0

                        # 切换到下一个环境状态
                        state_user = next_state_user
                        state_graph = next_state_graph
                        state_en_bw = next_state_en_bw

                        # When the number of transitions in buffer reaches batch_size,then update
                        if replay_buffer.count == args.batch_size:
                            # print(args.batch_size)
                            count_special = i
                            gail.learn(expert_s_user, expert_s_graph, expert_s_en_bw, expert_a, expert_s_edge_indexs,
                                       replay_buffer,count_special)
                            # agent.update(replay_buffer)
                            replay_buffer.count = 0

                        # print(f'缩放后的reward-->{reward}')
                        if done:
                            break

                    for user in gs.user_group:
                        # 用户的卸载延迟只和t=0时刻用户卸载的有关(因为用户只在t = 0时卸载)
                        if user.t == 0:
                            # print(f"userid{user.id}")
                            # print(f"curen{user.cur_en}")
                            user.onload_del = gs.temp_onload_del[user.id][user.cur_en]
                            user.cur_mig_del = 0
                            user.total_del = gs.temp_total_del[user.id][user.cur_en]
                            user.cur_com_del = user.last_com_del + gs.temp_com_del[user.id][user.cur_en]
                            user.cur_dl_del = gs.temp_dl_del[user.id][user.cur_en]
                        else:
                            user.total_del = gs.temp_total_del[user.id][user.cur_en]
                            user.cur_com_del = gs.temp_com_del[user.id][user.cur_en]
                            user.cur_mig_del = user.last_mig_del + 0 if all(not item for item in gs.temp_mig_del[user.id]) else \
                                gs.temp_mig_del[user.id][user.cur_en]
                            user.cur_dl_del = gs.temp_dl_del[user.id][user.cur_en]

                    # TODO:更新系统时间
                    system_time += time_slot

                    # TODO:更新用户新的坐标
                    for u in range(gs.u_num):
                        gs.user_group[u].last_loc = gs.user_group[u].loc
                        gs.user_group[u].loc = gs.user_group[u].traj[int(gs.user_group[u].t / time_slot) + 1]
                        origin_user_info = scaler_for_user.inverse_transform(users_data[u])
                        origin_user_info[0] = gs.user_group[u].loc[0]
                        origin_user_info[1] = gs.user_group[u].loc[1]
                        users_data[u] = scaler_for_user.transform(origin_user_info)

                    # TODO:网络产生随机波动
                    gs.en_bw = generate_network_bandwidth(mean=80, std_dev=25, n=gs.valid_num)
                    for en in range(gs.en_num):
                        gs.EN_group[en].bw = float(generate_network_bandwidth(mean=80, std_dev=25, n=1)) * math.pow(10, 6)
                        origin_en_bw = scaler_en.inverse_transform(edge_nodes_feature[en])
                        origin_en_bw[4] = gs.EN_group[en].bw
                        edge_nodes_feature[en] = scaler_en.transform(origin_en_bw)

                    kk = 0
                    edge_attr2 = []
                    for m in range(1, gs.en_num):
                        for n in range(m):
                            distance_ap_to_ap2 = np.linalg.norm(x=np.array(gs.EN_group[m].loc) - np.array(gs.EN_group[n].loc),
                                                                ord=2)
                            if distance_ap_to_ap2 < (gs.EN_group[m].radius + gs.EN_group[n].radius):
                                bandwidth = gs.en_bw[kk] * 1e6
                                edge_attr2.append(bandwidth)  # 边权重,带宽
                                edge_attr2.append(bandwidth)  # 边权重,带宽
                            kk = kk + 1
                    edge_attr2 = np.array(edge_attr2, dtype=float)
                    edge_attr = scaler_edge.transform(edge_attr2)
                    edge_attr = edge_attr.reshape(-1, 1)

                    '''
                     # 判断当前系统时间是否有用户到达，有用户到达则添加到用户组
                    '''
                    # print(f"第{match_num}轮匹配")
                    # print(f"系统时间{system_time}")
                    # print(f'help{arrival_times[arrival_index] < system_time and arrival_index < arrival_times.size}')
                    while arrival_index < arrival_times.size and arrival_times[arrival_index] < system_time:  # 表明新用户到达
                        arrival_index, is_complete = utils.new_user_arrival(traj_file, arrival_index, gs, is_complete)

                    # 假设每 timeslot 毫秒检查一次用户服务是否需要迁移
                    gs.ap_set_for_u, gs.dist_set = gs.ap_set_for_user()
                    gs.ap_for_user = gs.chooseAP()

                    for u in range(gs.u_num):
                        '''
                        # 对于新到达的用户，其还没有托管其服务，先不需要迁移，先为其选择托管服务的边缘服务器
                        '''
                        if gs.user_group[u].cur_en == np.inf:
                            gs.generate_user_favorite_list(gs.user_group[u].id)
                            print('---------------------------------------------------------')
                            continue
                        '''
                         # 对于不是新到达的用户，判断是否需要迁移
                        '''
                        gs.user_group[u].t += time_slot
                        last_ds = gs.user_group[u].data_size
                        gs.user_group[u].last_dl_del = gs.user_group[u].cur_dl_del

                        if gs.user_group[u].cur_en != np.inf:
                            done_ds = gs.user_group[u].cpu_circle / gs.EN_group[gs.user_group[u].cur_en].comp_power * 8

                        # 如果用户剩余数据<一个时隙服务器可以计算的服务数据,则说明用户服务已经完成
                        if gs.user_group[u].data_size <= done_ds:
                            gs.user_group[u].done = True
                            gs.user_group[u].data_size = 0
                            # origin_user_data = scaler_for_user.inverse_transform(users_data[u])  # 反向映射回来
                            # origin_user_data[6] = 1e-10
                            # users_data[u] = scaler_for_user.transform(origin_user_data)  # 映射回来
                            is_complete[u] = True
                        else:
                            gs.user_group[u].data_size -= done_ds

                            # origin_user_data = scaler_for_user.inverse_transform(users_data[u])  # 反向映射回来
                            # origin_user_data[6] = gs.user_group[u].data_size
                            # users_data[u] = scaler_for_user.transform(origin_user_data)  # 映射回来

                            gs.user_group[u].last_com_del = gs.user_group[u].last_com_del + time_slot \
                                if gs.user_group[u].estimated_remaining_time > time_slot else gs.user_group[u].last_com_del + \
                                                                                              gs.user_group[
                                                                                                  u].estimated_remaining_time

                            gs.user_group[u].estimated_remaining_time = \
                                (gs.user_group[u].estimated_remaining_time - time_slot) if gs.user_group[
                                                                                               u].estimated_remaining_time > time_slot else 0

                            # 如果t==0，用户不可能发生迁移
                            if gs.user_group[u].t == 0:
                                gs.user_group[u].last_mig_del = 0
                            else:
                                if gs.user_group[u].this_mig_time <= time_slot:
                                    gs.user_group[u].refuse_mig = False
                                    gs.user_group[u].this_mig_time = 0
                                    gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del
                                else:
                                    gs.user_group[u].refuse_mig = True
                                    gs.user_group[u].this_mig_time -= time_slot
                                    gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del

                            # 判断用户是否需要迁移
                            str1 = "软延迟" if gs.user_group[u].class_for_del == False else "硬延迟"
                            if np.array_equal(gs.user_group[u].loc, gs.user_group[u].last_loc):  # 用户没有移动
                                gs.user_group[u].favorNum = []  # 不需要迁移
                            else:
                                a2u_down_del = gs.user_group[u].res_size / (utils.tr_BU(B=gs.EN_group[gs.ap_for_user[u]].bw,
                                                                                        h=gs.EN_group[gs.ap_for_user[u]].h,
                                                                                        sigma=1.5 * math.pow(10, -11),
                                                                                        p_b=gs.EN_group[gs.ap_for_user[u]].p,
                                                                                        r=np.linalg.norm(ord=2, x=np.array(
                                                                                            gs.EN_group[
                                                                                                gs.ap_for_user[
                                                                                                    u]].loc) - np.array(
                                                                                            gs.user_group[u].loc))) / math.pow(10,
                                                                                                                               3))

                                down_TDM = utils.get_TDM(gs.en_num, gs.en_bw, gs.EN_group, gs.user_group[u].res_size)
                                down_distance, down_path = dijkstra(down_TDM, gs.ap_for_user[u], gs.user_group[u].cur_en)

                                gs.user_group[u].cur_dl_del = a2u_down_del + down_distance[gs.user_group[u].cur_en]

                                # 如果总延迟超过了用户能接受的最大延迟，则发生迁移
                                delay = gs.user_group[u].onload_del + gs.user_group[u].cur_com_del + gs.user_group[
                                    u].cur_mig_del + gs.user_group[u].cur_dl_del

                                '''
                                # 分情况讨论：
                                # 1.如果用户服务是软服务且服务执行程度超过50%,且在软服务最大延迟接收范围内，则可以不迁移
                                # 2.如果用户服务是硬服务，则一旦超越满意延迟范围，则必须迁移
                                '''
                                if gs.user_group[u].class_for_del == 0 and \
                                        (gs.user_group[u].init_data_size - gs.user_group[u].data_size) / gs.user_group[
                                    u].init_data_size >= 0.5 \
                                        and delay <= gs.user_group[u].max_serv_del:
                                    # print(f'软延迟服务，执行程度超过50%，不需要迁移')
                                    continue
                                elif gs.user_group[u].class_for_del == 0 and delay <= gs.user_group[u].satisfied_serv_del:
                                    # print(f'软延迟服务，未超过最优服务体验范围，不需要迁移')
                                    continue
                                elif gs.user_group[u].class_for_del == 1 and delay <= gs.user_group[u].satisfied_serv_del:
                                    # print(f'硬延迟服务，未超过延迟范围，不需要迁移')
                                    continue
                                else:
                                    # if delay > gs.user_group[u].max_serv_del:
                                    # print(f'{gs.user_group[u].id}-->发生迁移')
                                    '''
                                        # 修改用户和托管其服务的原服务器的状态
                                    '''
                                    utils.modify_state(gs, u)

                                    '''
                                        重新计算用户的偏好列表
                                    '''
                                    gs.generate_user_favor_list_ignore_onload_latency(u, time_slot)

                return_list.append(episode_return)
                # gail.learn(expert_s_user, expert_s_graph, expert_s_en_bw, expert_a, expert_s_edge_indexs,
                #            transition_dict["states_user"], transition_dict["states_graph"],transition_dict["states_en_bw"],
                #            transition_dict["actions"],transition_dict["next_states_user"],transition_dict["next_states_graph"],
                #            transition_dict["next_states_en_bw"], transition_dict["dones"])

                with open('train_results3.csv', 'a', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow(
                        [i * 30 + i_episode, np.mean(return_list[-1:])
                         ])
                    # agent.update(transition_dict)
                if (i_episode + 1) % 10 == 0:
                    # Evaluate the policy
                    # 在每次评估后将数据附加到CSV文件的末尾
                    evaluate_num += 1
                    evaluate_reward = evaluate_policy(agent)
                    evaluate_rewards.append(evaluate_reward)
                    print("evaluate_num:{} \t evaluate_reward:{} \t".format(evaluate_num, evaluate_reward))
                    with open('evaluate_results3.csv', 'a', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow([evaluate_num, evaluate_reward])
                    # with open('train_results6.csv', 'a', newline='') as file:
                    #     writer = csv.writer(file)
                    #     writer.writerow(
                    #         [evaluate_num, np.mean(return_list[-10:])
                    #          ])
                    # Save the rewards
                    # if evaluate_num % 6 == 0:
                    #     np.save('./data_train/PPO_discrete_env_{}.npy'.format('gs'),
                    #             np.array(evaluate_rewards))

                    pbar.set_postfix({'episode': '%d' % (args.num_episodes / 10 * i + i_episode + 1),  # 计算最后10个元素的平均值
                                      'return': '%.3f' % np.mean(return_list[-10:]),
                                      })
                    # 'critic_loss': '%.4f' % agent.critic_loss
                    # 'actor_loss': '%.4f' % agent.actor_loss.mean()
                    # agent.greediness = 0.45 * math.exp(-1.2 * (3000 - (i * 30 + i_episode)) / 3000)
                agent.greediness = 0.0
                if i > 99:
                    agent.greediness = 0.0
                pbar.update(1)
        if (i + 1) % 1 == 0:
            # print("来了来了")
            actor_path = f"./gail_weights/actor_epoch_{i + 1}.pt"
            critic_path = f"./gail_weights/critic_epoch_{i + 1}.pt"
            disc_path = f"./gail_weights/disc_epoch_{i + 1}.pt"
            torch.save(agent.actor.state_dict(), actor_path)
            torch.save(agent.critic.state_dict(), critic_path)
            torch.save(gail.discriminator.state_dict(), disc_path)
            # if (i + 1) % 5 == 0:

            # greediness_list[(i + 1) // 5]
        print(f'贪心概率{agent.greediness}')

    return return_list


def main(args):
    # args.actor_lr = 1e-4  # 策略网络学习率
    # args.critic_lr = 6e-4  # 价值网络学习率
    args.actor_lr = 1e-4  # 策略网络学习率
    args.critic_lr = 6e-4  # 价值网络学习率
    args.discriminator_lr = 9e-5  # 判別网络学习率
    args.num_episodes = 300  # 回合数
    args.hidden_dim = 128  # 隐藏层维度
    args.gamma = 0.99  # 折扣系数
    args.lambda_ = 0.70  # λ
    args.epochs = 100  # 训练轮数
    args.eps = 0.2  # PPO参数
    args.en_graph_dim = 5  # 边缘节点的特征维度
    args.user_information_dim = 8  # 用户信息的特征维度
    args.action_dim = gs.en_num + 1  # 动作空间的维度,即边缘服务器的个数+1,因为有可能用户这一轮不需要选择边缘服务器
    args.state_dim = 68  # 状态空间的维度
    args.greediness = 0.0
    args.state_en_bw_dim = 114

    device = torch.device("cuda:0") if torch.cuda.is_available() else torch.device("cpu")
    ppo_agent1 = PPO(args, device)

    actor_checkpoint = torch.load('../imitation_learning/weights/actor_epoch_99.pt', map_location='cuda:0')  # 加载模型权重的状态字典
    critic_checkpoint = torch.load('../imitation_learning/weights/critic_epoch_99.pt', map_location='cuda:0')  # 加载模型权重的状态字典
    ppo_agent1.actor.load_state_dict(actor_checkpoint)  # 将状态字典加载到模型中
    ppo_agent1.critic.load_state_dict(critic_checkpoint)  # 将状态字典加载到模型中
    ppo_agent1.actor.eval()
    ppo_agent1.critic.eval()
    ppo_agent1.greediness = 0.4

    expert_s_user, expert_s_graph, expert_s_en_bw, expert_a, expert_s_edge_indexs = sample_expert_data(n_episode=1000,
                                                                                                       agent=ppo_agent1)
    # print(expert_s_user.shape)
    # print(expert_s_graph.shape)
    # print(expert_s_en_bw.shape)
    # 将 expert_s_user 和 expert_s_graph 转换为 1D 数组
    user_flat = expert_s_user
    # print(user_flat.shape)
    graph_flat = expert_s_graph.reshape(expert_s_graph.shape[0], -1)
    # print(graph_flat.shape)
    en_bw_flat = expert_s_en_bw.reshape(expert_s_en_bw.shape[0], -1)
    # print(graph_flat.shape)
    # 将 expert_s_user 和 expert_s_graph 进行水平拼接
    data_combined = np.hstack((user_flat, graph_flat, en_bw_flat))

    # 删除重复的行，保留第一次出现的行
    unique_data, unique_indices = np.unique(data_combined, axis=0, return_index=True)

    # 使用 unique_indices 来提取唯一的数据
    unique_user = expert_s_user[unique_indices]
    unique_graph = expert_s_graph[unique_indices]
    unique_en_bw = expert_s_en_bw[unique_indices]
    unique_a = expert_a[unique_indices]
    unique_edge_indexs = expert_s_edge_indexs[unique_indices]
    print(f"专家数量{unique_user.shape}")

    # breakpoint()
    # n_samples = 1024  # 采样100个数据
    # random.seed(40)
    # random_index = random.sample(range(expert_s_user.shape[0]), n_samples)
    # expert_s_user = expert_s_user[random_index]
    # expert_s_graph = expert_s_graph[random_index]
    # expert_s_en_bw = expert_s_en_bw[random_index]
    # expert_a = expert_a[random_index]
    # expert_s_edge_indexs = expert_s_edge_indexs[random_index]

    n_samples = unique_user.shape[0]  # 采样100个数据
    # n_samples = 256  # 采样100个数据
    random.seed(40)
    random_index = random.sample(range(unique_user.shape[0]), n_samples)
    expert_s_user = unique_user[random_index]
    expert_s_graph = unique_graph[random_index]
    expert_s_en_bw = unique_en_bw[random_index]
    expert_a = unique_a[random_index]
    expert_s_edge_indexs = unique_edge_indexs[random_index]

    ppo_agent2 = PPO(args, device)
    # ppo_agent2.actor.load_state_dict(actor_checkpoint)  # 将状态字典加载到模型中
    # ppo_agent2.critic.load_state_dict(critic_checkpoint)  # 将状态字典加载到模型中
    gail = GAIL(ppo_agent2, args, device)

    # torch.autograd.set_detect_anomaly(True)
    return_list = train_on_gail(gail, ppo_agent2, args, device, expert_s_user, expert_s_graph, expert_s_en_bw, expert_a,
                                expert_s_edge_indexs)

    torch.autograd.set_detect_anomaly(True)
    iteration_list = list(range(len(return_list)))
    matplotlib.rcParams['font.family'] = 'Times New Roman'  # 设置字体为Times New Roman
    matplotlib.rcParams['xtick.labelsize'] = 14  # 设置x轴刻度字体大小为14
    matplotlib.rcParams['xtick.labelsize'] = 14  # 设置x轴刻度字体大小为14
    matplotlib.rcParams['ytick.labelsize'] = 14  # 设置y轴刻度字体大小为14

    # 训练的回合数
    steps = np.array(iteration_list)

    # 假设这里有1000个未平滑的奖励值数据，实际情况应根据数据调整
    rewards = np.array(return_list)

    # 计算每二十步的均值和标准差
    window_size = 30
    mean_rewards = np.convolve(rewards, np.ones(window_size) / window_size, mode='valid')
    std_rewards = np.std(np.lib.stride_tricks.as_strided(rewards, shape=(rewards.size - window_size + 1, window_size),
                                                         strides=(rewards.strides[0], rewards.strides[0])), axis=1)

    # 设置科研配色
    color = 'tab:blue'
    fill_color = 'tab:blue'
    mean_color = 'tab:red'

    # 绘制奖励曲线和填充色波动区间
    plt.figure(figsize=(10, 6))
    plt.plot(steps[window_size - 1:], mean_rewards, label='Mean Rewards', color=mean_color, linewidth=2)
    plt.fill_between(steps[window_size - 1:], mean_rewards - std_rewards, mean_rewards + std_rewards, alpha=0.2,
                     color=fill_color)
    plt.xlabel('Training Episodes', fontsize=16)
    plt.ylabel('Negative Value of Average Latency', fontsize=16)
    plt.legend(fontsize=14)
    plt.title('Reward Curve with Fluctuation Interval (Every Thirty Episodes)', fontsize=18)
    plt.grid(True)
    plt.tight_layout()  # 自动调整子图参数，防止标题、标签等超出图表边界
    # 加粗边框
    for spine in plt.gca().spines.values():
        spine.set_linewidth(2.5)

    # 保存为高分辨率的PDF矢量图
    plt.savefig('gail_reward_curve_2.pdf', dpi=300, format='pdf')
    plt.savefig('gail_reward_curve_2.png', dpi=500, format='png')
    # plt.savefig('reward_curve.png', dpi=100, format='png')
    plt.show()

    # iteration_list = list(range(len(return_list)))
    # plt.plot(iteration_list, return_list)
    # plt.xlabel('Iterations')
    # plt.ylabel('Returns')
    # plt.title("GAIL")
    # plt.show()


if __name__ == '__main__':
    parser = argparse.ArgumentParser("Hyperparameter Setting for PPO-discrete")
    parser.add_argument("--actor_lr", type=float, default=3e-4, help="Learning rate of actor")
    parser.add_argument("--discriminator_lr", type=float, default=3e-4, help="Learning rate of discriminator")
    parser.add_argument("--critic_lr", type=float, default=3e-4, help="Learning rate of critic")
    parser.add_argument("--en_graph_dim", type=int, default=5, help="en_graph_dim")
    parser.add_argument("--state_en_bw_dim", type=int, default=114, help="state_en_bw_dim")
    parser.add_argument("--user_information_dim", type=int, default=8, help="user_information_dim")
    parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor")
    parser.add_argument("--lamda_", type=float, default=0.90, help="GAE parameter")
    parser.add_argument("--eps", type=float, default=0.2, help="PPO clip parameter")
    parser.add_argument("--epochs", type=int, default=20, help="PPO parameter")
    parser.add_argument("--use_reward_scaling", type=bool, default=False, help="Trick 4:reward scaling")
    parser.add_argument("--use_grad_clip", type=bool, default=True, help="Trick 7: Gradient clip")
    parser.add_argument("--use_adv_norm", type=bool, default=True, help="Trick 1:advantage normalization")
    parser.add_argument("--K_epochs", type=int, default=20, help="PPO parameter")
    parser.add_argument("--batch_size", type=int, default=256, help="Batch size")
    parser.add_argument("--mini_batch_size", type=int, default=64, help="Minibatch size")  # 原1024
    parser.add_argument("--entropy_coef", type=float, default=0.05, help="Trick 5: policy entropy") # 原0.05
    parser.add_argument("--use_lr_decay", type=bool, default=True, help="Trick 6:learning rate Decay")

    args = parser.parse_args()

    main(args)
