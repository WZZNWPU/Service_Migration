import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import torch_geometric.nn as geo_nn
from collections import deque
from torch_geometric.data import Data, Batch

from torch.nn import init


# 定义图神经网络模块
class GraphNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, device):
        super(GraphNetwork, self).__init__()

        self.conv1 = geo_nn.GCNConv(input_dim, hidden_dim).to(device)
        self.relu = nn.ReLU().to(device)
        self.conv2 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv3 = geo_nn.GCNConv(128, output_dim).to(device)
        self.init_parameters()

    def init_parameters(self):
        # Xavier初始化conv1的权重和偏置
        init.xavier_normal_(self.conv1.lin.weight)
        init.zeros_(self.conv1.bias)

        # Xavier初始化conv2的权重和偏置
        init.xavier_normal_(self.conv2.lin.weight)
        init.zeros_(self.conv2.bias)

        # Xavier初始化conv3的权重和偏置
        init.xavier_normal_(self.conv3.lin.weight)
        init.zeros_(self.conv3.bias)

    def forward(self, x, edge_index, edge_attr):
        residual = x  # 保存原始输入作为残差连接
        x = self.conv1(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv2(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv3(x, edge_index, edge_attr)
        x += residual  # 添加残差连接
        return x


class Dueling_Net(nn.Module):
    def __init__(self, args,device):
        super(Dueling_Net, self).__init__()
        # 对状态信息进行特征提取
        self.gcn = GraphNetwork(args.en_graph_dim, hidden_dim=128, output_dim=5, device=device)  # 采用图卷积提取边缘节点的特征
        self.fc1 = nn.Linear(args.state_dim, 128).to(device)  # 输入层
        self.dropout = nn.Dropout(0.0)
        self.fc2 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc3 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc4 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc5 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc6 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc7 = nn.Linear(128, 128).to(device)  # 隐藏层
        if args.use_noisy:
            self.V = NoisyLinear(128, 1).to(device)
            self.A = NoisyLinear(128, args.action_dim).to(device)
        else:
            self.V = nn.Linear(128, 1).to(device)
            self.A = nn.Linear(128, args.action_dim).to(device)

        # 初始化参数
        self.init_parameters()

    def init_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)


    def forward(self, x):
        graph_data, user_information = x[0], x[1]
        nodes_ferature, edge_index, edge_attr = graph_data.x, graph_data.edge_index, graph_data.edge_attr
        batchsize = int(nodes_ferature.shape[0] / 25)
        # print(f'nodes_ferature-->{nodes_ferature}')
        # print(f'user_information-->{user_information}')
        # print(f'edge_attr-->{edge_attr}')

        output1 = self.gcn(nodes_ferature, edge_index, edge_attr)  # output1-->torch.Size([25, 64])
        # print(f'output1-->{output1}')
        # output2 = self.feature_extractor(user_information)  # output2-->torch.Size([64])
        # print(f'output2-->{output2}')
        # 将特征图展品 25*16--->400
        if batchsize > 1:
            output3 = output1.clone().view(batchsize, -1)  # output1-->torch.Size([1600])
        else:
            output3 = output1.clone().view(-1)

        # 进行向量拼接 (192,)
        output5 = torch.cat((output3.clone(), user_information), dim=-1)  # 特征融合后的状态信息 torch.Size([192])
        # print(f'output5-->{output5}')
        s = F.relu(self.fc1(output5))  # ReLU激活函数
        s = torch.relu(self.fc2(s))
        s = torch.relu(self.fc3(s))
        s = torch.relu(self.fc4(s))
        s = torch.relu(self.fc5(s))
        s = torch.relu(self.fc6(s))
        s = torch.relu(self.fc7(s))
        V = self.V(s)  # batch_size X 1
        A = self.A(s)  # batch_size X action_dim
        Q = V + (A - torch.mean(A, dim=-1, keepdim=True))  # Q(s,a)=V(s)+A(s,a)-mean(A(s,a))
        return Q


class Net(nn.Module):
    def __init__(self, args,device):
        super(Net, self).__init__()
        # 对状态信息进行特征提取
        self.gcn = GraphNetwork(args.en_graph_dim, hidden_dim=128, output_dim=5, device=device)  # 采用图卷积提取边缘节点的特征
        self.fc1 = nn.Linear(args.state_dim, 128).to(device)  # 输入层
        self.dropout = nn.Dropout(0.0)
        self.fc2 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc3 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc4 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc5 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc6 = nn.Linear(128, 128).to(device)  # 隐藏层
        if args.use_noisy:
            self.fc7 = NoisyLinear(args.hidden_dim, args.action_dim).to(device)
        else:
            self.fc7 = nn.Linear(args.hidden_dim, args.action_dim).to(device)
            # 初始化参数
            self.init_parameters()

    def init_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
    def forward(self, x):
        graph_data, user_information = x[0], x[1]
        nodes_ferature, edge_index, edge_attr = graph_data.x, graph_data.edge_index, graph_data.edge_attr
        batchsize = int(nodes_ferature.shape[0] / 25)
        # print(f'nodes_ferature-->{nodes_ferature}')
        # print(f'user_information-->{user_information}')
        # print(f'edge_attr-->{edge_attr}')

        output1 = self.gcn(nodes_ferature, edge_index, edge_attr)  # output1-->torch.Size([25, 64])
        # print(f'output1-->{output1}')
        # output2 = self.feature_extractor(user_information)  # output2-->torch.Size([64])
        # print(f'output2-->{output2}')
        # 将特征图展品 25*16--->400
        if batchsize > 1:
            output3 = output1.clone().view(batchsize, -1)  # output1-->torch.Size([1600])
        else:
            output3 = output1.clone().view(-1)

        # 进行向量拼接 (192,)
        output5 = torch.cat((output3.clone(), user_information), dim=-1)  # 特征融合后的状态信息 torch.Size([192])
        # print(f'output5-->{output5}')
        s = F.relu(self.fc1(output5))  # ReLU激活函数
        s = torch.relu(self.fc2(s))
        s = torch.relu(self.fc3(s))
        s = torch.relu(self.fc4(s))
        s = torch.relu(self.fc5(s))
        s = torch.relu(self.fc6(s))
        Q = self.fc7(s)
        return Q


class NoisyLinear(nn.Module):
    def __init__(self, in_features, out_features, sigma_init=0.5):
        super(NoisyLinear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.sigma_init = sigma_init

        self.weight_mu = nn.Parameter(torch.FloatTensor(out_features, in_features))
        self.weight_sigma = nn.Parameter(torch.FloatTensor(out_features, in_features))
        self.register_buffer('weight_epsilon', torch.FloatTensor(out_features, in_features))

        self.bias_mu = nn.Parameter(torch.FloatTensor(out_features))
        self.bias_sigma = nn.Parameter(torch.FloatTensor(out_features))
        self.register_buffer('bias_epsilon', torch.FloatTensor(out_features))

        self.reset_parameters()
        self.reset_noise()

    def forward(self, x):
        if self.training:
            self.reset_noise()
            weight = self.weight_mu + self.weight_sigma.mul(self.weight_epsilon)  # mul是对应元素相乘
            bias = self.bias_mu + self.bias_sigma.mul(self.bias_epsilon)

        else:
            weight = self.weight_mu
            bias = self.bias_mu

        return F.linear(x, weight, bias)

    def reset_parameters(self):
        mu_range = 1 / math.sqrt(self.in_features)
        self.weight_mu.data.uniform_(-mu_range, mu_range)
        self.bias_mu.data.uniform_(-mu_range, mu_range)

        self.weight_sigma.data.fill_(self.sigma_init / math.sqrt(self.in_features))
        self.bias_sigma.data.fill_(self.sigma_init / math.sqrt(self.out_features))  # 这里要除以out_features

    def reset_noise(self):
        epsilon_i = self.scale_noise(self.in_features)
        epsilon_j = self.scale_noise(self.out_features)
        self.weight_epsilon.copy_(torch.ger(epsilon_j, epsilon_i))
        self.bias_epsilon.copy_(epsilon_j)

    def scale_noise(self, size):
        x = torch.randn(size)  # torch.randn产生标准高斯分布
        x = x.sign().mul(x.abs().sqrt())
        return x
