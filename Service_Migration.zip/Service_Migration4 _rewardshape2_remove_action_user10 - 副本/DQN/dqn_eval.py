import csv
import math

# import gym
import numpy as np
import torch
import torch.nn.functional as F
from matplotlib import pyplot as plt
from tqdm import tqdm

from StableMatch.Gale_Shapley.GS_test2 import GaleShapleyUser
from StableMatch import utils
from StableMatch.utils import generate_network_bandwidth
from dijkstra import dijkstra
from imitation_learning.PPO_test import PPO
from torch_geometric.data import Data

# 训练采用的设备
from imitation_learning.processdata import StandardScaler, MinMaxScaler

device = torch.device("cuda:0") if torch.cuda.is_available() else torch.device("cpu")
print(device)

# 获取环境的状态特征
user_file = '../StableMatch/user.csv'
en_file = '../StableMatch/en.csv'
num_file = '../StableMatch/num.csv'
traj_file = '../Trajectory.csv'

gs = GaleShapleyUser(user_file, en_file, num_file, traj_file)
print('\n\n\n\n')

'''读取用户信息，并对用户信息进行归一化'''


def read_users_dataset():
    # 定义节点特征
    users_feature = []
    with open(user_file, 'r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        # 将读文件的信息写入列表里存放)
        i = 0
        for row in reader:
            # print(i)
            if (i < 10):
                loc = (float(row['loc_x']), float(row['loc_y']))
                u_id = int(row['u_id'])
                cpu_circle = float(row['cpu_circle'])
                class_for_del = int(row['class_for_del'])
                satisfied_serv_del = float(row['satisfied_serv_del'])
                max_serv_del = float(row['max_serv_del'])
                data_size = float(row['input_size'])
                result_size = float(row['result_size'])
                p = float(row['p'])
                user_node_feature = [float(row['loc_x']),
                                     float(row['loc_y']),
                                     cpu_circle,
                                     satisfied_serv_del,
                                     max_serv_del,
                                     data_size,
                                     # data_size,
                                     result_size,
                                     # p,
                                     class_for_del]
                # with open(traj_file, 'r', encoding='utf-8') as csvfile:
                #     reader2 = csv.DictReader(csvfile)
                #     for row2 in reader2:
                #         if int(row2['#Node']) == u_id:
                #             # 将对应的用户轨迹写到对应的用户
                #             user_node_feature.append(float(row2['X']))
                #             user_node_feature.append(float(row2['Y']))
                users_feature.append(user_node_feature)
                i += 1
            else:
                break
    # 使用StandardScaler记录标准化参数
    users_feature = np.array(users_feature, dtype=float)
    # 获取均值和标准差
    scaler = MinMaxScaler()
    scaler.fit(users_feature)
    scaler.min[0] = 100
    scaler.min[1] = 100
    scaler.max[0] = 3000
    scaler.max[1] = 3000
    # print(scaler.min)
    # print(scaler.max)
    # breakpoint()
    users_data = scaler.transform(users_feature)
    return scaler, users_data


'''
1.读取各边缘服务器的特征，将其转换为numpy
  每个边缘服务器的各个属性用list存储
  转换为张量
  定义边的索引
'''


def read_graph_dataset():
    # 定义节点特征
    edge_nodes_feature = []
    for en_id in range(gs.en_num):
        node_feature = [gs.EN_group[en_id].loc[0],
                        gs.EN_group[en_id].loc[1],
                        # gs.EN_group[en_id].clock_frequency,
                        # gs.EN_group[en_id].radius,
                        gs.EN_group[en_id].comp_power,
                        # gs.EN_group[en_id].p,
                        # gs.EN_group[en_id].h,
                        gs.EN_group[en_id].curConsumeResources + 1e5,
                        gs.EN_group[en_id].bw]
        edge_nodes_feature.append(node_feature)
    edge_nodes_feature = np.array(edge_nodes_feature, dtype=float)  # shape([25, 5])
    # print(f'边缘节点特征数组:{edge_nodes_feature}')

    # 按列进行标准化
    scaler_en = MinMaxScaler()
    scaler_en.fit(edge_nodes_feature)
    scaler_en.min[3] = 1e4
    scaler_en.max[3] = 5e8
    # print(scaler_en.min)
    # print(scaler_en.max)
    # breakpoint()
    edge_nodes_feature = scaler_en.transform(edge_nodes_feature)

    # print(f'标准化之后的边缘节点特征数组:{edge_nodes_feature}')
    # print(f'边缘节点特征张量:{edge_nodes_feature}')
    # breakpoint()

    edge_index = []
    edge_attr = []
    # 定义边索引,判断两个边缘服务器之间是否有连接,若有连接,获取两个边缘服务器间的带宽矩阵
    k = 0
    for i in range(1, gs.en_num):
        for j in range(i):
            distance_ap_to_ap = np.linalg.norm(x=np.array(gs.EN_group[i].loc) - np.array(gs.EN_group[j].loc), ord=2)
            if distance_ap_to_ap < (gs.EN_group[i].radius + gs.EN_group[j].radius):
                bandwidth = gs.en_bw[k] * 1e6
                edge_attr.append(bandwidth)  # 边权重,带宽
                edge_index.append([i, j])
                edge_attr.append(bandwidth)  # 边权重,带宽
                edge_index.append([j, i])
            k = k + 1
    # edge_index = torch.tensor(edge_index, dtype=torch.long).to(device)  # torch.Size([114, 2])
    # edge_index = edge_index.t().contiguous()  # 边索引 torch.Size([2, 114])

    edge_attr = np.array(edge_attr, dtype=float)  # 边权重,带宽

    # print(f'前edge_attr-->{edge_attr}')
    # 对边权值按列进行标准化
    scaler_edge = MinMaxScaler()
    # scaler_edge.fit(edge_attr)
    scaler_edge.min, scaler_edge.max = 5e6, 1e8
    edge_attr = scaler_edge.transform(edge_attr)
    edge_attr = edge_attr.reshape(-1, 1)
    # print(f'后edge_attr-->{edge_attr}')
    # breakpoint()
    return edge_nodes_feature, scaler_en, edge_index, edge_attr, scaler_edge


def evaluate_policy(agent):
    times = 3
    evaluate_reward = 0
    for _ in range(times):
        # 每个回合重新读取用户信息和边缘服务器信息
        edge_nodes_feature, scaler_en, edge_index, edge_attr, scaler_edge = read_graph_dataset()
        scaler_for_user, users_data = read_users_dataset()
        gs = GaleShapleyUser(user_file, en_file, num_file, traj_file)
        print('\n\n\n\n')

        # 用一个列表存储所有用户的服务是否完成:t = 0时，默认所有都未完成
        is_complete = [False for i in range(gs.u_num)]

        time_slot = 100
        match_num = 1  # 当前匹配次数
        system_time = 0  # 记录当前的系统时间

        '''
        用户按泊松分布到达
        '''
        arrival_rate = 0.005  # 用户到达的平均频率
        start_time = 200  # 区间的起始时间
        end_time = 1000  # 区间的结束时间

        interval_length = end_time - start_time  # 区间的长度

        expected_arrivals = arrival_rate * interval_length  # 期望到达次数

        arrivals = np.random.poisson(expected_arrivals)  # 生成到达次数
        arrival_times = np.sort(
            np.random.uniform(start_time, end_time, arrivals))  # [333.00916808 340.35106544 983.32026072]
        arrival_index = 0

        episode_return = 0
        transition_dict = {"states_graph": [], "states_user": [], "actions": [], "next_states_graph": [],
                           "next_states_user": [], "rewards": [], "dones": [],
                           "mask": [], "states_en_bw": [], "next_states_en_bw": [], "edge_index": []}

        # 获取初始状态
        state_graph = edge_nodes_feature
        state_user = users_data[0]
        state_en_bw = edge_attr

        # 当有用户的服务没有完成时，不断循环
        # while not all(is_complete):
        done = False
        while not done:

            for user_id in range(gs.u_num):
                # 初始时对所有边缘服务器进行掩码
                mask = np.ones(gs.en_num + 1, dtype=bool)
                # print(mask)

                if gs.user_group[user_id].t == 0:
                    gs.generate_user_favorite_list(user_id)
                    # print(gs.user_group[user_id].favorNum)
                    for en_id in range(gs.en_num):
                        if en_id in gs.user_group[user_id].favorNum:
                            # 会导致用户超出延迟要求的边缘服务器不可选,对于用户请求资源 > 边缘服务器当前可用资源, 这些边缘服务器不能选
                            if (gs.EN_group[en_id].Capacity - gs.EN_group[en_id].curConsumeResources) >= gs.user_group[
                                user_id].cpu_circle:
                                mask[en_id] = False
                    mask = torch.tensor(mask, dtype=torch.bool).to(device).detach()

                    action = agent.choose_action(state_graph, state_user, state_en_bw, edge_index, mask.clone(),epsilon = 0)

                else:
                    # gs.generate_user_favor_list_ignore_onload_latency(user_id,time_slot)
                    # print(gs.user_group[user_id].favorNum)
                    if gs.user_group[user_id].status:
                        mask[:] = True
                    else:
                        for en_id in range(gs.en_num):
                            if en_id in gs.user_group[user_id].favorNum:
                                # 会导致用户超出延迟要求的边缘服务器不可选,对于用户请求资源 > 边缘服务器当前可用资源, 这些边缘服务器不能选
                                if (gs.EN_group[en_id].Capacity - gs.EN_group[en_id].curConsumeResources) >= \
                                        gs.user_group[
                                            user_id].cpu_circle:
                                    mask[en_id] = False
                        mask = torch.tensor(mask, dtype=torch.bool).to(device).detach()

                        action = agent.choose_action(state_graph, state_user, state_en_bw, edge_index, mask.clone(),epsilon = 0)

                mask = torch.tensor(mask, dtype=torch.bool).to(device).detach()

                # action = agent.evaluate(state_graph, state_user, state_en_bw, edge_index, mask.clone())  # 为用户选择边缘服务器,预测时采用确定性动作

                # 更新边缘服务器的状态信息
                if not torch.all(mask):
                    print(f'action--> {action}')
                    gs.user_group[user_id].onload_del = gs.temp_onload_del[user_id][action]  # 更新用户卸载延迟
                    gs.user_group[user_id].cur_en = action  # 更新用户en
                    gs.user_group[user_id].status = True  # 用户当前状态更新为True
                    gs.EN_group[action].currentUsers.append(gs.user_group[user_id])
                    gs.EN_group[action].currentUserNum += 1
                    gs.EN_group[action].curConsumeResources += gs.user_group[user_id].cpu_circle
                    origin_info = scaler_en.inverse_transform(edge_nodes_feature[action])
                    origin_info[3] += gs.user_group[user_id].cpu_circle
                    edge_nodes_feature[action] = scaler_en.transform(origin_info)

                # TODO:更新Env状态信息
                '''
                TODO:更新Env状态信息
                更新边缘服务器的信息，比如占用资源啥的
                '''

                # 对边缘服务器信息和用户信息进行特征提取和特征融合
                if user_id < gs.u_num:
                    next_state_graph = edge_nodes_feature
                    next_state_user = users_data[user_id + 1]
                    next_state_en_bw = edge_attr

                if all(is_complete):
                    done = True
                    total_del_list = []
                    for u in range(gs.u_num):
                        total_del_list.append(gs.user_group[u].total_del)
                    reward = -np.mean(np.array(total_del_list))
                    # episode_return = reward
                else:
                    reward = 0
                    done = False

                transition_dict["states_user"].append(state_user)
                transition_dict["states_graph"].append(state_graph)
                transition_dict["states_en_bw"].append(state_en_bw)
                transition_dict["actions"].append(action)
                transition_dict["next_states_user"].append(next_state_user)
                transition_dict["next_states_graph"].append(next_state_graph)
                transition_dict["next_states_en_bw"].append(next_state_en_bw)
                transition_dict["rewards"].append(reward)
                transition_dict["dones"].append(done)
                transition_dict["mask"].append(mask.clone())
                transition_dict["edge_index"].append(edge_index)

                # 切换到下一个环境状态
                state_user = next_state_user
                state_graph = next_state_graph
                state_en_bw = next_state_en_bw
                episode_return += reward
                if done:
                    break

            for user in gs.user_group:
                # 用户的卸载延迟只和t=0时刻用户卸载的有关(因为用户只在t = 0时卸载)
                if user.t == 0:
                    print(f"userid{user.id}")
                    print(f"curen{user.cur_en}")
                    user.onload_del = gs.temp_onload_del[user.id][user.cur_en]
                    user.cur_mig_del = 0
                    user.total_del = gs.temp_total_del[user.id][user.cur_en]
                    user.cur_com_del = user.last_com_del + gs.temp_com_del[user.id][user.cur_en]
                    user.cur_dl_del = gs.temp_dl_del[user.id][user.cur_en]
                else:
                    user.total_del = gs.temp_total_del[user.id][user.cur_en]
                    user.cur_com_del = gs.temp_com_del[user.id][user.cur_en]
                    user.cur_mig_del = user.last_mig_del + 0 if all(not item for item in gs.temp_mig_del[user.id]) else \
                        gs.temp_mig_del[user.id][user.cur_en]
                    user.cur_dl_del = gs.temp_dl_del[user.id][user.cur_en]

            # TODO:更新系统时间
            system_time += time_slot

            # TODO:更新用户新的坐标
            for u in range(gs.u_num):
                gs.user_group[u].last_loc = gs.user_group[u].loc
                gs.user_group[u].loc = gs.user_group[u].traj[int(gs.user_group[u].t / time_slot) + 1]
                origin_user_info = scaler_for_user.inverse_transform(users_data[u])
                origin_user_info[0] = gs.user_group[u].loc[0]
                origin_user_info[1] = gs.user_group[u].loc[1]
                users_data[u] = scaler_for_user.transform(origin_user_info)

            # TODO:网络产生随机波动
            gs.en_bw = generate_network_bandwidth(mean=80, std_dev=25, n=gs.valid_num)
            for en in range(gs.en_num):
                gs.EN_group[en].bw = float(generate_network_bandwidth(mean=80, std_dev=25, n=1)) * math.pow(10, 6)
                origin_en_bw = scaler_en.inverse_transform(edge_nodes_feature[en])
                origin_en_bw[4] = gs.EN_group[en].bw
                edge_nodes_feature[en] = scaler_en.transform(origin_en_bw)

            kk = 0
            edge_attr2 = []
            for m in range(1, gs.en_num):
                for n in range(m):
                    distance_ap_to_ap2 = np.linalg.norm(x=np.array(gs.EN_group[m].loc) - np.array(gs.EN_group[n].loc),
                                                        ord=2)
                    if distance_ap_to_ap2 < (gs.EN_group[m].radius + gs.EN_group[n].radius):
                        bandwidth = gs.en_bw[kk] * 1e6
                        edge_attr2.append(bandwidth)  # 边权重,带宽
                        edge_attr2.append(bandwidth)  # 边权重,带宽
                    kk = kk + 1
            edge_attr2 = np.array(edge_attr2, dtype=float)
            edge_attr = scaler_edge.transform(edge_attr2)
            edge_attr = edge_attr.reshape(-1, 1)

            '''
             # 判断当前系统时间是否有用户到达，有用户到达则添加到用户组
            '''
            # print(f"第{match_num}轮匹配")
            # print(f"系统时间{system_time}")
            # print(f'help{arrival_times[arrival_index] < system_time and arrival_index < arrival_times.size}')
            while arrival_index < arrival_times.size and arrival_times[arrival_index] < system_time:  # 表明新用户到达
                arrival_index, is_complete = utils.new_user_arrival(traj_file, arrival_index, gs, is_complete)

            # 假设每 timeslot 毫秒检查一次用户服务是否需要迁移
            gs.ap_set_for_u, gs.dist_set = gs.ap_set_for_user()
            gs.ap_for_user = gs.chooseAP()

            for u in range(gs.u_num):
                '''
                # 对于新到达的用户，其还没有托管其服务，先不需要迁移，先为其选择托管服务的边缘服务器
                '''
                if gs.user_group[u].cur_en == np.inf:
                    gs.generate_user_favorite_list(gs.user_group[u].id)
                    print('---------------------------------------------------------')
                    continue
                '''
                 # 对于不是新到达的用户，判断是否需要迁移
                '''
                gs.user_group[u].t += time_slot
                last_ds = gs.user_group[u].data_size
                gs.user_group[u].last_dl_del = gs.user_group[u].cur_dl_del

                if gs.user_group[u].cur_en != np.inf:
                    done_ds = gs.user_group[u].cpu_circle / gs.EN_group[gs.user_group[u].cur_en].comp_power * 8

                # 如果用户剩余数据<一个时隙服务器可以计算的服务数据,则说明用户服务已经完成
                if gs.user_group[u].data_size <= done_ds:
                    gs.user_group[u].done = True
                    gs.user_group[u].data_size = 0
                    # origin_user_data = scaler_for_user.inverse_transform(users_data[u])  # 反向映射回来
                    # origin_user_data[6] = 1e-10
                    # users_data[u] = scaler_for_user.transform(origin_user_data)  # 映射回来
                    is_complete[u] = True
                else:
                    gs.user_group[u].data_size -= done_ds
                    # origin_user_data = scaler_for_user.inverse_transform(users_data[u])  # 反向映射回来
                    # origin_user_data[6] = gs.user_group[u].data_size
                    # users_data[u] = scaler_for_user.transform(origin_user_data)  # 映射回来

                    gs.user_group[u].last_com_del = gs.user_group[u].last_com_del + time_slot \
                        if gs.user_group[u].estimated_remaining_time > time_slot else gs.user_group[u].last_com_del + \
                                                                                      gs.user_group[
                                                                                          u].estimated_remaining_time

                    gs.user_group[u].estimated_remaining_time = \
                        (gs.user_group[u].estimated_remaining_time - time_slot) if gs.user_group[
                                                                                       u].estimated_remaining_time > time_slot else 0

                    # 如果t==0，用户不可能发生迁移
                    if gs.user_group[u].t == 0:
                        gs.user_group[u].last_mig_del = 0
                    else:
                        if gs.user_group[u].this_mig_time <= time_slot:
                            gs.user_group[u].refuse_mig = False
                            gs.user_group[u].this_mig_time = 0
                            gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del
                        else:
                            gs.user_group[u].refuse_mig = True
                            gs.user_group[u].this_mig_time -= time_slot
                            gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del

                    # 判断用户是否需要迁移
                    str1 = "软延迟" if gs.user_group[u].class_for_del == False else "硬延迟"
                    if np.array_equal(gs.user_group[u].loc, gs.user_group[u].last_loc):  # 用户没有移动
                        gs.user_group[u].favorNum = []  # 不需要迁移
                    else:
                        a2u_down_del = gs.user_group[u].res_size / (utils.tr_BU(B=gs.EN_group[gs.ap_for_user[u]].bw,
                                                                                h=gs.EN_group[gs.ap_for_user[u]].h,
                                                                                sigma=1.5 * math.pow(10, -11),
                                                                                p_b=gs.EN_group[gs.ap_for_user[u]].p,
                                                                                r=np.linalg.norm(ord=2, x=np.array(
                                                                                    gs.EN_group[
                                                                                        gs.ap_for_user[
                                                                                            u]].loc) - np.array(
                                                                                    gs.user_group[u].loc))) / math.pow(10,
                                                                                                                       3))

                        down_TDM = utils.get_TDM(gs.en_num, gs.en_bw, gs.EN_group, gs.user_group[u].res_size)
                        down_distance, down_path = dijkstra(down_TDM, gs.ap_for_user[u], gs.user_group[u].cur_en)

                        gs.user_group[u].cur_dl_del = a2u_down_del + down_distance[gs.user_group[u].cur_en]

                        # 如果总延迟超过了用户能接受的最大延迟，则发生迁移
                        delay = gs.user_group[u].onload_del + gs.user_group[u].cur_com_del + gs.user_group[
                            u].cur_mig_del + gs.user_group[u].cur_dl_del

                        '''
                        # 分情况讨论：
                        # 1.如果用户服务是软服务且服务执行程度超过50%,且在软服务最大延迟接收范围内，则可以不迁移
                        # 2.如果用户服务是硬服务，则一旦超越满意延迟范围，则必须迁移
                        '''
                        if gs.user_group[u].class_for_del == 0 and \
                                (gs.user_group[u].init_data_size - gs.user_group[u].data_size) / gs.user_group[
                            u].init_data_size >= 0.5 \
                                and delay <= gs.user_group[u].max_serv_del:
                            # print(f'软延迟服务，执行程度超过50%，不需要迁移')
                            continue
                        elif gs.user_group[u].class_for_del == 0 and delay <= gs.user_group[u].satisfied_serv_del:
                            # print(f'软延迟服务，未超过最优服务体验范围，不需要迁移')
                            continue
                        elif gs.user_group[u].class_for_del == 1 and delay <= gs.user_group[u].satisfied_serv_del:
                            # print(f'硬延迟服务，未超过延迟范围，不需要迁移')
                            continue
                        else:
                            # if delay > gs.user_group[u].max_serv_del:
                            # print(f'{gs.user_group[u].id}-->发生迁移')
                            '''
                                # 修改用户和托管其服务的原服务器的状态
                            '''
                            utils.modify_state(gs, u)

                            '''
                                重新计算用户的偏好列表
                            '''
                            gs.generate_user_favor_list_ignore_onload_latency(u, time_slot)

        evaluate_reward += episode_return

    return evaluate_reward / times
