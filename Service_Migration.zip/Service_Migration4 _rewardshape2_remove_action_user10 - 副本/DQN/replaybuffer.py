from collections import deque

import torch
import numpy as np


class ReplayBuffer:
    def __init__(self, args, device): # 经验池容量
        self.device = device
        self.batch_size = args.batch_size
        self.buffer_capacity = int(args.buffer_capacity)
        self.current_size = 0
        self.count = 0
        self.buffer = {
                        'state_graph':np.zeros((self.buffer_capacity, 25, args.en_graph_dim)),
                        'state_user':np.zeros((self.buffer_capacity, args.user_information_dim)),
                        'state_en_bw': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 1)),
                         'action':np.zeros((self.buffer_capacity, 1)),
                         'reward':  np.zeros((self.buffer_capacity,)),
                        'next_state_graph': np.zeros((self.buffer_capacity, 25, args.en_graph_dim)),
                        'next_state_user': np.zeros((self.buffer_capacity, args.user_information_dim)),
                        'next_state_en_bw': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 1)),
                        'done': np.zeros((self.buffer_capacity, 1)),
                        'mask': np.zeros((self.buffer_capacity, args.action_dim), dtype=bool),
                        'edge_index': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 2), dtype=np.long),
                        'terminal': np.zeros(self.buffer_capacity),
        }
    def store_transition(self,state_user, state_graph, state_en_bw, action, reward, next_state_user, next_state_graph,
              next_state_en_bw, done, mask, edge_index,terminal):
        self.buffer['state_graph'][self.count] = state_graph
        self.buffer['state_user'][self.count] = state_user
        self.buffer['state_en_bw'][self.count] = state_en_bw
        self.buffer['action'][self.count] = action
        self.buffer['reward'][self.count] = reward
        self.buffer['next_state_graph'][self.count] = next_state_graph
        self.buffer['next_state_user'][self.count] = next_state_user
        self.buffer['next_state_en_bw'][self.count] = next_state_en_bw
        self.buffer['done'][self.count] = done
        self.buffer['mask'][self.count] = mask.cpu().numpy()
        self.buffer['edge_index'][self.count] = edge_index
        self.buffer['terminal'][self.count] = terminal
        self.count = (self.count + 1) % self.buffer_capacity  # When the 'count' reaches buffer_capacity, it will be reset to 0.
        self.current_size = min(self.current_size + 1, self.buffer_capacity)

    def sample(self, total_steps):
        index = np.random.randint(0, self.current_size, size=self.batch_size)
        batch = {}
        for key in self.buffer.keys():  # numpy->tensor
            if key == 'action':
                batch[key] = torch.tensor(self.buffer[key][index], dtype=torch.long).to(self.device)
            elif key == 'edge_index':
                batch[key] = torch.tensor(self.buffer[key][index], dtype=torch.long).to(self.device)
            else:
                batch[key] = torch.tensor(self.buffer[key][index], dtype=torch.float32).to(self.device)

        return batch, None, None
    def numpy_to_tensor(self):
        state_graph = torch.tensor(self.state_graph, dtype=torch.float).to(self.device)
        state_user = torch.tensor(self.state_user, dtype=torch.float).to(self.device)
        state_en_bw = torch.tensor(self.state_en_bw, dtype=torch.float).to(self.device)
        action = torch.tensor(self.action, dtype=torch.long).to(
            self.device)  # In discrete action space, 'a' needs to be torch.long
        action_logprob = torch.tensor(self.action_logprob, dtype=torch.float).to(self.device)
        reward = torch.tensor(self.reward, dtype=torch.float).to(self.device)
        next_state_graph = torch.tensor(self.next_state_graph, dtype=torch.float).to(self.device)
        next_state_user = torch.tensor(self.next_state_user, dtype=torch.float).to(self.device)
        next_state_en_bw = torch.tensor(self.next_state_en_bw, dtype=torch.float).to(self.device)
        dw = torch.tensor(self.dw, dtype=torch.float).to(self.device)
        done = torch.tensor(self.done, dtype=torch.float).to(self.device)
        mask = torch.tensor(self.mask, dtype=torch.bool).to(self.device)
        edge_index = torch.tensor(self.edge_index[0], dtype=torch.long).to(self.device)

        return state_user, state_graph, state_en_bw, action, action_logprob, reward, next_state_user, next_state_graph, next_state_en_bw, dw, done, mask, edge_index







class N_Steps_ReplayBuffer(object):
    def __init__(self, args):
        self.gamma = args.gamma
        self.batch_size = self.buffer_capacity
        self.buffer_capacity = args.buffer_capacity
        self.current_size = 0
        self.count = 0
        self.n_steps = args.n_steps
        self.n_steps_deque = deque(maxlen=self.n_steps)
        self.buffer = {
            'state_graph': np.zeros((self.buffer_capacity, 25, args.en_graph_dim)),
            'state_user': np.zeros((self.buffer_capacity, args.user_information_dim)),
            'state_en_bw': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 1)),
            'action': np.zeros((self.buffer_capacity, 1)),
            'reward': np.zeros((self.buffer_capacity, )),
            'next_state_graph': np.zeros((self.buffer_capacity, 25, args.en_graph_dim)),
            'next_state_user': np.zeros((self.buffer_capacity, args.user_information_dim)),
            'next_state_en_bw': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 1)),
            'done': np.zeros((self.buffer_capacity, 1)),
            'mask': np.zeros((self.buffer_capacity, args.action_dim), dtype=bool),
            'edge_index': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 2), dtype=np.long),
            'terminal': np.zeros(self.buffer_capacity),
        }

    def store_transition(self,state_user, state_graph, state_en_bw, action, reward, next_state_user, next_state_graph,
              next_state_en_bw, done, mask, edge_index,terminal):
        transition = (state_user, state_graph, state_en_bw, action, reward, next_state_user, next_state_graph,
              next_state_en_bw, done, mask, edge_index,terminal)
        self.n_steps_deque.append(transition)
        if len(self.n_steps_deque) == self.n_steps:
            state_user, state_graph, state_en_bw, action, reward, next_state_user, next_state_graph,\
            next_state_en_bw, done, mask, edge_index, terminal = self.get_n_steps_transition()

            self.buffer['state_graph'][self.count] = state_graph
            self.buffer['state_user'][self.count] = state_user
            self.buffer['state_en_bw'][self.count] = state_en_bw
            self.buffer['action'][self.count] = action
            self.buffer['reward'][self.count] = reward
            self.buffer['next_state_graph'][self.count] = next_state_graph
            self.buffer['next_state_user'][self.count] = next_state_user
            self.buffer['next_state_en_bw'][self.count] = next_state_en_bw
            self.buffer['done'][self.count] = done
            self.buffer['mask'][self.count] = mask
            self.buffer['edge_index'][self.count] = edge_index
            self.buffer['terminal'][self.count] = terminal
            self.count = (self.count + 1) % self.buffer_capacity  # When the 'count' reaches buffer_capacity, it will be reset to 0.
            self.current_size = min(self.current_size + 1, self.buffer_capacity)

    def get_n_steps_transition(self):
        state_user, state_graph, state_en_bw, action = self.n_steps_deque[0][:4]
        next_state_user, next_state_graph, next_state_en_bw, terminal = self.n_steps_deque[-1][5:9]
        n_steps_reward = 0
        for i in reversed(range(self.n_steps)):
            r, _, _, d, _ = self.n_steps_deque[i][4:]  # 使用 "_" 占位未使用的元素
            n_steps_reward = r + self.gamma * (1 - d) * n_steps_reward
            if d:
                next_state_user, next_state_graph, next_state_en_bw, terminal = self.n_steps_deque[i][5:9]

        return state_user, state_graph, state_en_bw, action, n_steps_reward, next_state_user, next_state_graph, \
               next_state_en_bw, terminal

    def sample(self, total_steps):
        index = np.random.randint(0, self.current_size, size=self.batch_size)
        batch = {}
        for key in self.buffer.keys():  # numpy->tensor
            if key == 'action':
                batch[key] = torch.tensor(self.buffer[key][index], dtype=torch.long)
            else:
                batch[key] = torch.tensor(self.buffer[key][index], dtype=torch.float32)

        return batch, None, None




from sum_tree import SumTree
class Prioritized_ReplayBuffer(object):
    def __init__(self, args,device):
        self.device = device
        self.max_train_steps = args.max_train_steps
        self.alpha = args.alpha
        self.beta_init = args.beta_init
        self.beta = args.beta_init
        self.buffer_capacity = int(args.buffer_capacity)
        self.batch_size = args.batch_size
        self.sum_tree = SumTree(self.buffer_capacity)
        self.current_size = 0
        self.count = 0
        self.buffer = {
            'state_graph': np.zeros((self.buffer_capacity, 25, args.en_graph_dim)),
            'state_user': np.zeros((self.buffer_capacity, args.user_information_dim)),
            'state_en_bw': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 1)),
            'action': np.zeros((self.buffer_capacity, 1)),
            'reward': np.zeros((self.buffer_capacity,)),
            'next_state_graph': np.zeros((self.buffer_capacity, 25, args.en_graph_dim)),
            'next_state_user': np.zeros((self.buffer_capacity, args.user_information_dim)),
            'next_state_en_bw': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 1)),
            'done': np.zeros((self.buffer_capacity, 1)),
            'mask': np.zeros((self.buffer_capacity, args.action_dim), dtype=bool),
            'edge_index': np.zeros((self.buffer_capacity, args.state_en_bw_dim, 2), dtype=np.long),
            'terminal': np.zeros(self.buffer_capacity),
        }

    def store_transition(self, state_user, state_graph, state_en_bw, action, reward, next_state_user, next_state_graph,
                         next_state_en_bw, done, mask, edge_index, terminal):
        self.buffer['state_graph'][self.count] = state_graph
        self.buffer['state_user'][self.count] = state_user
        self.buffer['state_en_bw'][self.count] = state_en_bw
        self.buffer['action'][self.count] = action
        self.buffer['reward'][self.count] = reward
        self.buffer['next_state_graph'][self.count] = next_state_graph
        self.buffer['next_state_user'][self.count] = next_state_user
        self.buffer['next_state_en_bw'][self.count] = next_state_en_bw
        self.buffer['done'][self.count] = done
        self.buffer['mask'][self.count] = mask.cpu().numpy()
        self.buffer['edge_index'][self.count] = edge_index
        self.buffer['terminal'][self.count] = terminal
        # 如果是第一条经验，初始化优先级为1.0；否则，对于新存入的经验，指定为当前最大的优先级
        priority = 1.0 if self.current_size == 0 else self.sum_tree.priority_max
        self.sum_tree.update(data_index=self.count, priority=priority)  # 更新当前经验在sum_tree中的优先级
        self.count = (self.count + 1) % self.buffer_capacity  # When the 'count' reaches buffer_capacity, it will be reset to 0.
        self.current_size = min(self.current_size + 1, self.buffer_capacity)

    def sample(self, total_steps):
        batch_index, IS_weight = self.sum_tree.get_batch_index(current_size=self.current_size, batch_size=self.batch_size, beta=self.beta)
        self.beta = self.beta_init + (1 - self.beta_init) * (total_steps / self.max_train_steps)  # beta：beta_init->1.0
        batch = {}
        for key in self.buffer.keys():  # numpy->tensor
            if key == 'action':
                batch[key] = torch.tensor(self.buffer[key][batch_index], dtype=torch.long).to(self.device)
            elif key == 'edge_index':
                batch[key] = torch.tensor(self.buffer[key][batch_index], dtype=torch.long).to(self.device)
            else:
                batch[key] = torch.tensor(self.buffer[key][batch_index], dtype=torch.float32).to(self.device)

        return batch, batch_index, IS_weight

    def update_batch_priorities(self, batch_index, td_errors):  # 根据传入的td_error，更新batch_index所对应数据的priorities
        priorities = (np.abs(td_errors) + 0.01) ** self.alpha
        for index, priority in zip(batch_index, priorities):
            self.sum_tree.update(data_index=index, priority=priority)


class N_Steps_Prioritized_ReplayBuffer(object):
    def __init__(self, args):
        self.max_train_steps = args.max_train_steps
        self.alpha = args.alpha
        self.beta_init = args.beta_init
        self.beta = args.beta_init
        self.gamma = args.gamma
        self.batch_size = self.buffer_capacity
        self.buffer_capacity = args.buffer_capacity
        self.sum_tree = SumTree(self.buffer_capacity)
        self.n_steps = args.n_steps
        self.n_steps_deque = deque(maxlen=self.n_steps)
        self.buffer = {'state': np.zeros((self.buffer_capacity, args.state_dim)),
                       'action': np.zeros((self.buffer_capacity, 1)),
                       'reward': np.zeros(self.buffer_capacity),
                       'next_state': np.zeros((self.buffer_capacity, args.state_dim)),
                       'terminal': np.zeros(self.buffer_capacity),
                       }
        self.current_size = 0
        self.count = 0

    def store_transition(self, state, action, reward, next_state, terminal, done):
        transition = (state, action, reward, next_state, terminal, done)
        self.n_steps_deque.append(transition)
        if len(self.n_steps_deque) == self.n_steps:
            state, action, n_steps_reward, next_state, terminal = self.get_n_steps_transition()
            self.buffer['state'][self.count] = state
            self.buffer['action'][self.count] = action
            self.buffer['reward'][self.count] = n_steps_reward
            self.buffer['next_state'][self.count] = next_state
            self.buffer['terminal'][self.count] = terminal
            # 如果是buffer中的第一条经验，那么指定priority为1.0；否则对于新存入的经验，指定为当前最大的priority
            priority = 1.0 if self.current_size == 0 else self.sum_tree.priority_max
            self.sum_tree.update(data_index=self.count, priority=priority)  # 更新当前经验在sum_tree中的优先级
            self.count = (self.count + 1) % self.buffer_capacity  # When 'count' reaches buffer_capacity, it will be reset to 0.
            self.current_size = min(self.current_size + 1, self.buffer_capacity)

    def sample(self, total_steps):
        batch_index, IS_weight = self.sum_tree.get_batch_index(current_size=self.current_size, batch_size=self.batch_size, beta=self.beta)
        self.beta = self.beta_init + (1 - self.beta_init) * (total_steps / self.max_train_steps)  # beta：beta_init->1.0
        batch = {}
        for key in self.buffer.keys():  # numpy->tensor
            if key == 'action':
                batch[key] = torch.tensor(self.buffer[key][batch_index], dtype=torch.long)
            else:
                batch[key] = torch.tensor(self.buffer[key][batch_index], dtype=torch.float32)

        return batch, batch_index, IS_weight

    def get_n_steps_transition(self):
        state, action = self.n_steps_deque[0][:2]  # 获取deque中第一个transition的s和a
        next_state, terminal = self.n_steps_deque[-1][3:5]  # 获取deque中最后一个transition的s'和terminal
        n_steps_reward = 0
        for i in reversed(range(self.n_steps)):  # 逆序计算n_steps_reward
            r, s_, ter, d = self.n_steps_deque[i][2:]
            n_steps_reward = r + self.gamma * (1 - d) * n_steps_reward
            if d:  # 如果done=True，说明一个回合结束，保存deque中当前这个transition的s'和terminal作为这个n_steps_transition的next_state和terminal
                next_state, terminal = s_, ter

        return state, action, n_steps_reward, next_state, terminal

    def update_batch_priorities(self, batch_index, td_errors):  # 根据传入的td_error，更新batch_index所对应数据的priorities
        priorities = (np.abs(td_errors) + 0.01) ** self.alpha
        for index, priority in zip(batch_index, priorities):
            self.sum_tree.update(data_index=index, priority=priority)