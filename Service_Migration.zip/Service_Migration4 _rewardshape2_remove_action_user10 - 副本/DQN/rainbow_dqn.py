import torch
import numpy as np
import copy

from torch_geometric.data import Data, Batch

from network import Dueling_Net, Net


class DQN(object):
    def __init__(self, args, device):
        self.action_dim = args.action_dim
        self.batch_size = args.batch_size  # batch size
        self.max_train_steps = args.max_train_steps
        self.lr = args.lr  # learning rate
        self.gamma = args.gamma  # discount factor
        self.tau = args.tau  # Soft update
        self.use_soft_update = args.use_soft_update
        self.target_update_freq = args.target_update_freq  # hard update
        self.update_count = 0
        self.device = device
        self.grad_clip = args.grad_clip
        self.use_lr_decay = args.use_lr_decay
        self.use_double = args.use_double
        self.use_dueling = args.use_dueling
        self.use_per = args.use_per
        self.use_n_steps = args.use_n_steps
        if self.use_n_steps:
            self.gamma = self.gamma ** args.n_steps

        if self.use_dueling:  # Whether to use the 'dueling network'
            self.net = Dueling_Net(args, self.device)
        else:
            self.net = Net(args, self.device)

        self.target_net = copy.deepcopy(self.net)  # Copy the online_net to the target_net

        self.optimizer = torch.optim.Adam(self.net.parameters(), lr=self.lr)

    def choose_action(self, state_graph, state_user, state_en_bw, edge_index, mask, epsilon):
        with torch.no_grad():
            # 定义节点特征
            edge_nodes_feature = torch.tensor(data=state_graph, dtype=torch.float).to(self.device)  # torch.Size([25, 5])
            edge_index = torch.tensor(edge_index, dtype=torch.long).to(self.device)  # torch.Size([114, 2])
            edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([2, 114])
            edge_attr = torch.tensor(state_en_bw, dtype=torch.float).to(self.device)  # 边权重,带宽
            en_graph_data = Data(x=edge_nodes_feature, edge_index=edge_index_,
                                 edge_attr=edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
            en_graph_data = en_graph_data.to(self.device)
            state_user = torch.tensor(state_user, dtype=torch.float).to(self.device)
            state = [en_graph_data, state_user]
            # print(f'en_graph_data-->{en_graph_data}')
            # print(f'state_user-->{state_user}')

            # if torch.all(mask == True):
            #     return mask.shape[0] - 1

            q = self.net(state)
            # print(q)
            # print(torch.sum(q))

            fixed_q = torch.where(mask == True, torch.tensor(-torch.inf, dtype=torch.float, device=self.device), q).to(
                self.device)

            # print(f'fixed_q--{fixed_q}')

            if np.random.uniform() > epsilon:
                action = fixed_q.argmax(dim=-1).item()
            else:
                if torch.all(mask == True):
                    action = torch.tensor(mask.shape[0] - 1).to(self.device)
                else:
                    # 从可选的动作中随机选择一个
                    valid_indices = torch.arange(len(mask), device=self.device)[~mask].to(self.device)
                    selected_action = np.random.randint(len(valid_indices))
                    action = valid_indices[selected_action].item()

                # action = np.random.randint(0, self.action_dim)
                # print(f'valid_indices{valid_indices}')
                # print(f"selected_action{selected_action}")
                # print(f"action{action}")
            return action

    def learn(self, replay_buffer, total_steps):
        batch, batch_index, IS_weight = replay_buffer.sample(total_steps)
        state_user = batch['state_user']
        state_graph = batch['state_graph']
        state_en_bw = batch['state_en_bw']
        next_state_user = batch['next_state_user']
        next_state_graph = batch['next_state_graph']
        next_state_en_bw = batch['next_state_en_bw']
        edge_index = batch['edge_index'][0]
        edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([114, 2] --》torch.Size([2, 114])
        states_graph_data_list = []
        for state_id in range(state_graph.shape[0]):
            edge_nodes_feature = state_graph[state_id]  # torch.Size([25, 4])

            edge_attr = state_en_bw[state_id]  # 边权重,带宽
            # print(edge_attr.shape)
            # breakpoint()

            en_graph_data = Data(x=edge_nodes_feature, edge_index=edge_index_,
                                 edge_attr=edge_attr)  # Data(x=[25,4], edge_index=[2, 114])
            en_graph_data = en_graph_data.to(self.device)
            states_graph_data_list.append(en_graph_data)
        # print(len(graph_data_list))
        # print(graph_data_list)
        states_batch = Batch.from_data_list(states_graph_data_list)
        states = [states_batch, state_user]

        next_states_graph_data_list = []
        for state_id in range(next_state_graph.shape[0]):
            next_state_edge_nodes_feature = next_state_graph[state_id]  # torch.Size([25, 4])

            next_state_edge_attr = next_state_en_bw[state_id]  # 边权重,带宽

            next_state_en_graph_data = Data(x=next_state_edge_nodes_feature, edge_index=edge_index_,
                                            edge_attr=next_state_edge_attr)  # Data(x=[25,4], edge_index=[2, 114])
            next_state_en_graph_data = next_state_en_graph_data.to(self.device)
            next_states_graph_data_list.append(next_state_en_graph_data)
        # print(len(graph_data_list))
        # print(graph_data_list)
        next_states_batch = Batch.from_data_list(next_states_graph_data_list)
        next_states = [next_states_batch, next_state_user]

        with torch.no_grad():  # q_target has no gradient
            if self.use_double:  # Whether to use the 'double q-learning'
                # Use online_net to select the action
                a_argmax = self.net(next_states).argmax(dim=-1, keepdim=True).to(self.device) # shape：(batch_size,1)
                # Use target_net to estimate the q_target
                q_target = batch['reward'] + self.gamma * (1 - batch['terminal']) * self.target_net(next_states).gather(
                    -1, a_argmax).squeeze(-1) .to(self.device) # shape：(batch_size,)
            else:
                q_target = batch['reward'] + self.gamma * (1 - batch['terminal']) * \
                           self.target_net(next_states).max(dim=-1)[0].to(self.device)  # shape：(batch_size,)

        q_current = self.net(states).gather(-1, batch['action']).squeeze(-1).to(self.device)  # shape：(batch_size,)
        td_errors = (q_current - q_target).to(self.device)  # shape：(batch_size,)


        if self.use_per:

            self.loss = (IS_weight.to(self.device) * (td_errors ** 2)).mean().to(self.device)
            replay_buffer.update_batch_priorities(batch_index, td_errors.detach().cpu().numpy())
        else:
            self.loss = (td_errors ** 2).mean()

        self.optimizer.zero_grad()
        self.loss.backward()
        if self.grad_clip:
            torch.nn.utils.clip_grad_norm_(self.net.parameters(), self.grad_clip)
        self.optimizer.step()

        if self.use_soft_update:  # soft update
            for param, target_param in zip(self.net.parameters(), self.target_net.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        else:  # hard update
            self.update_count += 1
            if self.update_count % self.target_update_freq == 0:
                self.target_net.load_state_dict(self.net.state_dict())

        if self.use_lr_decay:  # learning rate Decay
            self.lr_decay(total_steps)

    def lr_decay(self, total_steps):
        lr_now = 0.9 * self.lr * (1 - total_steps / self.max_train_steps) + 0.1 * self.lr
        for p in self.optimizer.param_groups:
            p['lr'] = lr_now
