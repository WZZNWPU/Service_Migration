# 北京 天津 郑州 济南 长沙 海南
# 0    1    2    3    4    5

# 模拟从文件中读入图的各个路径
a = """
0 1 500
0 2 100
1 2 900
1 3 300
2 3 400
2 4 500
3 4 1300
3 5 1400
4 5 1500
"""

INF = float('inf')

# 定义邻接矩阵 记录各城市之间的距离
weight = [[INF if j != i else 0 for j in range(6)] for i in range(6)]
print(f'weight-->\n{weight}')

print(a.split('\n'))
# 解析数据
b = [[int(i) for i in i.split(' ')] for i in a.split('\n') if i != '']
print(f"b-->{b}")

for i in b:
    weight[i[0]][i[1]] = i[2]
    weight[i[1]][i[0]] = i[2]

print(f"weight-->{weight}")


def floyd(src, target):
    path = [[j for j in range(6)] for i in range(6)]

    for k in range(6):
        for j in range(6):
            for i in range(6):
                if weight[i][k] + weight[k][j] < weight[i][j]:
                    weight[i][j] = weight[i][k] + weight[k][j]
                    # 记录经过的点
                    path[i][j] = path[i][k]

    # 输出最短路径的各个节点
    i = src
    while i != target:
        print(i, end="->")
        i = path[i][target]
    print(target)

    return weight[src][target]


testi = 0
testj = 5

print(floyd(testi, testj))

