
def floyd(src, target,weight,num):
    path = [[j for j in range(num)] for i in range(num)]

    for k in range(num):
        for j in range(num):
            for i in range(num):
                if weight[i][k] + weight[k][j] < weight[i][j]:
                    weight[i][j] = weight[i][k] + weight[k][j]
                    # 记录经过的点
                    path[i][j] = path[i][k]

    # print(f"\nweight--->\n{weight}\n")

    # 输出最短路径的各个节点
    i = src
    while i != target:
        print(i, end="->")
        i = path[i][target]
    print(target)

    return weight[src][target]


# testi = 1
# testj = 4
#
# floyd(testi, testj)