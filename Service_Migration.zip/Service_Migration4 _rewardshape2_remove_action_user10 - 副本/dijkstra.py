import heapq
import numpy as np


def dijkstra(matrix, start, end):
    num_nodes = len(matrix)
    heap = []
    distances = np.full(num_nodes, float('inf'))
    distances[start] = 0
    heapq.heappush(heap, (distances[start], start))
    # 使用一个字典来记录每个节点的前驱节点，以构建最短路径
    predecessors = {}

    while heap:
        current_distance, current_node = heapq.heappop(heap)
        if current_distance > distances[current_node]:
            continue
        for neighbor in range(num_nodes):
            weight = matrix[current_node][neighbor]
            if weight > 0:
                distance = current_distance + weight
                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    heapq.heappush(heap, (distance, neighbor))
                    predecessors[neighbor] = current_node

    # 构建最短路径
    path = [end]
    while end != start:
        end = predecessors[end]
        path.insert(0, end)

    return distances, path


if __name__ == '__main__':
    # # 北京 天津 郑州 济南 长沙 海南
    # # 0    1    2    3    4    5
    #
    # # 模拟从文件中读入图的各个路径
    # a = """
    # 0 1 500
    # 0 2 100
    # 1 2 900
    # 1 3 300
    # 2 3 400
    # 2 4 500
    # 3 4 1300
    # 3 5 1400
    # 4 5 1500
    # """
    #
    # INF = float('inf')
    #
    # # 定义邻接矩阵 记录各城市之间的距离
    # weight = [[INF if j != i else 0 for j in range(6)] for i in range(6)]
    # print(f'weight-->\n{weight}')
    #
    # print(a.split('\n'))
    # # 解析数据
    # b = [[int(i) for i in i.split(' ')] for i in a.split('\n') if i != '']
    # print(f"b-->{b}")
    #
    # for i in b:
    #     weight[i[0]][i[1]] = i[2]
    #     weight[i[1]][i[0]] = i[2]

    weight = np.array([[0,500,100,np.inf,np.inf,np.inf],
                       [500,0,900,300,np.inf,np.inf],
                       [100,900,0,400,500,np.inf],
                       [np.inf,300,400,0,1300,1400],
                       [np.inf,np.inf,1300,np.inf,0,1500],
                       [np.inf,np.inf,np.inf,1400,1500,0]])


    print(f"weight-->{weight}")

    print(dijkstra(weight, 0,5))
    print(dijkstra(weight, 0, 4))
