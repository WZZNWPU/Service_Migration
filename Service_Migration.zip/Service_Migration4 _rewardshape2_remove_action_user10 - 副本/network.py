from random import random

import numpy as np
from scipy.stats import truncnorm


def generate_network_bandwidth(mean,std_dev,n):
    lower_bound = 0
    upper_bound = 100
    # bandwidths = np.random.normal(mean, std_dev, n)  # 使用正态分布生成网络带宽
    bandwidths = truncnorm((lower_bound - mean) / std_dev, (upper_bound - mean) / std_dev, loc=mean, scale=std_dev).rvs(
        size=n)

    return bandwidths

# 示例：使用5个信道，仿真总时长为10秒，保证每次仿真结果一致，但每个时刻的网络带宽不同
n = 20
mean = 70
std_dev = 40
simulation_duration = 10
random_seed = 42

np.random.seed(random_seed)  # 设置随机种子

for _ in range(simulation_duration):
    bandwidths = generate_network_bandwidth(mean,std_dev,n)
    print("网络带宽：", bandwidths)
