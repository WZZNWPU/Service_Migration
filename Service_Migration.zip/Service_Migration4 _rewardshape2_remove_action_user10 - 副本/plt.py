import math

import matplotlib.pyplot as plt

# 分贝为-127dbm 噪声功率为
import numpy as np

from StableMatch.utils import PL_A2A, tr_UU, tr_UB, tr_BU

B = 100 * math.pow(10, 6)
sigma =1.5 * math.pow(10, -11)
d = 1000
p_u = 10
d = np.arange(100,1501)
tr_u2u = []
tr_b2u = []
tr_u2b = []
for i in range(d.size):
    tr_u2u.append(tr_UU(B, sigma, d[i], p_u = 100)/1e6)
    tr_b2u.append(tr_BU(B, d[i], 50, sigma, p_b = 100)/1e6)
    tr_u2b.append(tr_UB(B, d[i], 50, sigma, p_u = 1)/1e6)


print(tr_b2u)
plt.figure(figsize=(4, 4))
plt.figure(dpi=500)
plt.title("Variation of Transfer Rate with Distance")
plt.xlabel("Distance(meters)", fontsize=12)
plt.ylabel("Transmission_rate(Mbps)", fontsize=12)
plt.plot(d,tr_u2u,label="A2A")
plt.plot(d,tr_b2u,label="A2G")
plt.plot(d,tr_u2b,label="A2G_2")
plt.legend()
plt.show()

import torch

# 假设你有两个边缘服务器，每个服务器有三个特征值
num_servers = 2
num_features = 3

# 生成示例特征值
server1_features = [1.0, 2.0, 3.0]
server2_features = [4.0, 5.0, 6.0]

# 定义输入矩阵
input_matrix = torch.tensor([server1_features, server2_features], dtype=torch.float)

# 打印输入矩阵的形状
print(input_matrix.shape)
