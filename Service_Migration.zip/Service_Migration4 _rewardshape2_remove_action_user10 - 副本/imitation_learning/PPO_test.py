import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from torch.distributions import Categorical
from torch.nn import init
from torch.optim.lr_scheduler import ExponentialLR
from torch.utils.data import BatchSampler, SubsetRandomSampler
import torch_geometric.nn as geo_nn
from collections import deque
from torch_geometric.data import Data, Batch
# 环境是自建的任务迁移环境
from tqdm import tqdm
# 恢复默认的打印选项
np.set_printoptions(threshold=None)

# Trick 8: orthogonal initialization 正交初始化
def orthogonal_init(layer, gain=1.0):
    nn.init.orthogonal_(layer.weight, gain=gain)
    nn.init.constant_(layer.bias, 0)


# 定义图神经网络模块
class GraphNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, device):
        super(GraphNetwork, self).__init__()

        self.conv1 = geo_nn.GCNConv(input_dim, hidden_dim).to(device)
        self.relu = nn.ReLU().to(device)
        self.conv2 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv3 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv4 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv5 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv6 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv7 = geo_nn.GCNConv(128, output_dim).to(device)

        # self.conv1 = geo_nn.GMMConv(input_dim, hidden_dim,aggr='mean',dim=1, kernel_size=8 ).to(device)
        # self.relu = nn.ReLU().to(device)
        # self.conv2 = geo_nn.GMMConv(hidden_dim, 128,aggr='mean',dim=1, kernel_size=8 ).to(device)
        # self.conv3 = geo_nn.GMMConv(hidden_dim, 128,aggr='mean',dim=1, kernel_size=8 ).to(device)
        # self.conv4 = geo_nn.GMMConv(hidden_dim, 128,aggr='mean',dim=1, kernel_size=8).to(device)
        # self.conv5 = geo_nn.GMMConv(hidden_dim, 128,aggr='mean',dim=1, kernel_size=8).to(device)
        # self.conv6 = geo_nn.GMMConv(hidden_dim, 128,aggr='mean',dim=1, kernel_size=8).to(device)
        # self.conv7 = geo_nn.GMMConv(128, output_dim,aggr='mean',dim=1, kernel_size=8).to(device)

        self.init_parameters()

    def init_parameters(self):
        # Xavier初始化conv1的权重和偏置
        init.orthogonal_(self.conv1.lin.weight)
        init.zeros_(self.conv1.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv2.lin.weight)
        init.zeros_(self.conv2.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv3.lin.weight)
        init.zeros_(self.conv3.bias)

        # Xavier初始化conv2的权重和偏置
        init.xavier_uniform_(self.conv4.lin.weight)
        init.zeros_(self.conv4.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv5.lin.weight)
        init.zeros_(self.conv5.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv6.lin.weight)
        init.zeros_(self.conv6.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv7.lin.weight)
        init.zeros_(self.conv7.bias)




    # def init_parameters(self):
    #     for conv in [self.conv1, self.conv2, self.conv3, self.conv4, self.conv5]:
    #         if hasattr(conv, 'weight') and conv.weight is not None:
    #             if conv.weight.requires_grad:
    #                 init.orthogonal_(conv.weight, gain=init.calculate_gain('relu'))

    # def init_parameters(self):
    #     for name, param in self.named_parameters():
    #         if "weight" in name:
    #             init.orthogonal_(param.data)


    def forward(self, x, edge_index, edge_attr):
        residual = x  # 保存原始输入作为残差连接
        x = self.conv1(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv2(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv3(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv4(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv5(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv6(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv7(x, edge_index, edge_attr)
        x += residual  # 添加残差连接
        return x


# 定义PolicyNet类，实现PolicyNet网络
class PolicyNet(nn.Module):
    def __init__(self, en_graph_dim, user_information_dim, state_dim, action_dim, device):
        super(PolicyNet, self).__init__()
        # 对状态信息进行特征提取
        self.gcn = GraphNetwork(en_graph_dim, hidden_dim=128, output_dim=5, device=device)  # 采用图卷积提取边缘节点的特征

        self.feature_extractor = nn.Sequential(  # 采用全连接神经网络提取用户的信息特征
            nn.Linear(user_information_dim, 128).to(device),
            nn.ReLU(),
            nn.Linear(128, 128).to(device),
            nn.ReLU(),
            nn.Linear(128, 128).to(device),
            nn.ReLU(),
            nn.Linear(128, 4).to(device)
        )

        self.feature_extractor2 = nn.Sequential(  # 采用全连接神经网络提取图卷积后的信息特征
            nn.Linear(25 * 5, 256).to(device),
            nn.ReLU(),
            nn.Linear(256, 256).to(device),
            nn.ReLU(),
            nn.Linear(256, 256).to(device),
            nn.ReLU(),
            nn.Linear(256, 64).to(device)
        )

        # 输出动作
        self.fc1 = nn.Linear(state_dim, 128).to(device)  # 输入层
        self.dropout = nn.Dropout(0.0)
        self.fc2 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc3 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc4 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc5 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc6 = nn.Linear(128, 128).to(device)  # 隐藏层
        self.fc7 = nn.Linear(128, action_dim).to(device)  # 输出层
        # 初始化参数
        self.init_parameters()

    def init_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        graph_data, user_information = x[0], x[1]
        nodes_ferature, edge_index, edge_attr = graph_data.x, graph_data.edge_index, graph_data.edge_attr
        batchsize = int(nodes_ferature.shape[0] / 25)
        # print(f'nodes_ferature-->{nodes_ferature}')
        # print(f'user_information-->{user_information}')
        # print(f'edge_attr-->{edge_attr}')

        output1 = self.gcn(nodes_ferature, edge_index, edge_attr)  # output1-->torch.Size([25, 64])
        # print(f'output1-->{output1}')
        output2 = self.feature_extractor(user_information)  # output2-->torch.Size([64])
        # print(f'output2-->{output2}')
        # 将特征图展品 25*16--->400
        if batchsize > 1:
            output3 = output1.clone().view(batchsize, -1)  # output1-->torch.Size([1600])
        else:
            output3 = output1.clone().view(-1)
        # print(f'output3-->{output3}')
        # 对展平后的向量提取特征
        output4 = self.feature_extractor2(output3.clone())
        # print(f'outpu t4-->{output4.shape}')
        # print(f'output2-->{output2.shape}')
        # 进行向量拼接 (192,)
        output5 = torch.cat((output4, output2), dim=-1)  # 特征融合后的状态信息 torch.Size([192])
        # print(f'output5-->{output5}')
        x = F.relu(self.fc1(output5))  # ReLU激活函数
        # x = self.dropout(x)
        # x = F.leaky_relu(self.fc2(x))  # ReLU激活函数
        # x = self.dropout(x)
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        x = F.relu(self.fc4(x))
        x = F.relu(self.fc5(x))
        x = F.relu(self.fc6(x))

        # x = self.fc4(x)
        # x = self.fc5(x)
        x = self.fc7(x)

        # print(x.shape)
        # print(torch.max(x, dim=0)[0].shape)

        policy = F.softmax((x - torch.max(x, dim=-1,keepdim=True)[0]), dim=-1)  # 输出
        # print(f'policy-->{policy}')
        # print(f'self.fc3(x).shape-->{self.fc3(x).shape}')
        return policy


# 定义ValueNet类，实现ValueNet网络
class ValueNet(nn.Module):
    def __init__(self, en_graph_dim, user_information_dim, state_dim, device):
        super(ValueNet, self).__init__()

        # 对状态信息进行特征提取
        self.gcn = GraphNetwork(en_graph_dim, hidden_dim=128, output_dim=5, device=device)  # 采用图卷积提取边缘节点的特征

        self.feature_extractor = nn.Sequential(  # 采用全连接神经网络提取用户的信息特征
            nn.Linear(user_information_dim, 128).to(device),
            nn.ReLU(),
            nn.Linear(128, 128).to(device),
            nn.ReLU(),
            nn.Linear(128, 128).to(device),
            nn.ReLU(),
            nn.Linear(128, 4).to(device)
        )

        self.feature_extractor2 = nn.Sequential(  # 采用全连接神经网络提取图卷积后的信息特征
            nn.Linear(25 * 5, 256).to(device),
            nn.ReLU(),
            nn.Linear(256, 256).to(device),
            nn.ReLU(),
            nn.Linear(256, 256).to(device),
            nn.ReLU(),
            nn.Linear(256, 64).to(device),
            # nn.LeakyReLU(),
            # nn.Linear(512, 256).to(device),
            # nn.LeakyReLU(),
            # nn.Linear(256, 64).to(device)
        )

        self.fc1 = nn.Linear(state_dim, 128).to(device)
        self.dropout = nn.Dropout(0.0)
        self.fc2 = nn.Linear(128, 128).to(device)
        self.fc3 = nn.Linear(128, 128).to(device)
        self.fc4 = nn.Linear(128, 128).to(device)
        self.fc5 = nn.Linear(128, 128).to(device)
        self.fc6 = nn.Linear(128, 1).to(device)  # 输出层为一个单一的值

        # 初始化参数
        self.init_parameters()

    def init_parameters(self):
        def init_weights(m):
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

        self.apply(init_weights)

    def forward(self, x):
        graph_data, user_information = x[0], x[1]
        nodes_ferature, edge_index, edge_attr = graph_data.x, graph_data.edge_index, graph_data.edge_attr
        batchsize = int(nodes_ferature.shape[0] / 25)
        # print(f'nodes_ferature-->{nodes_ferature}')
        # print(f'edge_index-->{edge_index}')
        # print(f'edge_attr-->{edge_attr}')
        # print(f'batchsize-->{batchsize}')

        output1 = self.gcn(nodes_ferature, edge_index, edge_attr)  # output1-->torch.Size([25, 64])
        # print(f'output1-->{output1.shape}')
        output2 = self.feature_extractor(user_information)  # output2-->torch.Size([64])

        # 将特征图展品 3300*16--->52800
        output6 = output1.clone().view(batchsize, -1)
        # print(f'output6-->{output6.shape}')
        # output3 = output6.clone().view(batchsize,-1)  # output1-->torch.Size([1600])
        output3 = output6.clone()  # output1-->torch.Size([1600])

        # 对展平后的向量提取特征
        output4 = self.feature_extractor2(output3.clone())
        # print(f'output4-->{output4.shape}')
        # print(f'output2-->{output2.shape}')
        # 进行向量拼接 (192,)
        output5 = torch.cat((output4, output2), dim=-1)  # 特征融合后的状态信息 torch.Size([192])
        # print(f'output5-->{output5.shape}')
        x = F.relu(self.fc1(output5))  # ReLU激活函数
        x = F.relu(self.fc2(x))  # ReLU激活函数
        x = F.relu(self.fc3(x))  # ReLU激活函数
        x = F.relu(self.fc4(x))  # ReLU激活函数
        x = F.relu(self.fc5(x))  # ReLU激活函数

        # x = self.dropout(x)  # 防止过拟合
        # x = self.fc2(x)
        # x = F.leaky_relu(x)  # ReLU激活函数
        # x = self.dropout(x)  # 防止过拟合
        value = self.fc6(x)  # 输出
        # value = x  # 输出
        return value


# 计算优势（Generalized Advantage Estimation）
def compute_advantage(gamma, lambda_, td_delta):
    """
    这段代码是用于计算优势（advantage）的。
    在PPO算法中，优势是指智能体在执行某个动作时相对于平均水平的优势。
    :param gamma: 累计折扣系数
    :param lambda_:
    :param td_delta: 表示每个时间步的TD误差
    :return:
    """
    td_delta = td_delta.cpu().detach().numpy()
    advantage_list = []
    advantage = 0.0
    for delta in td_delta[::-1]:
        advantage = gamma * lambda_ * advantage + delta
        advantage_list.append(advantage)
    advantage_list.reverse()
    return torch.tensor(np.array(advantage_list), dtype=torch.float)


# 定义强化学习的PPO算法
class PPO:
    """ PPO算法，采用截断方式 """

    def __init__(self, args, device):
        """
        :param state_dim: 状态信息
        :param hidden_dim: 隐藏层维度
        :param action_dim: 动作维度
        :param actor_lr: 策略网络学习率
        :param critic_lr: 价值网络学习率
        :param lambda_: λ
        :param epochs: 训练回合
        :param eps: eps是PPO算法中的一个超参数，用于控制策略更新的大小。
                    具体来说，eps被用于计算一个比率，该比率用于限制策略更新的大小。
                    如果新的策略比旧的策略更优，则使用eps来计算一个比率，该比率用于限制策略更新的大小。
                    这有助于防止智能体对其策略进行大幅更改，从而可能对其性能产生不利影响。
        :param gamma: 折扣系数
        :param device: 训练设备：GPU or CPU
        """

        self.lr_a = args.actor_lr
        self.lr_c = args.critic_lr
        self.use_lr_decay = args.use_lr_decay
        self.K_epochs = args.K_epochs
        self.use_adv_norm = args.use_adv_norm
        self.use_grad_clip = args.use_grad_clip
        self.entropy_coef = args.entropy_coef
        self.mini_batch_size = args.mini_batch_size
        self.batch_size = args.batch_size
        self.device = device
        self.actor = PolicyNet(args.en_graph_dim, args.user_information_dim, args.state_dim, args.action_dim, self.device).to(
            device)
        print(f'策略网络：\n{self.actor}\n')
        self.critic = ValueNet(args.en_graph_dim, args.user_information_dim, args.state_dim, self.device).to(device)
        print(f'价值网络：\n{self.critic}\n')
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=args.actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=args.critic_lr)
        self.gamma = args.gamma
        self.lambda_ = args.lambda_
        self.epochs = args.epochs
        self.eps = args.eps
        self.greediness = args.greediness
        # 定义学习率调度器
        # self.a_scheduler = ExponentialLR(self.actor_optimizer, gamma=0.96)
        # self.c_scheduler = ExponentialLR(self.critic_optimizer, gamma=0.96)
        self.a_scheduler = ExponentialLR(self.actor_optimizer, gamma=0.99)
        self.c_scheduler = ExponentialLR(self.critic_optimizer, gamma=0.99)

    # # 使用Log-Sum-Exp技巧计算稳定的指数函数
    # def stable_exp(self,x):
    #     max_value = torch.max(x)
    #     return torch.exp(x - max_value) / torch.sum(torch.exp(x - max_value))
    #
    # # 使用Log-Sum-Exp技巧计算指数函数
    # def compute_exp_logsumexp(self,x):
    #     max_value = torch.max(x)
    #     return max_value + torch.log(torch.sum(torch.exp(x - max_value)))

    # 预测的时候采用确定性的概率
    def evaluate(self, state_graph, state_user, state_en_bw, edge_index, mask):
        # 定义节点特征
        edge_nodes_feature = torch.tensor(data=state_graph, dtype=torch.float).to(device)  # torch.Size([25, 5])
        edge_index = torch.tensor(edge_index, dtype=torch.long).to(device)  # torch.Size([114, 2])
        edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([2, 114])
        edge_attr = torch.tensor(state_en_bw, dtype=torch.float).to(device)  # 边权重,带宽

        en_graph_data = Data(x=edge_nodes_feature, edge_index=edge_index_,
                             edge_attr=edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
        en_graph_data = en_graph_data.to(self.device)

        state_user = torch.tensor(state_user, dtype=torch.float).to(self.device)

        if torch.all(mask == True):
            return mask.shape[0] - 1

        # 基于策略网络输出动作空间中不同动作的概率，基于概率选择动作
        probs = self.actor([en_graph_data, state_user]).to(self.device)
        probs = torch.where(mask == True, torch.tensor(-torch.inf, dtype=torch.float, device=self.device), probs).to(self.device)

        # 将其他元素进行偏移
        probs[probs != -torch.inf] += 1e-5
        # 将负无穷替换为较小的有限值
        probs[probs == -torch.inf] = 1e-10

        # 计算张量的总和
        total_sum = torch.sum(probs).to(self.device)
        # 归一化处理
        normalized_probs = probs / total_sum

        # 确保所有归一化后的元素的和等于 1
        normalized_probs = normalized_probs / torch.sum(normalized_probs).to(self.device)
        probs = normalized_probs

        # 基于最大概率选择动作
        action = torch.argmax(probs)
        # print(probs)
        # print(action)
        # breakpoint()

        return action.item()

    # agent选择当前动作
    def take_action(self, state_graph, state_user, state_en_bw, edge_index, mask):
        # # 定义边索引,判断两个边缘服务器之间是否有连接,若有连接,获取两个边缘服务器间的带宽矩阵
        # k = 0
        # for i in range(1, en_num):
        #     for j in range(i):
        #         distance_ap_to_ap = np.linalg.norm(x=np.array(state_graph[i].loc) - np.array(state_graph[j].loc), ord=2)
        #         if distance_ap_to_ap < (state_graph[i].radius + state_graph[j].radius):
        #             bandwidth = state_en_bw[k] * 1e6
        #             edge_attr.append(bandwidth)  # 边权重,带宽
        #             edge_index.append([i, j])
        #             edge_attr.append(bandwidth)  # 边权重,带宽
        #             edge_index.append([j, i])
        #         k = k + 1
        # edge_index = torch.tensor(edge_index, dtype=torch.long).to(device)  # torch.Size([114, 2])
        # edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([2, 114])

        # 定义节点特征
        edge_nodes_feature = torch.tensor(data=state_graph, dtype=torch.float).to(device)  # torch.Size([25, 5])
        edge_index = torch.tensor(edge_index, dtype=torch.long).to(device)  # torch.Size([114, 2])
        edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([2, 114])
        edge_attr = torch.tensor(state_en_bw, dtype=torch.float).to(device)  # 边权重,带宽

        en_graph_data = Data(x=edge_nodes_feature, edge_index=edge_index_,
                             edge_attr=edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
        en_graph_data = en_graph_data.to(self.device)

        state_user = torch.tensor(state_user, dtype=torch.float).to(self.device)

        # print(f'en_graph_data-->{en_graph_data}')
        # print(f'state_user-->{state_user}')

        # if torch.all(mask == True):
        #     return mask.shape[0] - 1
        # print(f"mask_->{mask}")
        # 基于策略网络输出动作空间中不同动作的概率，基于概率选择动作
        probs = self.actor([en_graph_data, state_user]).to(self.device)
        # print(f'probs--{probs}')
        # mask = mask.cpu().numpy()
        # mask = np.append(mask, True)
        # mask = torch.tensor(mask,device=self.device,dtype=torch.float)
        probs = torch.where(mask == True, torch.tensor(-torch.inf, dtype=torch.float, device=self.device), probs).to(self.device)
        # print(f'maskprobs--{probs}')

        # 将其他元素进行偏移
        probs[probs != -torch.inf] += 1e-5
        # 将负无穷替换为较小的有限值
        probs[probs == -torch.inf] = 1e-10

        # print(f'maskprobs2--{probs}')
        # 计算张量的总和
        total_sum = torch.sum(probs).to(self.device)
        # 归一化处理
        normalized_probs = probs / total_sum

        # 确保所有归一化后的元素的和等于 1
        normalized_probs = normalized_probs / torch.sum(normalized_probs).to(self.device)
        probs = normalized_probs
        # print(f'概率和是否为1-->{torch.sum(probs)}')
        # 生成随机数，若随机数超过greediness，则探索，否则开发
        if np.random.uniform() < self.greediness:
            # 基于最大概率选择动作
            action = torch.argmax(probs)
            action_logprob = torch.log(probs[action])
            # return action.cpu().numpy(), action_logprob.cpu().numpy()
        else:
            # 基于概率选择动作
            with torch.no_grad():
                action_dist = torch.distributions.Categorical(probs)

                if torch.all(mask  == True):
                    action = torch.tensor(mask.shape[0] - 1).to(self.device)
                else:
                   action = action_dist.sample()

                   while mask[action] == True:
                       action = action_dist.sample()

                action_logprob = action_dist.log_prob(action)
                # print(action.cpu().numpy())
                #
                # print(action_logprob.cpu().numpy())
                # breakpoint()
        return action.item(), action_logprob.item()

    def update(self, replay_buffer):
        state_user, state_graph, state_en_bw, action, action_logprob, reward, next_state_user, next_state_graph, next_state_en_bw, dw, done, mask, edge_index = replay_buffer.numpy_to_tensor()  # Get training data
        edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([114, 2] --》torch.Size([2, 114])
        # np.set_printoptions(np.inf)
        # print(reward)
        # breakpoint()
        # print(state_graph.shape)
        # breakpoint()

        states_graph_data_list = []
        for state_id in range(state_graph.shape[0]):
            edge_nodes_feature = state_graph[state_id]  # torch.Size([25, 4])

            edge_attr = state_en_bw[state_id]  # 边权重,带宽

            en_graph_data = Data(x=edge_nodes_feature, edge_index=edge_index_,
                                 edge_attr=edge_attr)  # Data(x=[25,4], edge_index=[2, 114])
            en_graph_data = en_graph_data.to(self.device)
            states_graph_data_list.append(en_graph_data)
        # print(len(graph_data_list))
        # print(graph_data_list)
        states_batch = Batch.from_data_list(states_graph_data_list)
        states = [states_batch, state_user]

        next_states_graph_data_list = []
        for state_id in range(next_state_graph.shape[0]):
            next_state_edge_nodes_feature = next_state_graph[state_id]  # torch.Size([25, 4])

            next_state_edge_attr = next_state_en_bw[state_id]  # 边权重,带宽

            next_state_en_graph_data = Data(x=next_state_edge_nodes_feature, edge_index=edge_index_,
                                            edge_attr=next_state_edge_attr)  # Data(x=[25,4], edge_index=[2, 114])
            next_state_en_graph_data = next_state_en_graph_data.to(self.device)
            next_states_graph_data_list.append(next_state_en_graph_data)
        # print(len(graph_data_list))
        # print(graph_data_list)
        next_states_batch = Batch.from_data_list(next_states_graph_data_list)
        next_states = [next_states_batch, next_state_user]

        #advantage = []
        #gae = 0
        with torch.no_grad():  # adv and v_target have no gradient
            vs = self.critic(states).to(self.device)
            vs_ = self.critic(next_states).to(self.device)
            td_target = reward + self.gamma * vs_ * (1 - done).to(self.device)
            td_delta = td_target - vs
            advantage = compute_advantage(self.gamma, self.lambda_, td_delta).to(self.device)
            v_target = advantage + vs
            if self.use_adv_norm:  # Trick 1:advantage normalization
                advantage_ = ((advantage - advantage.mean()) / (advantage.std() + 1e-5))
            # # advantage_ = F.normalize(advantage, dim=0).to(self.device)
            #deltas = reward + self.gamma * (1.0 - dw) * vs_ - vs
            #for delta, d in zip(reversed(deltas.flatten().cpu().numpy()), reversed(done.flatten().cpu().numpy())):
                #gae = delta + self.gamma * self.lambda_ * gae * (1.0 - d)
                #advantage.insert(0, gae)
            #advantage = torch.tensor(advantage, dtype=torch.float).view(-1, 1).to(self.device)
            # print(adv.cpu().numpy())
            # print(adv.mean())
            # print(adv.std())
            # breakpoint()
            # v_target = advantage + vs
            # if self.use_adv_norm:  # Trick 1:advantage normalization
                #advantage_ = ((advantage - advantage.mean()) / (advantage.std() + 1e-5))
   
        # Optimize policy for K epochs:
        for _ in range(self.K_epochs):
            # Random sampling and no repetition. 'False' indicates that training will continue even if the number of samples in
            # the last time is less than mini_batch_size
            for index in BatchSampler(SubsetRandomSampler(range(self.batch_size)), self.mini_batch_size, False):
                state_batch = Batch.from_data_list(states_batch[index])
                state = [state_batch, state_user[index]]
                # print(state_batch)
                # print(state_user[index].shape)
                # breakpoint()
                dist_now = Categorical(probs=self.actor(state))
                dist_entropy = dist_now.entropy().view(-1, 1)  # shape(mini_batch_size X 1)
                action_logprob_now = dist_now.log_prob(action[index].squeeze()).view(-1, 1)  # shape(mini_batch_size X 1)
                # a/b=exp(log(a)-log(b))
                ratios = torch.exp(action_logprob_now - action_logprob[index])  # shape(mini_batch_size X 1)

                surr1 = ratios * advantage_[index]  # Only calculate the gradient of 'a_logprob_now' in ratios
                surr2 = torch.clamp(ratios, 1 - self.eps, 1 + self.eps) * advantage_[index]
                self.actor_loss = -torch.min(surr1, surr2) - self.entropy_coef * dist_entropy  # shape(mini_batch_size X 1)
                # Update actor
                self.actor_optimizer.zero_grad()  # 梯度清零
                self.actor_loss.mean().backward()  # 反向传播
                if self.use_grad_clip:  # Trick 7: Gradient clip
                    torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 1.0)
                self.actor_optimizer.step() # 更新参数



                # self.critic_loss = F.mse_loss(td_target[index], v_s)
                value_preds = self.critic(state)
                clipped_value_preds = vs[index] + torch.clamp(value_preds - vs[index], -0.2, 0.2) # (0.2 的效果还行)
                # self.critic_loss = torch.max(F.mse_loss(value_preds, v_target.detach()), F.mse_loss(clipped_value_preds, v_target.detach()))
                value_loss = torch.max(((value_preds - v_target[index]) ** 2), ((clipped_value_preds - v_target[index]) ** 2))
                self.critic_loss = value_loss.mean()


                # v_s = self.critic(state)
                # self.critic_loss = F.mse_loss(v_target[index], v_s)

                # Update critic
                self.critic_optimizer.zero_grad()
                self.critic_loss.backward()
                if self.use_grad_clip:  # Trick 7: Gradient clip
                    torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 1.0)
                self.critic_optimizer.step()
            print("当前学习率：")
            for param_group in self.actor_optimizer.param_groups:
                print(param_group['lr'])
            for param_group in self.critic_optimizer.param_groups:
                print(param_group['lr'])
        self.a_scheduler.step()
        self.c_scheduler.step()
        # if self.use_lr_decay:  # Trick 6:learning rate Decay
        #     self.lr_decay(total_steps)
        print("当前学习率：")
        for param_group in self.actor_optimizer.param_groups:
            print(param_group['lr'])
        for param_group in self.critic_optimizer.param_groups:
            print(param_group['lr'])
    #
    # def lr_decay(self, total_steps):
    #     lr_a_now = self.lr_a * (1 - total_steps / self.max_train_steps)
    #     lr_c_now = self.lr_c * (1 - total_steps / self.max_train_steps)
    #     for p in self.actor_optimizer.param_groups:
    #         p['lr'] = lr_a_now
    #     for p in self.critic_optimizer.param_groups:
    #         p['lr'] = lr_c_now

        # for _ in range(5):
        #     # for _ in range(10):
        #     log_probs = torch.log(self.actor(states).gather(1, actions.type(torch.int64)) + 1e-10)  # 计算新的log概率
        #     # print(f'log_probs-->{log_probs}')
        # 
        #     ratio = torch.exp(log_probs - old_log_probs)  # 计算比率
        #     # probs_ = log_probs.clone() - old_log_probs.clone()
        #     # ratio = self.compute_exp_logsumexp(probs_)  # 计算比率
        #     # print(f'ratio-->{ratio}')
        #     surr1 = ratio * advantage_
        #     surr2 = torch.clamp(ratio, 1 - self.eps, 1 + self.eps) * advantage_
        #     self.actor_loss = torch.mean(-torch.min(surr1, surr2))
        #     self.critic_loss = torch.mean(F.mse_loss(self.critic(states), td_target.detach()))
        # 
        #     # # 添加L2正则化项
        #     # l2_lambda = 0.01  # L2正则化项的权重系数
        #     # l2_reg = torch.tensor(0.0).to(self.device)  # 初始化L2正则化项的值
        #     # for param in self.actor.parameters():
        #     #     l2_reg += torch.norm(param, 2).to(self.device)  # 计算L2范数
        #     # self.actor_loss += l2_lambda * l2_reg  # 将L2正则化项添加到actor_loss中
        #     #
        #     # # 添加L2正则化项
        #     # l2_lambda2 = 0.01  # L2正则化项的权重系数
        #     # l2_reg2 = torch.tensor(0.0).to(self.device)  # 初始化L2正则化项的值
        #     # for param in self.critic.parameters():
        #     #     l2_reg2 += torch.norm(param, 2).to(self.device)  # 计算L2范数
        #     # self.critic_loss += l2_lambda2 * l2_reg2  # 将L2正则化项添加到actor_loss中
        # 
        #     self.actor_optimizer.zero_grad()  # 梯度清零
        #     self.critic_optimizer.zero_grad()  # 梯度清零
        #     self.actor_loss.backward()  # 反向传播
        #     self.critic_loss.backward()  # 反向传播
        #     torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 0.5)  # 对梯度进行裁剪
        #     torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 0.5)  # 对梯度进行裁剪
        #     self.actor_optimizer.step()  # 更新参数
        #     self.critic_optimizer.step()  # 更新参数

    # def update(self, transition_dict):
    #     edge_index = torch.tensor(transition_dict["edge_index"][0], dtype=torch.long).to(device)  # torch.Size([114, 2])
    #     edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([2, 114])
    #     states_user = torch.tensor(np.array(transition_dict["states_user"]), dtype=torch.float).to(self.device)
    #     # print(states_user.shape)
    #
    #     states_graph_data_list = []
    #     for state_id in range(len(transition_dict["states_graph"])):
    #         edge_nodes_feature = torch.tensor(data=transition_dict["states_graph"][state_id], dtype=torch.float).to(
    #             device)  # torch.Size([25, 5])
    #
    #         edge_attr = torch.tensor(transition_dict["states_en_bw"][state_id], dtype=torch.float).to(device)  # 边权重,带宽
    #
    #         en_graph_data = Data(x=edge_nodes_feature, edge_index=edge_index_,
    #                              edge_attr=edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
    #         en_graph_data = en_graph_data.to(self.device)
    #         states_graph_data_list.append(en_graph_data)
    #     # print(len(graph_data_list))
    #     # print(graph_data_list)
    #     states_batch = Batch.from_data_list(states_graph_data_list)
    #     states = [states_batch, states_user]
    #
    #     next_states_user = torch.tensor(np.array(transition_dict["next_states_user"]), dtype=torch.float).to(self.device)
    #     # print(next_states_user.shape)
    #
    #     next_states_graph_data_list = []
    #     for state_id in range(len(transition_dict["next_states_graph"])):
    #         next_state_edge_nodes_feature = torch.tensor(data=transition_dict["next_states_graph"][state_id],
    #                                                      dtype=torch.float).to(
    #             device)  # torch.Size([25, 5])
    #
    #         next_state_edge_attr = torch.tensor(transition_dict["next_states_en_bw"][state_id], dtype=torch.float).to(
    #             device)  # 边权重,带宽
    #
    #         next_state_en_graph_data = Data(x=next_state_edge_nodes_feature, edge_index=edge_index_,
    #                                         edge_attr=next_state_edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
    #         next_state_en_graph_data = next_state_en_graph_data.to(self.device)
    #         next_states_graph_data_list.append(next_state_en_graph_data)
    #     # print(len(graph_data_list))
    #     # print(graph_data_list)
    #     next_states_batch = Batch.from_data_list(next_states_graph_data_list)
    #     next_states = [next_states_batch, next_states_user]
    #
    #     actions = torch.tensor(np.array(transition_dict["actions"]), dtype=torch.float).view(-1, 1).to(self.device)
    #     rewards = torch.tensor(np.array(transition_dict["rewards"]), dtype=torch.float).view(-1, 1).to(self.device)
    #     # print(f"rewards-->{rewards}")
    #     # print(f"next_states-->{next_states.shape}")
    #
    #     dones = torch.tensor(np.array(transition_dict["dones"]), dtype=torch.float).view(-1, 1).to(self.device)
    #     td_target = rewards + self.gamma * self.critic(next_states) * (1 - dones).to(self.device)
    #     td_delta = td_target - self.critic(states)
    #     advantage = compute_advantage(self.gamma, self.lambda_, td_delta).to(self.device)
    #     # print(advantage)
    #     # breakpoint()
    #     # advantage_mean = torch.mean(advantage, dim=-1)  # 计算优势的均值
    #     # advantage_std = torch.std(advantage, dim=-1)  # 计算优势的标准差
    #     # advantage_ = (advantage.clone() - advantage_mean) / (advantage_std + 1e-10)
    #     advantage_ = F.normalize(advantage, dim=0).to(self.device)
    #     # print(advantage)
    #     # print(advantage_)
    #     # breakpoint()
    #     # print(self.actor(states))
    #     # breakpoint()
    #     old_log_probs = torch.log(self.actor(states).gather(1, actions.type(torch.int64)) + 1e-10).detach()
    #     # print(f'old_log_probs-->{old_log_probs}')
    #     # breakpoint()
    #     # for _ in range(self.epochs):
    #     for _ in range(5):
    #         # for _ in range(10):
    #         log_probs = torch.log(self.actor(states).gather(1, actions.type(torch.int64)) + 1e-10)  # 计算新的log概率
    #         # print(f'log_probs-->{log_probs}')
    #
    #         ratio = torch.exp(log_probs - old_log_probs)  # 计算比率
    #         # probs_ = log_probs.clone() - old_log_probs.clone()
    #         # ratio = self.compute_exp_logsumexp(probs_)  # 计算比率
    #         # print(f'ratio-->{ratio}')
    #         surr1 = ratio * advantage_
    #         surr2 = torch.clamp(ratio, 1 - self.eps, 1 + self.eps) * advantage_
    #         self.actor_loss = torch.mean(-torch.min(surr1, surr2))
    #         self.critic_loss = torch.mean(F.mse_loss(self.critic(states), td_target.detach()))
    #
    #         # # 添加L2正则化项
    #         # l2_lambda = 0.01  # L2正则化项的权重系数
    #         # l2_reg = torch.tensor(0.0).to(self.device)  # 初始化L2正则化项的值
    #         # for param in self.actor.parameters():
    #         #     l2_reg += torch.norm(param, 2).to(self.device)  # 计算L2范数
    #         # self.actor_loss += l2_lambda * l2_reg  # 将L2正则化项添加到actor_loss中
    #         #
    #         # # 添加L2正则化项
    #         # l2_lambda2 = 0.01  # L2正则化项的权重系数
    #         # l2_reg2 = torch.tensor(0.0).to(self.device)  # 初始化L2正则化项的值
    #         # for param in self.critic.parameters():
    #         #     l2_reg2 += torch.norm(param, 2).to(self.device)  # 计算L2范数
    #         # self.critic_loss += l2_lambda2 * l2_reg2  # 将L2正则化项添加到actor_loss中
    #
    #         self.actor_optimizer.zero_grad()  # 梯度清零
    #         self.critic_optimizer.zero_grad()  # 梯度清零
    #         self.actor_loss.backward()  # 反向传播
    #         self.critic_loss.backward()  # 反向传播
    #         torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 5.0)  # 对梯度进行裁剪
    #         torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 5.0)  # 对梯度进行裁剪
    #         self.actor_optimizer.step()  # 更新参数
    #         self.critic_optimizer.step()  # 更新参数


class ActorCritic(nn.Module):
    def __init__(self, hidden_sizes):
        super(ActorCritic, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_sizes[0])
        self.fc2 = nn.Linear(hidden_sizes[0], hidden_sizes[1])
        self.actor = nn.Sequential(
            nn.Linear(hidden_sizes[1], action_dim),
            nn.ReLU(),
            nn.Softmax(dim=-1)
        )
        self.critic = nn.Linear(hidden_sizes[1], 1)
        self.optimizer = optim.Adam(self.parameters(), lr=0.001)

    def forward(self, x):
        x = torch.nn.LeakyReLU(self.fc1(x))
        x = torch.nn.LeakyReLU(self.fc2(x))
        actor = self.actor(x)
        critic = self.critic(x)
        return actor, critic


def ppo_iter(mini_batch_size, states, actions, log_probs, returns, advantage):
    batch_size = states.size(0)
    for _ in range(batch_size // mini_batch_size):
        rand_ids = np.random.choice(batch_size, mini_batch_size)
        yield states[rand_ids, :], actions[rand_ids, :], log_probs[rand_ids, :], returns[rand_ids, :], advantage[
                                                                                                       rand_ids, :]


def ppo_update(ppo_epochs, mini_batch_size, clip_param, actor_critic, optimizer, states, actions, log_probs, returns,
               advantages):
    for _ in range(ppo_epochs):
        for state, action, old_log_probs, return_, advantage in ppo_iter(mini_batch_size, states, actions, log_probs,
                                                                         returns, advantages):
            actor, critic = actor_critic(state)
            dist = torch.distributions.Categorical(actor)
            entropy = dist.entropy().mean()
            new_log_probs = dist.log_prob(action)

            ratio = (new_log_probs - old_log_probs).exp()
            surr1 = ratio * advantage
            surr2 = torch.clamp(ratio, 1.0 - clip_param, 1.0 + clip_param) * advantage
            actor_loss = -torch.min(surr1, surr2).mean()
            critic_loss = (return_ - critic).pow(2).mean()

            loss = actor_loss + 0.5 * critic_loss - 0.001 * entropy

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()


def train_on_policy_agent(env, agent, num_episodes):
    return_list = []
    for i in range(epochs):
        with tqdm(total=int(num_episodes / 10), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes / 10)):
                episode_return = 0
                transition_dict = {"states": [], "actions": [], "next_states": [], "rewards": [], "dones": []}
                # [ 0.00828048  0.02124009 -0.02172656  0.0228728 ] 4维
                state = env.reset()
                # print(f"state-->{state}")
                done = False
                while not done:
                    action = agent.take_action(state)
                    next_state, reward, done, _ = env.step(action)
                    transition_dict["states"].append(state)
                    transition_dict["actions"].append(action)
                    transition_dict["next_states"].append(next_state)
                    transition_dict["rewards"].append(reward)
                    transition_dict["dones"].append(done)
                    state = next_state
                    episode_return += reward
                return_list.append(episode_return)
                agent.update(transition_dict)
                if (i_episode + 1) % 10 == 0:
                    pbar.set_postfix({'episode': '%d' % (num_episodes / 10 * i + i_episode + 1),  # 计算最后10个元素的平均值
                                      'return': '%.3f' % np.mean(return_list[-10:])})
                pbar.update(1)
    return return_list


actor_lr = 1e-3  # 策略网络学习率
critic_lr = 1e-2  # 价值网络学习率
num_episodes = 300  # 回合数
hidden_dim = 128  # 隐藏层维度
gamma = 0.98  # 折扣系数
lambda_ = 0.99  # λ
epochs = 10  # 训练轮数
eps = 0.2  # PPO参数

# 训练采用的设备
device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
# env = gym.make("CartPole-v1")

# 获取环境的状态特征


# user_file = '../user.csv'
# en_file = '../en.csv'
# num_file = '../num.csv'
# traj_file = '../../Trajectory.csv'
#
# state_dim = env.observation_space.shape[0]
# action_dim = env.action_space.n
# greediness = 0.0
# # ppo_agent = PPO(state_dim, hidden_dim, action_dim, actor_lr, critic_lr, lambda_, epochs, eps, gamma, device,
# #                 greediness=greediness)
