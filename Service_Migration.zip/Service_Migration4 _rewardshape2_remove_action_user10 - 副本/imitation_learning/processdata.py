import csv
import numpy as np
import torch


class StandardScaler():
    def __init__(self):
        self.mean = 0
        self.std = 1.

    def fit(self, data):
        self.mean = data.mean(0)  # 按列对dataframe中的数据进行求平均值
        self.std = data.std(0)  # 按列对dataframe中的数据进行求标准差

    def transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        # print(mean)
        # print(std)
        return (data - mean + 1e-10) / (std + 1e-10)

    def inverse_transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        if data.shape[-1] != mean.shape[-1]:
            mean = mean[-1:]
            std = std[-1:]
        return (data * std) + mean


class MinMaxScaler():
    def __init__(self):
        self.min = 0
        self.max = 1.

    def fit(self, data):
        self.min = data.min(0)  # 按列对数据求最小值
        self.max = data.max(0)  # 按列对数据求最大值

    def transform(self, data):
        min_val = torch.from_numpy(self.min).type_as(data).to(data.device) if torch.is_tensor(data) else self.min
        max_val = torch.from_numpy(self.max).type_as(data).to(data.device) if torch.is_tensor(data) else self.max
        return (data - min_val ) / (max_val - min_val + 1e-10)

    def inverse_transform(self, data):
        min_val = torch.from_numpy(self.min).type_as(data).to(data.device) if torch.is_tensor(data) else self.min
        max_val = torch.from_numpy(self.max).type_as(data).to(data.device) if torch.is_tensor(data) else self.max
        if data.shape[-1] != min_val.shape[-1]:
            min_val = min_val[-1:]
            max_val = max_val[-1:]
        return data * (max_val - min_val) + min_val


user_file = '../StableMatch/user.csv'
en_file = '../StableMatch/en.csv'
num_file = '../StableMatch/num.csv'
traj_file = '../Trajectory.csv'

'''读取用户信息，并对用户信息进行归一化'''


def read_users_dataset():
    # 定义节点特征
    users_feature = []
    with open(user_file, 'r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        # 将读文件的信息写入列表里存放)
        i = 0
        for row in reader:
            # print(i)
            if (i < 15):
                loc = (float(row['loc_x']), float(row['loc_y']))
                u_id = int(row['u_id'])
                cpu_circle = float(row['cpu_circle'])
                class_for_del = int(row['class_for_del'])
                satisfied_serv_del = float(row['satisfied_serv_del'])
                max_serv_del = float(row['max_serv_del'])
                data_size = float(row['input_size'])
                result_size = float(row['result_size'])
                p = float(row['p'])
                user_node_feature = [cpu_circle,
                                     satisfied_serv_del,
                                     max_serv_del,
                                     data_size,
                                     # data_size,
                                     result_size,
                                     # p,
                                     class_for_del]
                with open(traj_file, 'r', encoding='utf-8') as csvfile:
                    reader2 = csv.DictReader(csvfile)
                    for row2 in reader2:
                        if int(row2['#Node']) == u_id:
                            # 将对应的用户轨迹写到对应的用户
                            user_node_feature.append(float(row2['X']))
                            user_node_feature.append(float(row2['Y']))
                users_feature.append(user_node_feature)
                i += 1
            else:
                break
    # 使用StandardScaler记录标准化参数
    users_feature = np.array(users_feature, dtype=float)
    # 获取均值和标准差
    scaler = StandardScaler()
    scaler.fit(users_feature)

    users_data = scaler.transform(users_feature)
    return scaler,users_data
