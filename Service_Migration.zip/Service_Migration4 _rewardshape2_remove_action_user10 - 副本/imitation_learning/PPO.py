import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from matplotlib import pyplot as plt
from torch.distributions import Categorical
import gym
from tqdm import tqdm

# 定义PolicyNet类，实现PolicyNet网络
class PolicyNet(nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(PolicyNet, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)  # 输入层
        self.fc2 = nn.Linear(hidden_dim, action_dim)  # 输出层

    def forward(self, x):
        x = F.relu(self.fc1(x))  # ReLU激活函数
        policy = F.softmax(self.fc2(x), dim=1)  # 输出
        return policy


# 定义ValueNet类，实现ValueNet网络
class ValueNet(nn.Module):
    def __init__(self, state_dim, hidden_dim):
        super(ValueNet, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)  # 输入层
        self.fc2 = nn.Linear(hidden_dim, 1)  # 输出层

    def forward(self, x):
        x = F.relu(self.fc1(x))  # ReLU激活函数
        value = self.fc2(x)  # 输出
        return value


# 计算优势（Generalized Advantage Estimation）
def compute_advantage(gamma, lambda_, td_delta):
    """
    这段代码是用于计算优势（advantage）的。
    在PPO算法中，优势是指智能体在执行某个动作时相对于平均水平的优势。
    :param gamma: 累计折扣系数
    :param lambda_:
    :param td_delta: 表示每个时间步的TD误差
    :return:
    """
    td_delta = td_delta.cpu().detach().numpy()
    advantage_list = []
    advantage = 0.0
    for delta in td_delta[::-1]:
        advantage = gamma * lambda_ * advantage + delta
        advantage_list.append(advantage)
    advantage_list.reverse()
    return torch.tensor(np.array(advantage_list), dtype=torch.float)


# 定义强化学习的PPO算法
class PPO:
    """ PPO算法，采用截断方式 """

    def __init__(self, state_dim, hidden_dim, action_dim, actor_lr, critic_lr,
                 lambda_, epochs, eps, gamma, device, greediness=0.7):
        """
        :param state_dim: 状态维度
        :param hidden_dim: 隐藏层维度
        :param action_dim: 动作维度
        :param actor_lr: 策略网络学习率
        :param critic_lr: 价值网络学习率
        :param lambda_: λ
        :param epochs: 训练回合
        :param eps: eps是PPO算法中的一个超参数，用于控制策略更新的大小。
                    具体来说，eps被用于计算一个比率，该比率用于限制策略更新的大小。
                    如果新的策略比旧的策略更优，则使用eps来计算一个比率，该比率用于限制策略更新的大小。
                    这有助于防止智能体对其策略进行大幅更改，从而可能对其性能产生不利影响。
        :param gamma: 折扣系数
        :param device: 训练设备：GPU or CPU
        """
        self.actor = PolicyNet(state_dim, hidden_dim, action_dim).to(device)
        print(f'策略网络：\n{self.actor}\n')
        self.critic = ValueNet(state_dim, hidden_dim).to(device)
        print(f'价值网络：\n{self.critic}\n')
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=critic_lr)
        self.gamma = gamma
        self.lambda_ = lambda_
        self.epochs = epochs
        self.eps = eps
        self.device = device
        self.greediness = greediness

    # agent选择当前动作
    def take_action(self, state):
        state = torch.tensor(np.array([state]), dtype=torch.float).to(self.device)
        # 基于策略网络输出动作空间中不同动作的概率，基于概率选择动作
        probs = self.actor(state)
        # 生成随机数，若随机数超过greediness，则探索，否则开发
        if np.random.uniform() < self.greediness:
            # 基于最大概率选择动作
            action = torch.argmax(probs)
        else:
            # 基于概率选择动作
            action_dist = torch.distributions.Categorical(probs)
            action = action_dist.sample()
        return action.item()

    def update(self, transition_dict):
        states = torch.tensor(np.array(transition_dict["states"]), dtype=torch.float).to(self.device)
        actions = torch.tensor(np.array(transition_dict["actions"]), dtype=torch.float).view(-1, 1).to(self.device)
        rewards = torch.tensor(np.array(transition_dict["rewards"]), dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(np.array(transition_dict["next_states"]), dtype=torch.float).to(self.device)
        # print(f"next_states-->{next_states}")
        # breakpoint()
        dones = torch.tensor(np.array(transition_dict["dones"]), dtype=torch.float).view(-1, 1).to(self.device)
        td_target = rewards + self.gamma * self.critic(next_states) * (1 - dones).to(self.device)
        td_delta = td_target - self.critic(states)
        advantage = compute_advantage(self.gamma, self.lambda_, td_delta).to(self.device)
        old_log_probs = torch.log(self.actor(states).gather(1, actions.type(torch.int64))).detach()
        print(f'old_log_probs-->{old_log_probs}')

        for _ in range(self.epochs):
            log_probs = torch.log(self.actor(states).gather(1, actions.type(torch.int64)))  # 计算新的log概率
            print(f'log_probs-->{log_probs}')

            ratio = torch.exp(log_probs - old_log_probs)  # 计算比率
            print(ratio)
            breakpoint()
            surr1 = ratio * advantage
            surr2 = torch.clamp(ratio, 1 - self.eps, 1 + self.eps) * advantage
            actor_loss = torch.mean(-torch.min(surr1, surr2))
            critic_loss = torch.mean(F.mse_loss(self.critic(states), td_target.detach()))
            self.actor_optimizer.zero_grad()  # 梯度清零
            self.critic_optimizer.zero_grad()  # 梯度清零
            actor_loss.backward()  # 反向传播
            critic_loss.backward()  # 反向传播
            self.actor_optimizer.step()  # 更新参数
            self.critic_optimizer.step()  # 更新参数






def train_on_policy_agent(env, agent, num_episodes):
    return_list = []
    for i in range(epochs):
        with tqdm(total=int(num_episodes / 10), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes / 10)):
                episode_return = 0
                transition_dict = {"states": [], "actions": [], "next_states": [], "rewards": [], "dones": []}
                # [ 0.00828048  0.02124009 -0.02172656  0.0228728 ] 4维
                state = env.reset()
                # print(f"state-->{state}")
                done = False
                while not done:
                    action = agent.take_action(state)
                    next_state, reward, done, _ = env.step(action)
                    transition_dict["states"].append(state)
                    transition_dict["actions"].append(action)
                    transition_dict["next_states"].append(next_state)
                    transition_dict["rewards"].append(reward)
                    transition_dict["dones"].append(done)
                    state = next_state
                    episode_return += reward
                return_list.append(episode_return)
                agent.update(transition_dict)
                if (i_episode + 1) % 10 == 0:
                    pbar.set_postfix({'episode': '%d' % (num_episodes / 10 * i + i_episode + 1), # 计算最后10个元素的平均值
                                      'return': '%.3f' % np.mean(return_list[-10:])})
                pbar.update(1)
    return return_list


actor_lr = 1e-3
critic_lr = 1e-2
num_episodes =300
hidden_dim = 128
gamma = 0.98
lambda_ = 0.99
epochs = 10
eps = 0.2

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
env = gym.make("CartPole-v1")
state_dim = env.observation_space.shape[0]
action_dim = env.action_space.n
greediness = 0.0
ppo_agent = PPO(state_dim, hidden_dim, action_dim, actor_lr, critic_lr, lambda_, epochs, eps, gamma, device,greediness=greediness)

print(f"device: {device}")

return_list = train_on_policy_agent(env, ppo_agent, num_episodes)
iteration_list = list(range(len(return_list)))
plt.plot(iteration_list, return_list)
plt.xlabel('Iterations')
plt.ylabel('Returns')
plt.title("PPO")
plt.show()







# # 训练循环
# def train(env):
#     gamma = 0.99
#     eps_clip = 0.2
#     mini_batch_size = 5
#
#     max_episodes = 500
#     max_timesteps = 300
#     ppo_epochs = 4
#
#     for i_episode in range(max_episodes):
#         state = env.reset()
#         log_probs = []
#         values = []
#         rewards = []
#         masks = []
#         entropy = 0
#
#         for t in range(max_timesteps):
#             state = torch.FloatTensor(state)
#             policy, value = model(state)
#
#             dist = Categorical(policy)
#             action = dist.sample()
#
#             next_state, reward, done, _ = env.step(action.numpy())
#
#             log_prob = dist.log_prob(action)
#             entropy += dist.entropy().mean()
#
#             log_probs.append(log_prob)
#             values.append(value)
#             rewards.append(torch.FloatTensor([reward]))
#             masks.append(torch.FloatTensor([1 - done]))
#
#             state = next_state
#
#             if done:
#                 break
#
#         next_state = torch.FloatTensor(next_state)
#         _, next_value = model(next_state)
#         returns = compute_gae(next_value, rewards, masks, values)
#
#         returns = torch.cat(returns).detach()
#         log_probs = torch.cat(log_probs).detach()
#         values = torch.cat(values).detach()
#         states = torch.FloatTensor(states).detach()
#         actions = torch.FloatTensor(actions).detach()
#         advantage = returns - values
#
#         ppo_update(ppo_epochs, mini_batch_size, states, actions, log_probs, returns, advantage)
#
#
# # 计算广义优势估计
# def compute_gae(next_value, rewards, masks, values, gamma=0.99, tau=0.95):
#     values = values + [next_value]
#     gae = 0
#     returns = []
#
#     for step in reversed(range(len(rewards))):
#         delta = rewards[step] + gamma * values[step + 1] * masks[step] - values[step]
#         gae = delta + gamma * tau * masks[step] * gae
#         returns.insert(0, gae + values[step])
#
#     return returns


# def ppo_iter(mini_batch_size, states, actions, log_probs, returns, advantage):
#     batch_size = states.size(0)
#     for _ in range(batch_size // mini_batch_size):
#         rand_ids = np.random.choice(batch_size, mini_batch_size)
#         yield states[rand_ids, :], actions[rand_ids, :], log_probs[rand_ids, :], returns[rand_ids, :], advantage[
#                                                                                                        rand_ids, :]
#
#
# def ppo_update(ppo_epochs, mini_batch_size, clip_param, actor_critic, optimizer, states, actions, log_probs, returns,
#                advantages):
#     for _ in range(ppo_epochs):
#         for state, action, old_log_probs, return_, advantage in ppo_iter(mini_batch_size, states, actions, log_probs,
#                                                                          returns, advantages):
#             actor, critic = actor_critic(state)
#             dist = torch.distributions.Categorical(actor)
#             entropy = dist.entropy().mean()
#             new_log_probs = dist.log_prob(action)
#
#             ratio = (new_log_probs - old_log_probs).exp()
#             surr1 = ratio * advantage
#             surr2 = torch.clamp(ratio, 1.0 - clip_param, 1.0 + clip_param) * advantage
#             actor_loss = -torch.min(surr1, surr2).mean()
#             critic_loss = (return_ - critic).pow(2).mean()
#
#             loss = actor_loss + 0.5 * critic_loss - 0.001 * entropy
#
#             optimizer.zero_grad()
#             loss.backward()
#             optimizer.step()