import torch
import numpy as np


class ReplayBuffer:
    def __init__(self, args, device):
        self.device = device
        self.state_graph = np.zeros((args.batch_size, 25, args.en_graph_dim))
        self.state_user = np.zeros((args.batch_size, args.user_information_dim))
        self.state_en_bw = np.zeros((args.batch_size, args.state_en_bw_dim, 1))
        self.action = np.zeros((args.batch_size, 1))
        self.action_logprob = np.zeros((args.batch_size, 1))
        self.reward = np.zeros((args.batch_size, 1))
        self.next_state_graph = np.zeros((args.batch_size, 25, args.en_graph_dim))
        self.next_state_user = np.zeros((args.batch_size, args.user_information_dim))
        self.next_state_en_bw = np.zeros((args.batch_size, args.state_en_bw_dim, 1))
        self.dw = np.zeros((args.batch_size, 1))
        self.done = np.zeros((args.batch_size, 1))
        self.mask = np.zeros((args.batch_size, args.action_dim), dtype=bool)
        self.edge_index = np.zeros((args.batch_size, args.state_en_bw_dim, 2), dtype=np.long)
        self.count = 0
        self.batch_size = args.batch_size

    def store(self, state_user, state_graph, state_en_bw, action, action_logprob, reward, next_state_user, next_state_graph,
              next_state_en_bw, dw, done, mask, edge_index):
        self.state_graph[self.count] = state_graph
        self.state_user[self.count] = state_user
        self.state_en_bw[self.count] = state_en_bw
        self.action[self.count] = action
        self.action_logprob[self.count] = action_logprob
        self.reward[self.count] = reward
        self.next_state_graph[self.count] = next_state_graph
        self.next_state_user[self.count] = next_state_user
        self.next_state_en_bw[self.count] = next_state_en_bw
        self.dw[self.count] = dw
        self.done[self.count] = done
        self.mask[self.count] = mask.cpu().numpy()
        self.edge_index[self.count] = edge_index
        self.count += 1

    def copy_one_by_one_from(self, other_buffer):
        for i in range(other_buffer.count):
            if self.count <= 4095:
                self.state_graph[self.count] = other_buffer.state_graph[i]
                self.state_user[self.count] = other_buffer.state_user[i]
                self.state_en_bw[self.count] = other_buffer.state_en_bw[i]
                self.action[self.count] = other_buffer.action[i]
                self.action_logprob[self.count] = other_buffer.action_logprob[i]
                self.reward[self.count] = other_buffer.reward[i]
                self.next_state_graph[self.count] = other_buffer.next_state_graph[i]
                self.next_state_user[self.count] = other_buffer.next_state_user[i]
                self.next_state_en_bw[self.count] = other_buffer.next_state_en_bw[i]
                self.dw[self.count] = other_buffer.dw[i]
                self.done[self.count] = other_buffer.done[i]
                self.mask[self.count] = other_buffer.mask[i]
                self.edge_index[self.count] = other_buffer.edge_index[i]
                self.count += 1
            else:
                break

    def copy_from(self, other_buffer):
        num_elements_to_copy = min(other_buffer.count, self.batch_size - self.count)
        if num_elements_to_copy > 0:
            end_index = self.count + num_elements_to_copy
            self.state_graph[self.count:end_index] = other_buffer.state_graph[:num_elements_to_copy]
            self.state_user[self.count:end_index] = other_buffer.state_user[:num_elements_to_copy]
            self.state_en_bw[self.count:end_index] = other_buffer.state_en_bw[:num_elements_to_copy]
            self.action[self.count:end_index] = other_buffer.action[:num_elements_to_copy]
            self.action_logprob[self.count:end_index] = other_buffer.action_logprob[:num_elements_to_copy]
            self.reward[self.count:end_index] = other_buffer.reward[:num_elements_to_copy]
            self.next_state_graph[self.count:end_index] = other_buffer.next_state_graph[:num_elements_to_copy]
            self.next_state_user[self.count:end_index] = other_buffer.next_state_user[:num_elements_to_copy]
            self.next_state_en_bw[self.count:end_index] = other_buffer.next_state_en_bw[:num_elements_to_copy]
            self.dw[self.count:end_index] = other_buffer.dw[:num_elements_to_copy]
            self.done[self.count:end_index] = other_buffer.done[:num_elements_to_copy]
            self.mask[self.count:end_index] = other_buffer.mask[:num_elements_to_copy]
            self.edge_index[self.count:end_index] = other_buffer.edge_index[:num_elements_to_copy]
            self.count += num_elements_to_copy

    def numpy_to_tensor(self):
        state_graph = torch.tensor(self.state_graph, dtype=torch.float).to(self.device)
        state_user = torch.tensor(self.state_user, dtype=torch.float).to(self.device)
        state_en_bw = torch.tensor(self.state_en_bw, dtype=torch.float).to(self.device)
        action = torch.tensor(self.action, dtype=torch.long).to(
            self.device)  # In discrete action space, 'a' needs to be torch.long
        action_logprob = torch.tensor(self.action_logprob, dtype=torch.float).to(self.device)
        reward = torch.tensor(self.reward, dtype=torch.float).to(self.device)
        next_state_graph = torch.tensor(self.next_state_graph, dtype=torch.float).to(self.device)
        next_state_user = torch.tensor(self.next_state_user, dtype=torch.float).to(self.device)
        next_state_en_bw = torch.tensor(self.next_state_en_bw, dtype=torch.float).to(self.device)
        dw = torch.tensor(self.dw, dtype=torch.float).to(self.device)
        done = torch.tensor(self.done, dtype=torch.float).to(self.device)
        mask = torch.tensor(self.mask, dtype=torch.bool).to(self.device)
        edge_index = torch.tensor(self.edge_index[0], dtype=torch.long).to(self.device)

        return state_user, state_graph, state_en_bw, action, action_logprob, reward, next_state_user, next_state_graph, next_state_en_bw, dw, done, mask, edge_index
