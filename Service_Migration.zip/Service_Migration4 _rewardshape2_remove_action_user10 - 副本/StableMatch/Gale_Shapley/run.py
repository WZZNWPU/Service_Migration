import math

import numpy as np

import GS_test
from StableMatch import utils

if __name__ == '__main__':
    user_file = '../user.csv'
    en_file = '../en.csv'
    num_file = '../num.csv'
    # t=0时，先读取用户，EN的各类参数
    gs = GS_test.GaleShapleyUser(user_file, en_file, num_file)

    # 用一个列表存储所有用户的服务是否完成:t = 0时，默认所有都未完成
    is_complete = [False for i in range(gs.u_num)]

    time_slot = 2
    # 当有用户的服务没有完成时，不断循环
    while not all(is_complete):
        print('-------------------------新一轮匹配------------------------------------------')
        gs.match()
        # TODO:更新用户新的坐标
        for u in range(gs.u_num):
            gs.user_group[u].last_loc = gs.user_group[u].loc
            gs.user_group[u].loc = np.random.uniform(low=1000, high=2500, size=2)

        # 假设每 t=2 毫秒检查一次用户服务是否需要迁移
        gs.ap_set_for_u, gs.dist_set = gs.ap_set_for_user()

        gs.ap_for_user = gs.chooseAP()

        for u in range(gs.u_num):
            # 更新2毫秒后用户还需要计算的数据大小，还有用户的位置
            # gs.user_group[u].last_loc = gs.user_group[u].loc
            gs.user_group[u].t += time_slot
            print(f"原始数据大小：{gs.user_group[u].data_size}")

            gs.user_group[u].last_dl_del = gs.user_group[u].cur_dl_del

            # 2毫秒服务器可以计算的服务数据的大小为
            # done_ds = gs.EN_group[gs.user_group[u].cur_en].comp_power * gs.user_group[u].cpu_circle * time_slot
            done_ds = gs.EN_group[gs.user_group[u].cur_en].comp_power * gs.user_group[u].cpu_circle

            # 如果用户剩余数据<一个时隙服务器可以计算的服务数据,则说明用户服务已经完成
            if gs.user_group[u].data_size <= done_ds:
                gs.user_group[u].done = True
                gs.user_group[u].data_size = 0
                is_complete[u] = True
                continue
            else:
                gs.user_group[u].data_size -= done_ds
                gs.user_group[u].last_com_del = gs.user_group[u].cur_com_del - gs.user_group[u].last_com_del + time_slot
                if gs.user_group[u].t == 0:
                    gs.user_group[u].last_mig_del = 0
                else:
                    if gs.user_group[u].this_mig_time <= time_slot:
                        gs.user_group[u].refuse_mig = False
                        gs.user_group[u].this_mig_time = 0
                        gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del
                    else:
                        gs.user_group[u].refuse_mig = True
                        gs.user_group[u].this_mig_time -= time_slot
                        gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del

                # 更新用户新的坐标
                gs.user_group[u].loc = np.random.uniform(low=1000, high=2500, size=2)
                # print(f'{gs.user_group[u].loc}' )
                # 主动迁移因子设置为0.9
                v = 0.9
                # 判断用户是否需要迁移
                if (gs.user_group[u].loc == gs.user_group[u].last_loc).all():  # 用户没有移动
                    gs.user_group[u].favorNum = []  # 不需要迁移
                else:
                    a2u_down_del = gs.user_group[u].res_size / utils.tr_BU(B=gs.EN_group[gs.ap_for_user[u]].bw,
                                                                           h=gs.EN_group[gs.ap_for_user[u]].h,
                                                                           sigma=1.5 * math.pow(10, -11),
                                                                           p_b=gs.EN_group[gs.ap_for_user[u]].p,
                                                                           r=np.linalg.norm(ord=2, x=np.array(
                                                                               gs.EN_group[
                                                                                   gs.ap_for_user[
                                                                                       u]].loc) - np.array(
                                                                               gs.user_group[u].loc)))
                    gs.user_group[u].cur_dl_del = a2u_down_del + gs.user_group[u].res_size * \
                                                  gs.tr_mat[gs.ap_for_user[u]][
                                                      gs.user_group[u].cur_en]
                    print(gs.user_group[u].loc)

                    # print(
                    #     f'dist{np.linalg.norm(ord=2, x=np.array(gs.EN_group[gs.ap_for_user[u]].loc) - np.array(gs.user_group[u].loc))}')

                    print(f' gs.user_group[u].cur_dl_del-->{gs.user_group[u].cur_dl_del}')
                    print(f' gs.user_group[u].last_dl_del-->{gs.user_group[u].last_dl_del}')

                    # 如果总延迟超过了用户能接受的最大延迟，则发生迁移
                    print(
                        f'{gs.user_group[u].total_del + gs.user_group[u].cur_dl_del - gs.user_group[u].last_dl_del}-->{gs.user_group[u].max_serv_del}')
                    if gs.user_group[u].total_del + gs.user_group[u].cur_dl_del - gs.user_group[u].last_dl_del > \
                            gs.user_group[u].max_serv_del:
                        print(f'{gs.user_group[u].id}-->发生迁移')
                        gs.user_group[u].status = False
                        gs.EN_group[gs.user_group[u].cur_en].currentUsers.remove(gs.user_group[u])
                        gs.EN_group[gs.user_group[u].cur_en].currentUserNum -= 1


                        a2u_down_del = gs.user_group[u].res_size / utils.tr_BU(
                            B=gs.EN_group[gs.ap_for_user[u]].bw,
                            h=gs.EN_group[gs.ap_for_user[u]].h,
                            sigma=1.5 * math.pow(10, -11),
                            p_b=gs.EN_group[gs.ap_for_user[u]].p,
                            r=np.linalg.norm(ord=2, x=np.array(
                                gs.EN_group[
                                    gs.ap_for_user[u]].loc) - np.array(
                                gs.user_group[u].loc)))


                        down_del = [a2u_down_del for i in range(gs.en_num)]
                        print('-------------延迟------------')
                        print(f'ap_to_user_down_del:{down_del}')
                        com_del = []
                        total_del = []
                        for j in range(gs.en_num):
                            if j != gs.ap_for_user[u]:
                                down_del[j] += gs.user_group[u].res_size * gs.tr_mat[gs.ap_for_user[u]][j]

                            # 一个CPU周期的时间,单位为ns --> 转换为ms
                            circle_time = 1 / gs.EN_group[j].clock_frequency * math.pow(10, -6)
                            # print(f"一个cpu周期的时间{circle_time}")
                            # print(f"data_size{gs.user_group[u].data_size}")
                            # print(f"comp_power{gs.EN_group[j].comp_power}")
                            # print(f"cpu_circle{gs.user_group[u].cpu_circle}")
                            com_del.append(
                                gs.user_group[u].data_size / 8 * gs.EN_group[j].comp_power * 2 / gs.user_group[
                                    u].cpu_circle)
                            total_del.append(gs.user_group[u].onload_del + com_del[j] + down_del[j])
                        gs.temp_total_del.append(total_del)
                        gs.temp_com_del.append(com_del)
                        gs.temp_onload_del.append(onload_del)
                        gs.temp_dl_del.append(down_del)
                        print(f'onlad_del:{onload_del}')
                        print(f'down_del:{down_del}')
                        print(f'com_del:{com_del}')
                        print(f'total_del:{total_del}')
                        favorList = np.argsort(total_del)
                        print(favorList)
                        # 用户的偏好列表
                        gs.user_group[u].favorNum = [favorList[j] for j in range(gs.en_num) if
                                                     total_del[favorList[j]] != np.inf]
                        print(f'用户的偏好列表:{gs.user_group[u].favorNum}')
                        print('---------------------------\n')
                        pass

            print(f"剩余数据大小：{gs.user_group[u].data_size}")
            print(is_complete)
        gs.insert_user_favor()
        # break
