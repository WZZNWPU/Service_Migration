from StableMatch.School import school
from StableMatch.School.school import School
from StableMatch.Student import student
import sys

from StableMatch.Student.student import Student


# 盖尔-沙普利算法类
class GaleShapleyStu:
    def __init__(self, stu_file, school_file):
        self.stu_group = []
        self.school_group = []
        self.create_stu_group(stu_file)
        self.create_school_group(school_file)
        self.insert_stu_favor()

    # 创建学生数组
    def create_stu_group(self, stu_file):
        with open(stu_file, 'r',encoding='UTF-8') as f:
            stu_num, school_num = map(int, f.readline().split())
            for i in range(stu_num):
                name, score_str, *favor_str = map(str, f.readline().split())
                score = int(score_str)
                stu = Student(str(name), school_num, score, i)
                for j in range(school_num):
                    stu.favorNum[j] = int(favor_str[j])
                self.stu_group.append(stu)

    # 创建学校数组
    def create_school_group(self, school_file):
        with open(school_file, 'r',encoding='UTF-8') as f:
            stu_num, school_num = map(int, f.readline().split())
            for i in range(school_num):
                name, capacity = map(str, f.readline().split())
                self.school_group.append(School(str(name), int(capacity)))

    # 为每个学生写入偏好队列
    def insert_stu_favor(self):
        for stu in self.stu_group:
            stu.EntryQueue(self.school_group)

    # 定义根据盖尔-沙普利算法的申请方法
    @staticmethod
    def invitation(stu):
        # 学生当前偏好度最高的院校
        sch = stu.favor.get(0)
        # 获取当前学院最低录取分数
        sch.currentLowerScore = sch.getCurrentLowerScore()
        # 未录满情况下
        if sch.currentStuNum < sch.Contains:
            # 修改学校方的数据
            sch.currentStus.append(stu)
            sch.currentLowerScore = sch.getCurrentLowerScore()
            sch.currentStuNum += 1
            # 修改学生方的数据
            stu.status = True
            stu.currentSchool = sch.name

            # print(f"sch.Contains{sch.Contains}, len(sch.currentStus){len(sch.currentStus)}")
            print(
                f"学生:{stu.name}({stu.score})被学校:{sch.name}暂时录取，学校剩余名额{sch.Contains - len(sch.currentStus)}({sch.currentLowerScore})")
        else:
            # 院校已经录满情况下
            if stu.score < sch.currentLowerScore:
                # 分数低于当前最低录取分数的情况下直接被拒绝
                print(
                    f"学生:{stu.name}({stu.score})被学校:{sch.name}拒绝，学校剩余名额{sch.Contains - len(sch.currentStus)}({sch.currentLowerScore})")
            else:
                # 分数高于当前最低录取分数，可以暂时录取
                # 删除录取名单中分数最低的学生，并修改这名学生状
                least_stu = sch.currentStus[-1]
                least_stu.status = False
                sch.currentStus.append(stu)
                sch.currentLowerScore = sch.getCurrentLowerScore()
                stu.status = True
                stu.currentSchool = sch.name
                print(
                    f"学生:{stu.name}({stu.score})被学校:{sch.name}暂时录取，学生:{least_stu.name}({least_stu.score})被退录，学校剩余名额{sch.Contains - len(sch.currentStus)}({sch.currentLowerScore})")

    def match(self):
        num = 0
        # 开始循环进行申请
        while num != len(self.stu_group):
            print(
                "-------------------------------------------\n开始一轮邀请\n-------------------------------------------")
            num = 0
            for stu in self.stu_group:
                #  有暂时录取学校或者出局的学生不再进行本轮循环

                if stu.favor._qsize() == 0 or stu.status == True:
                    num += 1
                else:
                    self.invitation(stu)
        for stu in self.stu_group:
            print(f"Stu:{stu.name}({stu.score}) --> School:{stu.currentSchool}")


if __name__ == '__main__':
    stu_file = '../stu_file.txt'
    school_file = '../school_file.txt'
    gs = GaleShapleyStu(stu_file, school_file)
    # for i in range(len(gs.stu_group)):
    #     print(gs.stu_group[i].name)
    # for i in range(len(gs.school_group)):
    #     print(gs.school_group[i].name)
    #     print(gs.school_group[i].Contains)


    gs.match()
