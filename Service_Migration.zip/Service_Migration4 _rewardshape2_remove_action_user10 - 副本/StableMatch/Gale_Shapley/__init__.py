from StableMatch.Gale_Shapley.GS_test2 import GaleShapleyUser
