import time

from scipy.stats import truncnorm

from StableMatch import utils
from StableMatch.Configuration_Pair.EN import EN
import numpy as np
import csv
import math

# 盖尔-沙普利算法类
from StableMatch.User.user import User
from StableMatch.utils import generate_network_bandwidth
from dijkstra import dijkstra
from floydWarshall.floyd_test import floyd


class GaleShapleyUser:
    def __init__(self, user_file, en_file, num_file, traj_file):
        self.user_traj_list = []
        self.user_information_list = []
        self.user_group = []  # 用户集合
        self.EN_group = []  # 边缘服务器集合
        with open(num_file, 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                self.u_num = int(row['user_num'])
                self.en_num = int(row['en_num'])

        self.temp_total_del = [[] for _ in range(100)]
        self.temp_com_del = [[] for _ in range(100)]
        self.temp_mig_del = [[] for _ in range(100)]
        self.temp_dl_del = [[] for _ in range(100)]
        self.temp_onload_del = [[] for _ in range(100)]

        # 第一步,创建用户集合
        self.create_user_group(user_file)

        # 第二步，读取用户移动轨迹
        self.read_user_traj(traj_file)
        for u in range(self.u_num):
            # print(u)
            # print(f'用户移动轨迹：{self.user_group[u].traj}')
            self.user_group[u].loc = self.user_group[u].traj[0]

        # 第三步，创建边缘服务器集合
        self.create_EN_group(en_file)

        self.en_loc_set, self.en_r_set = self.get_loc_r_set()

        # 第四步,为用户选择接入的AP
        print('\n----------------------------------------为用户选择AP----------------------------')
        self.ap_set_for_u, self.dist_set = self.ap_set_for_user()
        self.ap_for_user = self.chooseAP()
        print('---------------------------------------------------------------------------------\n')

        self.valid_num = (self.en_num - 1) * self.en_num // 2  # 随机数的数量
        mu = 80  # 均值
        sigma = 30  # 标准差
        n = self.valid_num  # 随机数的数量
        np.random.seed(40)
        # 使用 truncnorm 函数生成截断正态分布的随机数
        self.en_bw = np.random.uniform(60, 100, self.valid_num)

        # generate_network_bandwidth(mu,sigma,self.valid_num)
        print(self.en_bw)

        # self.en_bw = np.random.uniform(low=100, high=150, size=valid_num)  # EN带宽，单位HZ[80M ~ 100M]
        # self.en_bw = np.random.normal(80,40, size=valid_num)  # EN带宽，单位HZ[80M ~ 100M]
        # print(self.en_bw)
        # 基于第三步选择的AP，基于弗洛伊德计算每个用户的最少的卸载延迟
        self.gen_users_favor_list()
        # self.gen_favor_list()

    def generate_user_favor_list_ignore_onload_latency(self, u,time_slot):
        # 计算ap到用户的距离
        ap_to_user_dist = np.linalg.norm(ord=2, x=np.array(self.EN_group[self.ap_for_user[u]].loc)
                                                  - np.array(self.user_group[u].loc))
        print(f'ap到用户的距离', {ap_to_user_dist})

        # 计算ap到用户的下载速率
        ap_to_user_download_tr = utils.tr_BU(B=self.EN_group[self.ap_for_user[u]].bw, h=self.EN_group[self.ap_for_user[u]].h,
                                             sigma=1.5 * math.pow(10, -11), p_b=self.EN_group[self.ap_for_user[u]].p,
                                             r=ap_to_user_dist) / math.pow(10, 3)

        print(f'ap到用户的下载传输速率', {ap_to_user_download_tr})

        # 计算ap到用户的下载延迟
        ap_to_user_download_latency = self.user_group[u].res_size / ap_to_user_download_tr

        down_latency_list = [ap_to_user_download_latency for i in range(self.en_num)]
        print('-------------延迟------------')
        print(f'ap_to_user_down_del:{ap_to_user_download_latency}')
        com_latency_list = []
        mig_latency_list = []
        total_latency_list = []
        for j in range(self.en_num):
            # if j != gs.ap_for_user[u]:
            down_TDM = utils.get_TDM(self.en_num, self.en_bw, self.EN_group, self.user_group[u].res_size)
            down_distance, down_path = dijkstra(down_TDM, self.ap_for_user[u], j)
            down_latency_list[j] += down_distance[j]

            # 一个CPU周期的时间,单位为ns --> 转换为ms
            circle_time = 1 / self.EN_group[j].clock_frequency * math.pow(10, -6)
            # print(f"一个cpu周期的时间{circle_time}")
            # print(f"data_size{gs.user_group[u].data_size/8}")
            # print(f"comp_power{gs.EN_group[j].comp_power}")
            # print(f"cpu_circle{gs.user_group[u].cpu_circle}")
            # print(f't-->{gs.user_group[u].t}')
            # print(f'上次计算延迟：{gs.user_group[u].last_com_del}')
            # print(f'因为发生了迁移，所以计算新的当前计算延迟{gs.user_group[u].last_com_del + gs.user_group[u].data_size / 8 * gs.EN_group[j].comp_power * 2 / gs.user_group[ u].cpu_circle}')
            com_latency_list.append(self.user_group[u].last_com_del + self.user_group[u].data_size / 8
                                    * self.EN_group[j].comp_power * time_slot / self.user_group[u].cpu_circle)
            mig_TDM = utils.get_TDM(self.en_num, self.en_bw, self.EN_group, self.user_group[u].data_size)
            mig_distance, mig_path = dijkstra(mig_TDM, self.user_group[u].cur_en, j)
            mig_latency_list.append(self.user_group[u].last_mig_del + mig_distance[j])
            total_latency_list.append(self.user_group[u].onload_del + com_latency_list[j] + down_latency_list[j]
                                      + mig_latency_list[j])

        self.temp_total_del[u] = total_latency_list
        self.temp_com_del[u] = com_latency_list

        self.temp_mig_del[u] = mig_latency_list
        self.temp_dl_del[u] = down_latency_list
        print(f'onlad_del:{self.user_group[u].onload_del}')
        print(f'down_del:{down_latency_list}')
        print(f'com_del:{com_latency_list}')
        print(f'mig_del:{mig_latency_list}')
        print(f'total_del:{total_latency_list}')
        favorList = np.argsort(total_latency_list)

        # 托管到en上的总延迟不能超过用户服务需要的最大延迟
        print(self.user_group[u].max_serv_del)
        favorList = [favorList[i] for i in favorList if total_latency_list[favorList[i]]
                     <= self.user_group[u].satisfied_serv_del]

        print(favorList)
        # 用户的偏好列表
        # self.user_group[u].favorNum = [favorList[j] for j in range(self.en_num) if
        #                                total_del[favorList[j]] != np.inf]
        if len(favorList) == 0:
            raise Exception(f'用户{u}的偏好列表为空')
        self.user_group[u].favorNum = favorList
        print([i.id for i in self.user_group[u].favor.queue])
        print(f'用户{self.user_group[u].id}的偏好列表:{self.user_group[u].favorNum}')
        print('-------------------------------------------------------------\n')

    def generate_user_favorite_list(self, u):
        """
        :param u: 用户的id
        :return:  生成该用户的偏好列表
        """

        # 计算AP到用户的距离
        user_to_ap_dist = np.linalg.norm(ord=2, x=np.array(self.EN_group[self.ap_for_user[u]].loc) -
                                                  np.array(self.user_group[u].loc))

        # 用户到连接的AP的上传链路的传输速率
        user_to_ap_up_transfer_rate = utils.tr_UB(B=self.EN_group[self.ap_for_user[u]].bw,
                                                  h=self.EN_group[self.ap_for_user[u]].h,
                                                  sigma=1.5 * math.pow(10, -11),
                                                  p_u=self.user_group[u].p,
                                                  r=user_to_ap_dist) / math.pow(10, 3)
        # 用户到连接的AP的上传延迟(卸载延迟)
        user_to_ap_upload_latency = self.user_group[u].data_size / user_to_ap_up_transfer_rate

        # print(f'ap到用户的距离', {user_to_ap_dist})
        # print(f'用户上传到ap的传输速率', {user_to_ap_upload_latency})

        # AP到用户的下行链路的传输速率
        ap_to_user_download_transfer_rate = utils.tr_BU(B=self.EN_group[self.ap_for_user[u]].bw,
                                                        h=self.EN_group[self.ap_for_user[u]].h,
                                                        sigma=1.5 * math.pow(10, -11),
                                                        p_b=self.EN_group[self.ap_for_user[u]].p,
                                                        r=user_to_ap_dist) / math.pow(10, 3)
        # print(f'从ap下载到用户的传输速率', {ap_to_user_download_transfer_rate})

        # AP到用户的下载延迟
        ap_to_user_down_latency = self.user_group[u].res_size / ap_to_user_download_transfer_rate

        # 用户上传延迟：用户到ap,ap到托管服务的边缘服务器两部分
        # 计算用户到不同边缘服务器的上传延迟
        onload_latency_list = [user_to_ap_upload_latency for i in range(self.en_num)]
        # 计算用户到不同边缘服务器的下载延迟
        download_latency_list = [ap_to_user_down_latency for i in range(self.en_num)]

        # print(f'\n----------------------用户{u}偏好列表--------------------------------')
        # print(f'用户上传到ap的的延迟:{onload_latency_list}')
        # print(f'从ap下载到用户的延迟:{download_latency_list}')
        com_latency_list = []
        total_latency_list = []

        # 初始化边缘服务器之间的传输延迟矩阵
        upload_transfer_latency_matrix = utils.get_TDM(self.en_num, self.en_bw, self.EN_group,
                                                       self.user_group[u].data_size)
        download_transfer_latency_matrix = utils.get_TDM(self.en_num, self.en_bw, self.EN_group,
                                                         self.user_group[u].res_size)
        # print(f"up_TDM\n{up_TDM}")
        # print(f"down_TDM\n{down_TDM}")

        for j in range(self.en_num):
            if j != self.ap_for_user[u]:
                # 通过dijkstra算法计算从ap到j的最小上传延迟
                min_upload_latency, min_upload_path = dijkstra(upload_transfer_latency_matrix, self.ap_for_user[u], j)
                # print(f'up_distance-->>{min_upload_latency[j]}-->{min_upload_path}')
                onload_latency_list[j] += min_upload_latency[j]

            # 通过dijkstra算法计算从ap到j的最小下载延迟
            min_down_latency, min_down_path = dijkstra(download_transfer_latency_matrix, self.ap_for_user[u], j)
            # print(f'min_down_latency-->>{min_down_latency[j]}-->{min_down_path}')

            download_latency_list[j] += min_down_latency[j]

            # 一个CPU周期的时间,单位为ns --> 转换为ms
            circle_time = 1 / self.EN_group[j].clock_frequency * math.pow(10, -6)
            # print(f"一个cpu周期的时间{circle_time}")
            # print(f"data_size{self.user_group[u].data_size/8}")
            # print(f"comp_power{self.EN_group[j].comp_power}")
            # print(f"cpu_circle{self.user_group[u].cpu_circle}")

            self.user_group[u].estimated_remaining_time = self.user_group[u].data_size / 8 * self.EN_group[
                j].comp_power * 100 / self.user_group[u].cpu_circle
            com_latency_list.append(self.user_group[u].estimated_remaining_time)
            total_latency_list.append(onload_latency_list[j] + com_latency_list[j] + download_latency_list[j])

        self.temp_total_del[u] = total_latency_list
        self.temp_com_del[u] = com_latency_list
        self.temp_onload_del[u] = onload_latency_list
        self.temp_dl_del[u] = download_latency_list
        # self.temp_mig_del = [[] for u in range(self.u_num)]

        print(f'onload_latency_list:{onload_latency_list}')
        # print(f'download_latency_list:{download_latency_list}')
        # print(f'com_latency_list:{com_latency_list}')
        # print(f'total_latency_list:{total_latency_list}')
        user_favorList = np.argsort(total_latency_list)

        # 托管到en上的总延迟不能超过用户服务需要的最大延迟
        # print(self.user_group[u].max_serv_del)
        user_favorList = [user_favorList[i] for i in user_favorList if total_latency_list[user_favorList[i]]
                          <= self.user_group[u].max_serv_del]

        # print(user_favorList)
        '''
           用户列表为空的话会报错,抛出异常
        '''
        if len(user_favorList) == 0:
            raise Exception(f'用户{u}的偏好列表为空')
        self.user_group[u].favorNum = user_favorList
        print(f'用户的偏好列表:{self.user_group[u].favorNum}')

    def gen_users_favor_list(self):
        """
         # 基于选择的AP，基于弗洛伊德计算每个用户的最少的卸载延迟
         # 同时计算每个用户在不同边缘服务器的总延迟，从而排序
        :return: 生成所有用户的偏好列表
        """
        for u in range(self.u_num):
            self.generate_user_favorite_list(u)
            # 第四步,基于服务效用为用户计算偏好列表
            self.insert_user_favor()

    def gen_favor_list(self):
        # 基于第三步选择的AP，基于弗洛伊德计算每个用户的最少的卸载延迟
        # 同时计算每个用户在不同边缘服务器的总延迟，从而排序
        for u in range(self.u_num):
            # 卸载延迟等于用户到ap,ap到托管用户服务的边缘节点
            # print(
            #     f"dsd:{utils.transfer_rate(bandwidth=self.EN_group[self.ap_for_user[u]].bw, p=500, h=0.8, sigma=10, dist=np.linalg.norm(x=np.array(self.EN_group[self.ap_for_user[u]].loc) - np.array(self.user_group[u].loc), ord=2))}")

            # print(
            #     f"dsd:{utils.tr_UB(B=self.EN_group[self.ap_for_user[u]].bw, h=self.EN_group[self.ap_for_user[u]].h, sigma=1.5 * math.pow(10, -11), p_u=self.user_group[u].p, r=np.linalg.norm(ord=2, x=np.array(self.EN_group[self.ap_for_user[u]].loc) - np.array(self.user_group[u].loc)))}")
            # print(f"data_size{self.user_group[u].data_size}")
            # print(
            #     f"dist{np.linalg.norm(ord=2, x=np.array(self.EN_group[self.ap_for_user[u]].loc) - np.array(self.user_group[u].loc))}")
            # print(f"cpu_circle{self.user_group[u].cpu_circle}")
            print(f'aaa--{self.user_group[u].data_size}')
            print(
                f'bbb--{(utils.tr_UB(B=self.EN_group[self.ap_for_user[u]].bw, h=self.EN_group[self.ap_for_user[u]].h, sigma=1.5 * math.pow(10, -11), p_u=self.user_group[u].p, r=np.linalg.norm(ord=2, x=np.array(self.EN_group[self.ap_for_user[u]].loc) - np.array(self.user_group[u].loc))) / math.pow(10, 3))}')
            u2a_up_del = self.user_group[u].data_size / (utils.tr_UB(B=self.EN_group[self.ap_for_user[u]].bw,
                                                                     h=self.EN_group[self.ap_for_user[u]].h,
                                                                     sigma=1.5 * math.pow(10, -11),
                                                                     p_u=self.user_group[u].p,
                                                                     r=np.linalg.norm(ord=2, x=np.array(
                                                                         self.EN_group[
                                                                             self.ap_for_user[u]].loc) - np.array(
                                                                         self.user_group[u].loc))) / math.pow(10, 3))

            print(f'ap到用户的距离', {np.linalg.norm(ord=2, x=np.array(
                self.EN_group[
                    self.ap_for_user[u]].loc) - np.array(
                self.user_group[u].loc))})
            print(f'ap到用户的传输速率', {utils.tr_BU(
                B=self.EN_group[self.ap_for_user[u]].bw,
                h=self.EN_group[self.ap_for_user[u]].h,
                sigma=1.5 * math.pow(10, -11),
                p_b=self.EN_group[self.ap_for_user[u]].p,
                r=np.linalg.norm(ord=2, x=np.array(
                    self.EN_group[
                        self.ap_for_user[u]].loc) - np.array(
                    self.user_group[u].loc))) / math.pow(10, 3)})

            a2u_down_del = self.user_group[u].res_size / (utils.tr_BU(B=self.EN_group[self.ap_for_user[u]].bw,
                                                                      h=self.EN_group[self.ap_for_user[u]].h,
                                                                      sigma=1.5 * math.pow(10, -11),
                                                                      p_b=self.EN_group[self.ap_for_user[u]].p,
                                                                      r=np.linalg.norm(ord=2, x=np.array(
                                                                          self.EN_group[
                                                                              self.ap_for_user[u]].loc) - np.array(
                                                                          self.user_group[u].loc))) / math.pow(10, 3))

            onload_del = [u2a_up_del for i in range(self.en_num)]
            down_del = [a2u_down_del for i in range(self.en_num)]
            print(f'\n----------------------用户{u}偏好列表--------------------------------')
            print(f'user_to_ap_onlad_del:{onload_del}')
            print(f'ap_to_user_down_del:{down_del}')
            com_del = []
            total_del = []

            # 初始化边缘服务器之间的传输延迟矩阵
            up_TDM = utils.get_TDM(self.en_num, self.en_bw, self.EN_group, self.user_group[u].data_size)
            down_TDM = utils.get_TDM(self.en_num, self.en_bw, self.EN_group, self.user_group[u].res_size)
            # print(f"up_TDM\n{up_TDM}")
            # print(f"down_TDM\n{down_TDM}")
            for j in range(self.en_num):
                if j != self.ap_for_user[u]:
                    distance, path = dijkstra(up_TDM, self.ap_for_user[u], j)
                    # print(f'up_distance-->>{distance[j]}-->{path}')
                    onload_del[j] += distance[j]

                down_distance, down_path = dijkstra(down_TDM, self.ap_for_user[u], j)
                # print(f'down_distance-->>{down_distance[j]}-->{down_path}')

                down_del[j] += down_distance[j]

                # 一个CPU周期的时间,单位为ns --> 转换为ms
                circle_time = 1 / self.EN_group[j].clock_frequency * math.pow(10, -6)
                # print(f"一个cpu周期的时间{circle_time}")
                # print(f"data_size{self.user_group[u].data_size/8}")
                # print(f"comp_power{self.EN_group[j].comp_power}")
                # print(f"cpu_circle{self.user_group[u].cpu_circle}")

                self.user_group[u].estimated_remaining_time = self.user_group[u].data_size / 8 * self.EN_group[
                    j].comp_power * 100 / self.user_group[u].cpu_circle
                com_del.append(self.user_group[u].estimated_remaining_time)
                total_del.append(onload_del[j] + com_del[j] + down_del[j])
            self.temp_total_del[u] = total_del
            self.temp_com_del[u] = com_del
            self.temp_onload_del[u] = onload_del
            self.temp_dl_del[u] = down_del
            self.temp_mig_del = [[] for u in range(self.u_num)]
            print(f'onlad_del:{onload_del}')
            print(f'down_del:{down_del}')
            print(f'com_del:{com_del}')
            print(f'total_del:{total_del}')
            favorList = np.argsort(total_del)

            # 托管到en上的总延迟不能超过用户服务需要的最大延迟
            print(self.user_group[u].max_serv_del)
            favorList = [favorList[i] for i in favorList if total_del[favorList[i]]
                         <= self.user_group[u].max_serv_del]

            print(favorList)
            # 用户的偏好列表
            # self.user_group[u].favorNum = [favorList[j] for j in range(self.en_num) if
            #                                total_del[favorList[j]] != np.inf]
            self.user_group[u].favorNum = favorList
            print(f'用户的偏好列表:{self.user_group[u].favorNum}')

            print('-----------------------------------------------------------------------------------\n')

        # 第四步,基于服务效用为用户计算偏好列表
        self.insert_user_favor()

    # 创建用户数组
    def create_user_group(self, user_file):
        with open(user_file, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            # 将读文件的信息写入列表里存放
            self.user_information_list = list(reader)
            i = 0
            for row in self.user_information_list:
                # print(i)
                if (i < self.u_num):
                    loc = (float(row['loc_x']), float(row['loc_y']))
                    u_id = int(row['u_id'])
                    cpu_circle = float(row['cpu_circle'])
                    class_for_del = int(row['class_for_del'])
                    satisfied_serv_del = float(row['satisfied_serv_del'])
                    max_serv_del = float(row['max_serv_del'])
                    data_size = float(row['input_size'])
                    result_size = float(row['result_size'])
                    p = float(row['p'])
                    user = User(u_id=u_id, loc=loc, num=u_id, cpu_circle=cpu_circle,
                                class_for_del=class_for_del, satisfied_serv_del=satisfied_serv_del,
                                max_serv_del=max_serv_del, data_size=data_size, ConfigPairNum=self.en_num,
                                res_size=result_size, p=p)
                    self.user_group.append(user)
                    i += 1
                else:
                    break

    # 创建边缘服务器EN数组
    def create_EN_group(self, EN_file):
        with open(EN_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            i = 0
            for row in reader:
                if (i < self.en_num):
                    loc = (float(row['loc_x']), float(row['loc_y']))
                    p_id = int(row['p_id'])
                    max_serv_num = int(row['max_serv_num'])
                    contains = int(row['contains'])
                    clock_frequency = float(row['clc_frequency'])
                    radius = float(row['radius'])
                    comp_power = float(row['comp_power'])
                    bw = float(row['bw'])
                    p = float(row['p'])
                    h = float(row['h'])
                    en = EN(p_id=p_id, loc=loc, max_serv_num=max_serv_num,
                            contains=contains, clock_frequency=clock_frequency,
                            radius=radius, comp_power=comp_power, bw=bw, p=p, h=h)
                    self.EN_group.append(en)
                    i += 1
                else:
                    break

    # 获取所有EN的loc和半径
    def get_loc_r_set(self):
        en_loc_set = []
        en_r_set = []
        for en in range(len(self.EN_group)):
            en_loc_set.append(self.EN_group[en].loc)
            en_r_set.append(self.EN_group[en].radius)
        # print(f'en_loc_set{en_loc_set}')
        return np.array(en_loc_set), en_r_set

    # 获取用户的AP集合
    def ap_set_for_user(self):
        # 存储每个用户的AP集合
        ap_ser_alluser = []

        # 存储每个用户的距离集合
        dist_set = []

        # 对每个用户分别计算接入点集合
        for u in range(len(self.user_group)):
            # 获取用户点的坐标
            u_loc = self.user_group[u].loc
            # print(f'用户{self.user_group[u].id}的坐标-->{u_loc}')
            u_loc_repeat = [u_loc for i in range(len(self.EN_group))]
            u_loc_repeat = np.array(u_loc_repeat)
            # print(f'u_loc_repeat\n{u_loc_repeat}')
            # print(f' self.en_loc_set\n{self.en_loc_set}')
            # 计算用户u到各个en点的距离
            dist = np.linalg.norm(ord=2, x=u_loc_repeat - self.en_loc_set, axis=1)
            dist_set.append(dist)
            ap_set = np.where(dist < self.en_r_set, True, False)
            ap_ser_alluser.append(ap_set)
            # print(f'u_{u}-->dist:\n{dist}\n')
            # print(f'radius:\n{self.en_r_set}\n')
            # print(f'u_{u}-->ap_set:\n{ap_set}\n')
        dist_set = np.array(dist_set)
        ap_ser_alluser = np.array(ap_ser_alluser)
        # print(f'dist_set:\n{dist_set}')
        # print(f'ap_ser_alluser:\n{ap_ser_alluser}')
        return ap_ser_alluser, dist_set

    # 为每个用户从AP集合里选择唯一的ap
    def chooseAP(self):
        unique_ap = []
        # 对用户的ap集合中的用户到每个ap的距离进行归一化
        for u in range(len(self.user_group)):
            dist_norm = np.where(self.ap_set_for_u[u],
                                 self.dist_set[u] / self.en_r_set,
                                 np.inf)
            # print(f"self.dist_set[u]:\n{self.dist_set[u]}\n")
            # print(f"self.en_r_set[u]:\n{self.en_r_set}\n")
            # print(f"dist_norm:\n{dist_norm}\n")
            # print(f"min:\n{np.min(dist_norm)}\n")

            if np.all(dist_norm == np.inf):
                print('\033[2;32m' + f'用户{self.user_group[u].id}无ap覆盖' + '\033[0m')
                print('\033[2;32m' + f'用户位置:{self.user_group[u].loc}无ap覆盖' + '\033[0m')
                raise Exception('用户无ap覆盖')
            else:
                self.user_group[u].cur_ap = np.argmin(dist_norm)
                unique_ap.append(np.argmin(dist_norm))

        print(unique_ap)
        return np.array(unique_ap)

    def insert_user_favor(self):
        for u in self.user_group:
            u.EntryQueue(self.EN_group)
        # pass

    def match(self):
        num = 0
        # 开始循环进行申请
        while num != self.u_num:
            print(
                "-------------------------------------------\n开始一轮邀请\n-------------------------------------------")
            num = 0
            for u in self.user_group:
                #  有暂时托管的边缘服务器或者被淘汰的用户不再进行本轮循环
                print(f'{u.id}-->{u.favor._qsize() == 0 or u.status == True}')
                if u.favor._qsize() == 0 or u.status == True:
                    num += 1
                else:
                    self.invitation(u, self.temp_total_del, self.temp_com_del, self.temp_onload_del, self.temp_mig_del)

        for user in self.user_group:
            # 用户的卸载延迟只和t=0时刻用户卸载的有关(因为用户只在t = 0时卸载)
            if user.t == 0:
                print(f"en-->{user.cur_en}")
                print(f"id-->{user.id}")
                print(self.temp_onload_del[user.id])
                user.onload_del = self.temp_onload_del[user.id][user.cur_en]
                user.cur_mig_del = 0
                user.total_del = self.temp_total_del[user.id][user.cur_en]
                user.cur_com_del = user.last_com_del + self.temp_com_del[user.id][user.cur_en]
                user.cur_dl_del = self.temp_dl_del[user.id][user.cur_en]
            else:
                print(self.temp_total_del)
                user.total_del = self.temp_total_del[user.id][user.cur_en]

                user.cur_com_del = self.temp_com_del[user.id][user.cur_en]
                print(self.temp_mig_del)
                user.cur_mig_del = user.last_mig_del + 0 if all(not item for item in self.temp_mig_del[user.id]) else \
                    self.temp_mig_del[user.id][user.cur_en]
                user.cur_dl_del = self.temp_dl_del[user.id][user.cur_en]

            print(
                f"User:{user.id}({user.cpu_circle}) --> EdgeServer:{user.cur_en}({self.EN_group[user.cur_en].Capacity})")

        # self.temp_total_del = []
        # self.temp_com_del = []
        # self.temp_mig_del = []
        # self.temp_dl_del = []
        # self.temp_onload_del = []

    # 定义根据盖尔-沙普利算法的申请方法
    @staticmethod
    def invitation(user, total_del, com_cel, onload_del, mig_del):
        # 用户当前偏好度最高的边缘服务器
        en = user.favor.get(0)
        # 获取当前边缘服务器托管的服务中需要最少资源的
        en.curLowerResource = en.get_cur_lower_resource()
        # 未录满情况下
        if user.cpu_circle + en.curConsumeResources <= en.Capacity and en.currentUserNum < en.max_serv_num:
            # 修改边缘服务器方的数据
            en.currentUsers.append(user)
            en.curLowerResource = en.get_cur_lower_resource()
            en.curConsumeResources += user.cpu_circle
            en.currentUserNum += 1
            # 修改用户方的数据
            user.status = True
            user.cur_en = en.id

            print(
                f"用户:{user.id}({user.cpu_circle})被边缘服务器:{en.id}暂时录取，边缘服务器剩余资源{en.Capacity - en.curConsumeResources}({en.curLowerResource}),边缘服务器最大托管数量{en.max_serv_num}({en.currentUserNum})")
        else:
            # 边缘服务器资源已经用完情况下
            if user.cpu_circle >= en.curLowerResource:
                # 该用户服务需要的资源大于边缘服务器最低资源的情况下直接被拒绝
                print(
                    f"用户:{user.id}({user.cpu_circle})被边缘服务器:{en.id}拒绝，边缘服务器剩余资源{en.Capacity - en.curConsumeResources}({en.curLowerResource})")
            else:
                # 服务需要的资源小于当前边缘服务器最低资源，可以暂时录取
                # 删除录取名单中资源占用最高的用户，并修改这名用户的状态
                # print(f"dwfg{len(en.currentUsers)}")
                least_user = en.currentUsers[len(en.currentUsers) - 1]
                least_user.status = False
                least_user.cur_en = None
                en.currentUsers.remove(least_user)
                en.currentUsers.append(user)
                en.curConsumeResources = en.curConsumeResources + user.cpu_circle \
                                         - least_user.cpu_circle
                # print(f"sdasda-->{len(en.currentUsers)}")
                # print(f"sdasda-->{[u.id for u in en.currentUsers]}")
                en.currentLowerScore = en.get_cur_lower_resource()
                user.status = True
                user.cur_en = en.id
                print(
                    f"用户:{user.id}({user.cpu_circle})被边缘服务器:{en.id}暂时录取，用户:{least_user.id}({least_user.cpu_circle})被退录，边缘服务器剩余资源{en.Capacity - en.curConsumeResources}({en.curLowerResource})")

    def read_user_traj(self, traj_data):
        with open(traj_data, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            self.user_traj_list = list(reader)
            for row in self.user_traj_list:
                if int(row['#Node']) < self.u_num:
                    # 将对应的用户轨迹写到对应的用户
                    loc = (float(row['X']), float(row['Y']))
                    # print(int(row['#Node']))
                    self.user_group[int(row['#Node'])].traj.append(loc)


if __name__ == '__main__':
    user_file = '../user.csv'
    en_file = '../en.csv'
    num_file = '../num.csv'
    traj_file = '../../Trajectory.csv'
    # t=0时，先读取用户，EN的各类参数
    np.random.seed(40)
    start_algorithm_time = time.time()
    gs = GaleShapleyUser(user_file, en_file, num_file, traj_file)

    # 用一个列表存储所有用户的服务是否完成:t = 0时，默认所有都未完成
    is_complete = [False for i in range(gs.u_num)]

    time_slot = 100
    match_num = 1  # 当前匹配次数
    system_time = 0  # 记录当前的系统时间

    '''
    用户按泊松分布到达
    '''
    arrival_rate = 0.005 # 用户到达的平均频率
    start_time = 200  # 区间的起始时间
    end_time = 1000  # 区间的结束时间

    interval_length = end_time - start_time  # 区间的长度

    expected_arrivals = arrival_rate * interval_length  # 期望到达次数

    arrivals = np.random.poisson(expected_arrivals)  # 生成到达次数
    arrival_times = np.sort(np.random.uniform(start_time, end_time, arrivals))
    arrival_index = 0
    print(arrival_times)

    # 当有用户的服务没有完成时，不断循环
    while not all(is_complete):
        print(f'-----------------------------第{match_num}轮匹配------------------------------------------')
        gs.match()
        for i in range(gs.en_num):
            print(
                f'边缘服务器{i}当前托管的用户为：{[u.id for u in gs.EN_group[i].currentUsers]},当前占用资源{gs.EN_group[i].curConsumeResources}/{gs.EN_group[i].Capacity}')
        print()
        print('----------------------------------------------------------------------------------------')
        match_num += 1

        # TODO:更新系统时间
        system_time += time_slot

        # TODO:更新用户新的坐标
        for u in range(gs.u_num):
            gs.user_group[u].last_loc = gs.user_group[u].loc
            gs.user_group[u].loc = gs.user_group[u].traj[int(gs.user_group[u].t / time_slot) + 1]

        # TODO:网络产生随机波动
        gs.en_bw = generate_network_bandwidth(mean=80, std_dev=25, n=gs.valid_num)
        for en in range(gs.en_num):
            gs.EN_group[en].bw = float(generate_network_bandwidth(mean=80, std_dev=25, n=1)) * math.pow(10, 6)
        # print(gs.en_bw)

        '''
         # 判断当前系统时间是否有用户到达，有用户到达则添加到用户组
        '''
        # print(f"第{match_num}轮匹配")
        # print(f"系统时间{system_time}")
        # print(f'help{arrival_times[arrival_index] < system_time and arrival_index < arrival_times.size}')
        while arrival_index < arrival_times.size and arrival_times[arrival_index] < system_time:  # 表明新用户到达
            arrival_index, is_complete = utils.new_user_arrival(traj_file, arrival_index, gs, is_complete)

        # 假设每 timeslot 毫秒检查一次用户服务是否需要迁移
        gs.ap_set_for_u, gs.dist_set = gs.ap_set_for_user()
        gs.ap_for_user = gs.chooseAP()

        for u in range(gs.u_num):
            '''
            # 对于新到达的用户，其还没有托管其服务，先不需要迁移，先为其选择托管服务的边缘服务器
            '''
            if gs.user_group[u].cur_en == np.inf:
                gs.generate_user_favorite_list(gs.user_group[u].id)
                print('---------------------------------------------------------')
                continue
            '''
             # 对于不是新到达的用户，判断是否需要迁移
            '''
            print(f'-----------------------------用户{u}是否需要迁移------------------')
            # 更新2毫秒后用户还需要计算的数据大小，还有用户的位置
            # gs.user_group[u].last_loc = gs.user_group[u].loc
            gs.user_group[u].t += time_slot
            last_ds = gs.user_group[u].data_size
            print(f"原始数据大小：{gs.user_group[u].data_size}")
            print(f"用户当前接入的AP：{gs.user_group[u].cur_ap}")
            print(f"用户当前接入的EN：{gs.user_group[u].cur_en}")

            gs.user_group[u].last_dl_del = gs.user_group[u].cur_dl_del

            # 2毫秒服务器可以计算的服务数据的大小为
            # done_ds = gs.EN_group[gs.user_group[u].cur_en].comp_power * gs.user_group[u].cpu_circle * time_slot
            # print(gs.EN_group[gs.user_group[u].cur_en].comp_power)
            print(gs.user_group[u].cpu_circle * 8)
            if gs.user_group[u].cur_en != np.inf:
                done_ds = gs.user_group[u].cpu_circle / gs.EN_group[gs.user_group[u].cur_en].comp_power * 8
                print(f'done_ds -----> {done_ds}')
            # 如果用户剩余数据<一个时隙服务器可以计算的服务数据,则说明用户服务已经完成
            if gs.user_group[u].data_size <= done_ds:
                gs.user_group[u].done = True
                gs.user_group[u].data_size = 0
                is_complete[u] = True
                # continue
            else:
                gs.user_group[u].data_size -= done_ds
                print(f'剩余数据大小 -----> {gs.user_group[u].data_size}')
                # gs.user_group[u].last_com_del = gs.user_group[u].cur_com_del - gs.user_group[u].last_com_del + time_slot

                gs.user_group[u].last_com_del = gs.user_group[u].last_com_del + time_slot \
                    if gs.user_group[u].estimated_remaining_time > time_slot else gs.user_group[u].last_com_del + \
                                                                                  gs.user_group[
                                                                                      u].estimated_remaining_time

                gs.user_group[u].estimated_remaining_time = \
                    (gs.user_group[u].estimated_remaining_time - time_slot) if gs.user_group[
                                                                                   u].estimated_remaining_time > time_slot else 0

                # 如果t==0，用户不可能发生迁移
                if gs.user_group[u].t == 0:
                    gs.user_group[u].last_mig_del = 0
                else:
                    if gs.user_group[u].this_mig_time <= time_slot:
                        gs.user_group[u].refuse_mig = False
                        gs.user_group[u].this_mig_time = 0
                        gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del
                    else:
                        gs.user_group[u].refuse_mig = True
                        gs.user_group[u].this_mig_time -= time_slot
                        gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del

                # 更新用户新的坐标
                # gs.user_group[u].loc = np.random.uniform(low=1000, high=2500, size=2)
                # print(f'{gs.user_group[u].loc}' )
                # 主动迁移因子设置为0.9
                v = 0.9
                # 判断用户是否需要迁移
                print(f"上次位置：{gs.user_group[u].last_loc}")
                print(f"这次位置：{gs.user_group[u].loc}")
                print(f'类型-->{gs.user_group[u].class_for_del}')
                str1 = "软延迟" if gs.user_group[u].class_for_del == False else "硬延迟"
                print(f"用户{gs.user_group[u].id}服务类型：{str1}")
                if np.array_equal(gs.user_group[u].loc, gs.user_group[u].last_loc):  # 用户没有移动
                    gs.user_group[u].favorNum = []  # 不需要迁移
                    print(f"用户{gs.user_group[u].id}没有移动，不需要迁移")
                else:
                    a2u_down_del = gs.user_group[u].res_size / (utils.tr_BU(B=gs.EN_group[gs.ap_for_user[u]].bw,
                                                                            h=gs.EN_group[gs.ap_for_user[u]].h,
                                                                            sigma=1.5 * math.pow(10, -11),
                                                                            p_b=gs.EN_group[gs.ap_for_user[u]].p,
                                                                            r=np.linalg.norm(ord=2, x=np.array(
                                                                                gs.EN_group[
                                                                                    gs.ap_for_user[
                                                                                        u]].loc) - np.array(
                                                                                gs.user_group[u].loc))) / math.pow(10,
                                                                                                                   3))

                    down_TDM = utils.get_TDM(gs.en_num, gs.en_bw, gs.EN_group, gs.user_group[u].res_size)
                    down_distance, down_path = dijkstra(down_TDM, gs.ap_for_user[u], gs.user_group[u].cur_en)

                    gs.user_group[u].cur_dl_del = a2u_down_del + down_distance[gs.user_group[u].cur_en]
                    print(gs.user_group[u].loc)

                    # print(
                    #     f'dist{np.linalg.norm(ord=2, x=np.array(gs.EN_group[gs.ap_for_user[u]].loc) - np.array(gs.user_group[u].loc))}')

                    print(f'a2u_down_del-->{a2u_down_del}')
                    print(f' gs.user_group[u].cur_dl_del-->{gs.user_group[u].cur_dl_del}')
                    print(f' gs.user_group[u].last_dl_del-->{gs.user_group[u].last_dl_del}')

                    # 如果总延迟超过了用户能接受的最大延迟，则发生迁移
                    print(f'onload_del-->{gs.user_group[u].onload_del}')
                    print(f'cur_com_del-->{gs.user_group[u].cur_com_del}')
                    print(f'cur_mig_del-->{gs.user_group[u].cur_mig_del}')
                    print(f'cur_dl_del-->{gs.user_group[u].cur_dl_del}')

                    delay = gs.user_group[u].onload_del + gs.user_group[u].cur_com_del + gs.user_group[u].cur_mig_del + \
                            gs.user_group[u].cur_dl_del
                    print(
                        f'delay{delay}-->max{gs.user_group[u].max_serv_del},stat{gs.user_group[u].satisfied_serv_del}')
                    print()

                    '''
                    # 分情况讨论：
                    # 1.如果用户服务是软服务且服务执行程度超过50%,且在软服务最大延迟接收范围内，则可以不迁移
                    # 2.如果用户服务是硬服务，则一旦超越满意延迟范围，则必须迁移
                    '''
                    if gs.user_group[u].class_for_del == 0 and \
                            (gs.user_group[u].init_data_size - gs.user_group[u].data_size) / gs.user_group[
                        u].init_data_size >= 0.5 \
                            and delay <= gs.user_group[u].max_serv_del:
                        print(f'软延迟服务，执行程度超过50%，不需要迁移')
                        continue
                    elif gs.user_group[u].class_for_del == 0 and delay <= gs.user_group[u].satisfied_serv_del:
                        print(f'软延迟服务，未超过最优服务体验范围，不需要迁移')
                        continue
                    elif gs.user_group[u].class_for_del == 1 and delay <= gs.user_group[u].satisfied_serv_del:
                        print(f'硬延迟服务，未超过延迟范围，不需要迁移')
                        continue
                    else:
                        # if delay > gs.user_group[u].max_serv_del:
                        print(f'{gs.user_group[u].id}-->发生迁移')
                        '''
                            # 修改用户和托管其服务的原服务器的状态
                        '''
                        utils.modify_state(gs, u)

                        '''
                            重新计算用户的偏好列表
                        '''
                        gs.generate_user_favor_list_ignore_onload_latency(u,time_slot)

            print(f"用户{gs.user_group[u].id}剩余数据大小：{last_ds}--->{gs.user_group[u].data_size}")

        print(is_complete)
        print('------------------------------------------------------------------------------------------')

        gs.insert_user_favor()
        # break

    total_del_list = []

    for u in range(gs.u_num):
        total_del_list.append(gs.user_group[u].total_del)
    print(np.array(total_del_list))
    print(np.mean(np.array(total_del_list)))
    end_algorithm_time = time.time()
    run_time = end_algorithm_time-start_algorithm_time
    print(f'算法运行时间{run_time:.6f}秒')