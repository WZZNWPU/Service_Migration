# 用户类
from queue import Queue

from StableMatch import School
import numpy as np


class User:
    def __init__(self, u_id: int, loc: tuple, num, cpu_circle,
                 class_for_del: int, satisfied_serv_del,
                 max_serv_del, data_size, ConfigPairNum,
                 res_size, p):
        # 用户id
        self.id = u_id

        # 用户的二维坐标
        self.loc = loc

        # 用户需要的CPU周期
        self.cpu_circle = cpu_circle

        # 用户服务的延迟类别 0表示软延迟,1表示硬延迟
        self.class_for_del = class_for_del

        # 用户感到满意的延迟，单位为ms
        self.satisfied_serv_del = satisfied_serv_del

        # 如果用户的服务是软延迟类型的，其实际服务延迟超出用户的满意延迟的范围
        # 用户仍然能够接受，只不过是服务体验不好，但是这个延迟范围也是有限的
        self.max_serv_del = max_serv_del if False == class_for_del else satisfied_serv_del

        # 用户服务的输入的数据大小，单位是M,需要转换为bit
        self.init_data_size = data_size * 8000000

        # 用户服务的输入的数据大小，单位是M,需要转换为bit，会随着运算时间改变
        self.data_size = data_size * 8000000

        # 用户服务的计算结果的大小，单位是M,需要转换为bit
        self.res_size = res_size * 8000000

        # 用户设备的发射功率
        self.p = p

        # 用户的偏好列表
        self.favorNum = [0] * ConfigPairNum

        # 偏好队列
        self.favor = Queue()

        # 匹配状态，是否暂时得到了某个配置对的服务 True表示暂时匹配到配置对
        self.status = False

        # 暂时匹配的配置对
        self.currentPair = ''

        # 在数组中序号
        self.numInGroup = num

        # 把用户覆盖在内的EN集合
        self.AP_Grouop = None

        # 用户的卸载延迟
        self.onload_del = 0

        # 用户的（0，1，..，t-1）时刻的计算延迟
        self.last_com_del = 0

        # 用户的（0，1，..，t-1）时刻的迁移延迟
        self.last_mig_del = 0

        # 用户的（0，1，..，t-1）时刻的下载延迟
        self.last_dl_del = 0

        # 用户的t时刻的计算延迟
        self.cur_com_del = 0

        # 用户的t时刻的迁移延迟
        self.cur_mig_del = 0

        # 用户的t时刻的下载延迟
        self.cur_dl_del = 0

        # 用户t时刻的总延迟
        self.total_del = 0

        # 用户t时刻选择的托管他服务的边缘服务器
        self.cur_en = np.inf

        # 用户暂时选择的AP
        self.cur_ap = np.inf

        # 用户服务已经完成
        self.done = False

        # 用户服务时间记录
        self.t = 0

        # 用户这次迁移的时间
        self.this_mig_time = 0

        # 用户拒绝迁移
        self.refuse_mig = False

        # 用户上一次坐标
        self.last_loc = ()

        # 预计计算完成剩余时间
        self.estimated_remaining_time = 0

        # 保存用户的移动轨迹
        self.traj = []

    # 为用户选择接入的AP结点
    def ChooseAP(self):
        # 评分基于距离+网络条件加权获取

        # 初始化各个点的评分
        score = [0 for i in range(len(self.AP_Grouop))]

        # 获取各个点的坐标和网络状况
        # aps_loc = get_loc

        # 计算用户到各个点的距离
        np.linalg.norm(self.loc, )

    # 用户计算自己对各个配置对的优先列表

    # 利用边缘服务器数组进行入队操作
    def EntryQueue(self, enGroop):
        for favorSchool in self.favorNum:
            self.favor.put(enGroop[favorSchool])

    # 用于被退录后进行状态的修改
    def ChangeState(self):
        self.status = False
        self.currentSchool = None

    # 获取暂时录取的院校名称
    def SchoolName(self) -> str:
        if self.currentSchool != '':
            print("进来了")
            print(self.currentSchool)
            return self.currentSchool
        else:
            return ' '

    # 类比较方法
    def __eq__(self, user):
        return self.cpu_circle == user.cpu_circle

    def __lt__(self, user):
        return self.cpu_circle < user.cpu_circle
#
# if __name__ == '__main__':
