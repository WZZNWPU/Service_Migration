# 学校类School
from StableMatch.Student.student import Student
from queue import Queue
from typing import List

# class School:
#     def __int__(self):
#         self.name = ''  # 学校名称
#         self.Contains = 0  # 学校预录取人数
#         self.currentStuNum = 0  # 当前录取人数
#         self.currentStus = []  # 当前预录取名单
#         self.currentLowerScore = 0.0  # 当前学校录取的最低分数
#
#     # 获取当前录取最小的分数
#     def getcurrentlowerscore(self):
#         list.sort(self.currentStus)  # 对当前名单内录取人员进行排序
#         # 未录满情况下返回0，表示只要申请的学生就能暂时录取
#         if self.currentStuNum < self.Contains:
#             return 0
#         else:
#             return self.currentStus[0].score;  # 录满情况下数组第一位表示最小录取分数
#
#     # 类比较方法
#     def __eq__(self, other):
#         return self.currentLowerScore == other.currentLowerScore
#
#     def __lt__(self, other):
#         return self.currentLowerScore < other.currentLowerScore


class School:
    def __init__(self, name_in: str, contains: int):
        self.name = name_in  # 学校名称
        self.Contains = contains  # 学校预录取人数
        self.currentStuNum = 0  # 当前录取人数
        self.currentStus = []  # 当前预录取名单
        self.currentLowerScore = 0  # 当前学校录取的最低分数

    # 获取当前录取最小的分数
    def getCurrentLowerScore(self) -> int:
        self.currentStus.sort()  # 对当前名单内录取人员进行排序
        if self.currentStuNum < self.Contains:
            return 0  # 未录满情况下返回0，表示只要申请的学生就能暂时录取
        else:
            return self.currentStus[0].score  # 录满情况下数组第一位表示最小录取分数

    # 重载比方法
    def __lt__(self, school):
        if self.name == school.name:
            return 0
        else:
            return -1
