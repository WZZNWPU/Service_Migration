import math

import numpy as np


class EN:
    def __init__(self, p_id: int, loc:tuple,
                 max_serv_num:int,contains: int,clock_frequency,
                 radius, comp_power,bw:float,p,h):
        # EN的编号id
        self.id = p_id

        # EN的坐标
        self.loc = loc

        # EN可以托管的最大服务数量
        self.max_serv_num = max_serv_num

        # EN的时钟频率
        self.clock_frequency = clock_frequency

        # EN的半径
        self.radius = radius

        # EN的CPU的计算能力（例，处理1bit数据需要多少时钟周期数）
        self.comp_power = comp_power

        # 边缘服务器的总的CPU周期
        self.Capacity = 100/(1/clock_frequency * math.pow(10,-6))

        # 当前托管服务的数量
        self.currentUserNum = 0

        # EN设备的发射功率
        self.p = p

        # EN设备的飞行高度
        self.h = h

        # 当前托管的所有服务占用的资源
        self.curConsumeResources = 0

        # 当前预托管服务的名单
        self.currentUsers = []

        # 当前EN托管的服务列表中需要最少的资源的服务的资源录需求
        self.curLowerResource = 0

        # EN为用户提供网络接入服务时的网络带宽
        self.bw = bw

    # 获取当前边缘服务器托管的服务中需要的最少资源
    def get_cur_lower_resource(self):
        self.currentUsers.sort()  # 对当前名单内用户进行排序
        if self.curConsumeResources < self.Capacity:
            return np.Inf  # 未录满情况下返回0，表示只要申请的用户就能暂时托管其服务
        else:
            return self.currentUsers[0].cpu_circle  # 录满情况下数组第一位表示最少资源


# 获取坐标
def get_loc(EN):
    return