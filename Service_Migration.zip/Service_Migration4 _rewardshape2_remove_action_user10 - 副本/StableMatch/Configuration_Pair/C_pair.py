# 配置对类
# 配置对-->AP接入点+服务放置的EN点
from StableMatch.Student.student import Student
from queue import Queue
from typing import List


class Pair:
    def __init__(self, p_id: int, loc_ap:tuple, loc_sp:tuple,
                 max_serv_num:int,contains: int,clock_frequency,
                 radius, comp_power):
        # 配置对id
        self.id = p_id

        # 配置对的接入点AP的坐标
        self.loc_ap = loc_ap

        # 配置对的服务放置点的坐标
        self.loc_sp = loc_sp

        # EN可以托管的最大服务数量
        self.max_serv_num = max_serv_num

        # EN的时钟频率
        self.clock_frequency = clock_frequency

        # EN的半径
        self.radius = radius

        # EN的CPU的计算能力（例，处理1bit数据需要多少时钟周期数）
        self.comp_power = comp_power

        self.Contains = contains  # 学校预录取人数

        # 当前托管服务的数量
        self.currentStuNum = 0

        # 当前预托管服务的名单
        self.currentStus = []

        # 当前EN托管的服务列表中需要最少的资源的服务的资源录需求
        self.currentLowerResource = 0

    # 获取坐标
    def get_ap_loc(self):
        return self.loc

    # 获取当前录取最小的分数
    def getCurrentLowerScore(self) -> int:
        self.currentStus.sort()  # 对当前名单内录取人员进行排序
        if self.currentStuNum < self.Contains:
            return 0  # 未录满情况下返回0，表示只要申请的学生就能暂时录取
        else:
            return self.currentStus[0].score  # 录满情况下数组第一位表示最小录取分数

    # 重载比方法
    def __lt__(self, school):
        if self.name == school.name:
            return 0
        else:
            return -1
