import numpy as np
import numpy as np

arrival_rate = 0.005  # 用户到达的平均频率
start_time = 200  # 区间的起始时间
end_time = 1000  # 区间的结束时间

interval_length = end_time - start_time  # 区间的长度

expected_arrivals = arrival_rate * interval_length  # 期望到达次数

arrivals = np.random.poisson(expected_arrivals)  # 生成到达次数

arrival_times = np.sort(np.random.uniform(start_time, end_time, arrivals))
print(arrival_times)