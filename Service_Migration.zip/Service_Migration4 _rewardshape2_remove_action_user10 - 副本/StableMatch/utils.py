import csv
import math

import numpy as np

# 计算总延迟
from scipy.stats import truncnorm

from StableMatch.User.user import User


def compute_total_delay(unload_flag: bool, past_mig_delay: float, past_comp_delay: float,
                        ser_done: bool, remain_ds: float, network: float):
    pass


# 计算某段信道的传输速率
def transfer_rate(bandwidth: float, p: float,
                  h: float, dist: float, sigma: float):
    """
    :param bandwidth: 网络带宽
    :param p: 发射功率
    :param h: 衰落矢量
    :param dist: 欧式距离
    :param sigma: 噪声功率
    :return: 传输速率
    """

    # print(np.log2(1 + (p * h * math.pow(dist, -3)) / math.pow(sigma, 2)))
    tr = bandwidth * np.log2(1 + (p * h * math.pow(dist, -3)) / math.pow(sigma, 2))
    return tr


# 计算某段信道(路径)传输数据的延迟
def up_del_one_path(tr: float, ds: float):
    """
    :param tr: 传输速率
    :param ds: 数据大小
    :return: 传输时间
    """

    return ds / tr


# 计算数据所需要的时间
def get_comp_time(ds, rho, cpu_circle):
    """
    :param ds: 数据大小
    :param rho: 服务器的计算能力
    :param cpu_circle: cpu周期
    :return: 计算这段数据需要的时间
    """
    return ds / (rho * cpu_circle)


# 计算用户k在时刻t的排队延迟:假设已经用户放置在该ap上
# def get_queue_delay(capacity,ap_matrix,request):


# 计算空对地路径损耗
def PL_A2G(r, h):
    """
    :param r: 水平距离,单位是m
    :param h: 高度,单位是m
    :return:
    """
    # 载波频率 单位是hz
    fc = 2.4 * math.pow(10, 9)
    # 光速 单位是m/s
    c = 299792458
    eta_LoS = 0.1
    eta_NLoS = 21
    # print(math.sqrt(r ** 2 + h ** 2))
    # print(f"sss-->{20 * math.log10(4 * math.pi * fc * math.sqrt(r ** 2 + h ** 2) / c)}")
    return 20 * math.log(4 * math.pi * fc * math.sqrt(r ** 2 + h ** 2) / c) + \
           PL_LoS(r, h) * eta_LoS + (1 - PL_LoS(r, h)) * eta_NLoS


def PL_LoS(r, h):
    a = 4.88
    b = 0.43
    return 1 / (1 + a * (math.exp(-b * math.atan2(h, r) - a)))


# 计算空对空路径损耗
def PL_A2A(d):
    """
    :param d: 无人机之间的距离，单位是km
    :return:
    """
    # 载波频率，单位是兆赫兹 2.4Ghz--->2.4e3 Mhz
    fc = 2.4 * math.pow(10, 3)
    return 32.45 + 20 * math.log(fc) + 20 * math.log(d)


# 计算用户设备到无人机的无线信道的数据传输速率
def tr_UB(B, r, h, sigma, p_u):
    return B * math.log2(1 + (p_u * math.pow(10, -PL_A2G(r, h) / 10))
                         / (math.pow(sigma, 2)))


# 计算无人机到用户设备的无线信道的数据传输速率
def tr_BU(B, r, h, sigma, p_b):
    return B * math.log2(1 + (p_b * math.pow(10, -PL_A2G(r, h) / 10))
                         / (math.pow(sigma, 2)))


# 计算无人机到无人机的无线信道的数据传输速率
def tr_UU(B, sigma, d, p_u):
    """

    :param B: 带宽，单位是hz
    :param sigma:
    :param d: 距离，单位是km
    :param p_u: 发射功率，单位w
    :return:
    """
    # 将m转换为km
    d = d / 1000.0
    # print(d)
    # print( -PL_A2A(d)/ 10)
    return B * math.log2(1 + (p_u * math.pow(10, -PL_A2A(d) / 10))
                         / (math.pow(sigma, 2)))


# 信道间传输延迟计算
def get_TDM(en_num, en_bw, EN_group, datasize):
    # np.random.seed(628)

    TDM = np.zeros(shape=(en_num, en_num))
    k = 0
    for i in range(1, en_num):
        for j in range(i):
            # 计算i--->j的传输速率
            distance_ap_to_ap = np.linalg.norm(x=np.array(EN_group[i].loc) - np.array(EN_group[j].loc),
                                               ord=2)
            if distance_ap_to_ap >= (EN_group[i].radius + EN_group[j].radius):
                bandwidth = 1e-15  # 表示两个边缘服务器没有直连，带宽几乎为0
            else:
                bandwidth = en_bw[k] * 1e6
            t_rate = tr_UU(B=bandwidth, sigma=1.5 * math.pow(10, -11),
                           d=distance_ap_to_ap,
                           p_u=EN_group[i].p) / math.pow(10, 3)
            TDM[i, j] = datasize / t_rate
            TDM[j, i] = datasize / t_rate
            k = k + 1
    # print(TDM)
    # print('-----------------------------------------------------------\n')
    return TDM


# 随机生成n个信道的网络带宽
def generate_network_bandwidth(mean, std_dev, n):
    lower_bound = 5
    upper_bound = 100
    # bandwidths = np.random.normal(mean, std_dev, n)  # 使用正态分布生成网络带宽
    bandwidths = truncnorm((lower_bound - mean) / std_dev, (upper_bound - mean) / std_dev, loc=mean, scale=std_dev).rvs(
        size=n)

    return bandwidths


# 仿真新用户到达
def new_user_arrival(traj_file, arrival_index, gs, is_complete):
    gs.u_num += 1
    # print(gs.user_information_list)
    row = gs.user_information_list[gs.u_num - 1]
    loc = (float(row['loc_x']), float(row['loc_y']))
    u_id = int(row['u_id'])
    # print(row)
    # print(u_id)
    cpu_circle = float(row['cpu_circle'])
    class_for_del = int(row['class_for_del'])
    satisfied_serv_del = float(row['satisfied_serv_del'])
    max_serv_del = float(row['max_serv_del'])
    data_size = float(row['input_size'])
    result_size = float(row['result_size'])
    p = float(row['p'])
    user = User(u_id=u_id, loc=loc, num=u_id, cpu_circle=cpu_circle,
                class_for_del=class_for_del, satisfied_serv_del=satisfied_serv_del,
                max_serv_del=max_serv_del, data_size=data_size, ConfigPairNum=gs.en_num,
                res_size=result_size, p=p)
    gs.user_group.append(user)
    with open(traj_file, 'r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        # rows = list(reader)
        # row = rows[gs.u_num-1]
        for row in reader:
            if int(row['#Node']) == gs.u_num - 1:
                # 将对应的用户轨迹写到对应的用户
                loc = (float(row['X']), float(row['Y']))
                # print(int(row['#Node']))
                gs.user_group[int(row['#Node'])].traj.append(loc)
    is_complete.append(False)
    arrival_index += 1
    print(f'arrival_index-->{arrival_index}')
    return arrival_index, is_complete


def modify_state(gs, u):
    # 因为要迁移，所以用户要换托管其服务的边缘服务器，所以其状态修改为False
    gs.user_group[u].status = False

    # 清空当前用户的偏好队列
    while not gs.user_group[u].favor.empty():
        gs.user_group[u].favor.get()

    # 修改对应的en的状态
    # print(gs.user_group[u].cur_en)
    # print(gs.user_group[u].id)

    # if gs.user_group[u] in gs.EN_group[gs.user_group[u].cur_en].currentUsers:
    #     print('sdasdasd')
    gs.EN_group[gs.user_group[u].cur_en].currentUsers.remove(gs.user_group[u])
    gs.EN_group[gs.user_group[u].cur_en].currentUserNum -= 1
    gs.EN_group[gs.user_group[u].cur_en].curConsumeResources -= gs.user_group[u].cpu_circle


if __name__ == '__main__':
    B = 100 * math.pow(10, 6)

    # 分贝为-127dbm 噪声功率为
    sigma = 2 * math.pow(10, -10)
    d = 1000
    p_u = 1.5
    print(PL_A2A(d))
    print(tr_UU(B, sigma, d, p_u))

    h = 70
    r = 400
    p_u = 1.5
    print(PL_A2G(r, h))
    print(tr_UB(B, r, h, sigma, p_u))
