# 学生类
from queue import Queue

from StableMatch import School


class Student:
    def __init__(self, name_in, SchoolNum, MyScore, num):
        self.name = name_in  # 学生姓名
        self.favorNum = [0] * SchoolNum  # 利用学校序号进行入队操作
        self.favor = Queue()  # 偏好队列
        self.status = False  # 录取状况，是否暂时被录取
        self.currentSchool = ''  # 暂时录取院校
        self.score = MyScore  # 考试分数
        self.numInGroup = num  # 在数组中序号
        print(self.favorNum)

    # 利用学校数组进行入队操作
    def EntryQueue(self, SchoolGroop):
        for favorSchool in self.favorNum:
            self.favor.put(SchoolGroop[favorSchool])

    # 用于被退录后进行状态的修改
    def ChangeState(self):
        self.status = False
        self.currentSchool = None

    # 获取暂时录取的院校名称
    def SchoolName(self) -> str:
        if self.currentSchool != '':
            print("进来了")
            print(self.currentSchool)
            return self.currentSchool
        else:
            return ' '

    # 类比较方法
    def __eq__(self, stu):
        return self.score == stu.score

    def __lt__(self, stu):
        return self.score < stu.score
