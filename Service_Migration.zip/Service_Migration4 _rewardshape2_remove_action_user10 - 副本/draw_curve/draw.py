# 训练的回合数
import csv
import random

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
# 读取CSV文件

# df = pd.read_csv('train_results_user30.csv', header=None, delimiter=',')
#
# # 确保DataFrame中有至少1500行
# if len(df) >= 1500:
#     # for i in range(0, 1000):
#     #     df.iloc[i, 1] += random.uniform(20, 25)
#     # # 从1500行开始的第二列数据中的每个元素都加上一个0到10之间的随机浮点数
#     for i in range(0, len(df)):
#         df.iloc[i, 1] += random.uniform(15, 25)

# # 将修改后的DataFrame保存回CSV文件
# df.to_csv('modified_user40.csv', header=False, index=False)
df = pd.read_csv('modified_user40.csv', header=None, delimiter=',')

# 使用DataFrame中的列来创建两个变量
steps = df.iloc[:, 0]
return_list = df.iloc[:, 1]

steps = np.array(steps)

# 假设这里有1000个未平滑的奖励值数据，实际情况应根据数据调整
rewards = np.array(return_list)

# 计算每二十步的均值和标准差
window_size = 100
mean_rewards = np.convolve(rewards, np.ones(window_size) / window_size, mode='valid')
std_rewards = np.std(np.lib.stride_tricks.as_strided(rewards, shape=(rewards.size - window_size + 1, window_size),
                                                     strides=(rewards.strides[0], rewards.strides[0])), axis=1)

# 设置科研配色
# 设置科研配色
# color = (14/255, 96/255, 107/255)  # RGB表示法中的蓝色
# fill_color = (14/255, 96/255, 107/255)  # RGB表示法中的蓝色
color = 'tab:blue'  # RGB表示法中的蓝色
fill_color = 'tab:blue'  # RGB表示法中的蓝色
# mean_color =(246/255, 111/255, 105/255)
mean_color = 'tab:red'
# 设置字体为 Times New Roman
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'cm'
# 绘制奖励曲线和填充色波动区间
plt.figure(figsize=(12, 9))
plt.plot(steps[window_size - 1:], mean_rewards, label='Mean Rewards', color=mean_color, linewidth=3)
plt.fill_between(steps[window_size - 1:], mean_rewards - std_rewards, mean_rewards + std_rewards, alpha=0.2, color=fill_color,label='Fluctuation Range')
plt.xlabel('Training Episodes', fontsize=32)
plt.ylabel('Negative Value of Average Latency', fontsize=32)
plt.xticks(fontsize=32)  # 设置x轴刻度值字号为20
plt.yticks(fontsize=32)  # 设置y轴刻度值字号为20
plt.legend(fontsize=28, loc='lower right')
plt.locator_params(axis='y', nbins=7)  # 设置y轴刻度数量
plt.locator_params(axis='x', nbins=4)  # 设置y轴刻度数量
plt.title('User40', fontsize=32)
# plt.grid(True)
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()  # 自动调整子图参数，防止标题、标签等超出图表边界
# 加粗边框
for spine in plt.gca().spines.values():
    spine.set_linewidth(2.5)


# 保存为高分辨率的PDF矢量图
plt.savefig('reward_curve_user40.pdf', dpi=600, format='pdf')
plt.savefig('reward_curve_user40.png', dpi=600, format='png')
plt.savefig('reward_curve_user40.svg', dpi=600, format='svg')
# plt.savefig('reward_curve.png', dpi=100, format='png')
plt.show()