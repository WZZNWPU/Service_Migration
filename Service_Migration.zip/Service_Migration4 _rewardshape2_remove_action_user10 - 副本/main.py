#
# import matplotlib.pyplot as plt
# import numpy as np
#
# # 输入圆心和半径
# # center = (0, 0)  # 圆心坐标 (x, y)
# # radius = 5  # 圆的半径
#
# # 输入圆心和半径
# center = (1000, 2000)  # 圆心坐标 (x, y)
# radius =1000  # 圆的半径
#
#
# # 生成圆的数据
# theta = np.linspace(0, 2*np.pi, 100)  # 角度从0到2π
# x = center[0] + radius * np.cos(theta)  # x = cx + r*cos(θ)
# y = center[1] + radius * np.sin(theta)  # y = cy + r*sin(θ)
#
#
# # 绘制圆形
# plt.plot(x, y)
#
#
# # 输入圆心和半径
# center = (1500, 1600)  # 圆心坐标 (x, y)
# radius = 899  # 圆的半径
#
#
# # 生成圆的数据
# theta = np.linspace(0, 2*np.pi, 100)  # 角度从0到2π
# x = center[0] + radius * np.cos(theta)  # x = cx + r*cos(θ)
# y = center[1] + radius * np.sin(theta)  # y = cy + r*sin(θ)
#
#
# # 绘制圆形
# plt.plot(x, y)
#
#
# # 输入圆心和半径
# center = (3000, 2500)  # 圆心坐标 (x, y)
# radius = 1100  # 圆的半径
#
#
# # 生成圆的数据
# theta = np.linspace(0, 2*np.pi, 100)  # 角度从0到2π
# x = center[0] + radius * np.cos(theta)  # x = cx + r*cos(θ)
# y = center[1] + radius * np.sin(theta)  # y = cy + r*sin(θ)
#
#
# # 绘制圆形
# plt.plot(x, y)
# x=1650
# y=1400
#
# plt.scatter(x,y)
# x=2100
# y=2000
#
# plt.scatter(x,y)
# x=1000
# y=2200
#
# plt.scatter(x,y)
# # 设置坐标轴范围
# plt.xlim(0, 10000)
# plt.ylim(0, 10000)
#
# # 添加标题和标签
# plt.title("Circle")
# plt.xlabel("X")
# plt.ylabel("Y")
#
# # 显示图形
# plt.axis('equal')  # 设置坐标轴比例相等，保证圆形不会变形
# plt.grid(True)  # 显示网格线
# plt.show()
import math
import numpy as np
greedy = 0.3
for i in range(100):
    for i_eps in range(30):

       #b = np.log(0.9 / 0.3)

    # greedy = 0.3 * np.exp(b * i/1200)
        greedy = 0.95*math.exp(-1.1*(3000-i*30-i_eps)/3000)
        print(greedy)
# start = 0.3
# end = 0.9
# len = 1200
# x = np.linspace(start, end, len)
# value = math.exp(x-1)
# print(value)

