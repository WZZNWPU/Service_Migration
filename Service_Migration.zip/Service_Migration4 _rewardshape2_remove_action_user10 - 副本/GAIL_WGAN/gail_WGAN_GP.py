import argparse

import numpy as np
from matplotlib import pyplot as plt
from torch import nn, autograd
import torch
import torch.nn.functional as F
from torch.linalg import svd
from torch.nn import init
from torch.nn.utils import spectral_norm
from torch.optim.lr_scheduler import ExponentialLR
from torch.utils.data import BatchSampler, SubsetRandomSampler
from tqdm import tqdm
import torch_geometric.nn as geo_nn
from collections import deque
from torch_geometric.data import Data, Batch

from imitation_learning.PPO_test import PPO
from imitation_learning.run_PPO import train_on_policy_agent


# # 定义图神经网络模块
# class GraphNetwork(nn.Module):
#     def __init__(self, input_dim, hidden_dim, output_dim, device):
#         super(GraphNetwork, self).__init__()
#
#         self.conv1 = geo_nn.GCNConv(input_dim, hidden_dim).to(device)
#         self.relu = nn.ReLU().to(device)
#         self.conv2 = geo_nn.GCNConv(hidden_dim, 128).to(device)
#         self.conv3 = geo_nn.GCNConv(hidden_dim, 128).to(device)
#         # self.conv4 = geo_nn.GCNConv(hidden_dim, 128).to(device)
#         self.conv5 = geo_nn.GCNConv(128, output_dim).to(device)
#
#         # 对图卷积层的权重张量应用谱归一化
#         self.conv1.lin.weight = nn.Parameter(self.spectral_norm(self.conv1.lin.weight))
#         self.conv2.lin.weight = nn.Parameter(self.spectral_norm(self.conv2.lin.weight))
#         self.conv3.lin.weight = nn.Parameter(self.spectral_norm(self.conv3.lin.weight))
#         self.conv5.lin.weight = nn.Parameter(self.spectral_norm(self.conv5.lin.weight))
#
#         self.init_parameters()
#     def spectral_norm(self, weight):
#         # Calculate the spectral norm of the weight matrix
#         sigma, _ = torch.symeig(torch.matmul(weight.t(), weight), eigenvectors=True)
#         sigma_max = sigma[-1].item()
#         return weight / sigma_max
#
#     # def spectral_norm(self, weight, power_iteration=5):
#     #     # 使用Power Iteration方法估计最大奇异值
#     #     with torch.no_grad():
#     #         u = torch.randn(weight.size(0), 1, device=weight.device)
#     #         for _ in range(power_iteration):
#     #             v = torch.matmul(weight, u)
#     #             u = v / v.norm()
#     #
#     #         sigma = torch.matmul(u.t(), torch.matmul(weight, v)).item()
#     #         return weight / sigma
#     # def spectral_norm(self, weight):
#     #     # Compute the spectral norm of the weight matrix
#     #     with torch.no_grad():
#     #         u = torch.randn(weight.size(0), 1, device=weight.device)
#     #         v = torch.matmul(weight, u)
#     #         v = v / v.norm()
#     #         for _ in range(10):
#     #             u = torch.matmul(weight.t(), v)
#     #             u = u / u.norm()
#     #             v = torch.matmul(weight, u)
#     #             v = v / v.norm()
#     #
#     #         sigma = torch.dot(u.squeeze(), torch.matmul(weight, v).squeeze())
#     #         return weight / sigma
#
#     def init_parameters(self):
#         # Xavier初始化conv1的权重和偏置
#         init.xavier_uniform_(self.conv1.lin.weight)
#         init.zeros_(self.conv1.bias)
#
#         # Xavier初始化conv2的权重和偏置
#         init.xavier_uniform_(self.conv2.lin.weight)
#         init.zeros_(self.conv2.bias)
#
#         # Xavier初始化conv2的权重和偏置
#         init.xavier_uniform_(self.conv3.lin.weight)
#         init.zeros_(self.conv3.bias)
#
#         # # Xavier初始化conv2的权重和偏置
#         # init.xavier_uniform_(self.conv4.lin.weight)
#         # init.zeros_(self.conv4.bias)
#
#         # Xavier初始化conv2的权重和偏置
#         init.xavier_uniform_(self.conv5.lin.weight)
#         init.zeros_(self.conv5.bias)
#
#
#
#     def forward(self, x, edge_index, edge_attr):
#
#         residual = x  # 保存原始输入作为残差连接
#         x = self.conv1(x, edge_index, edge_attr)
#         x = self.relu(x)
#         x = self.conv2(x, edge_index, edge_attr)
#         x = self.relu(x)
#         x = self.conv3(x, edge_index, edge_attr)
#         x = self.relu(x)
#         # x = self.conv4(x, edge_index, edge_attr)
#         # x = self.relu(x)
#         x = self.conv5(x, edge_index, edge_attr)
#         x += residual  # 添加残差连接
#         return x
# 定义图神经网络模块
class GraphNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, device):
        super(GraphNetwork, self).__init__()

        self.conv1 = geo_nn.GCNConv(input_dim, hidden_dim).to(device)
        self.relu = nn.LeakyReLU().to(device)
        self.conv2 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        # self.conv3 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        # self.conv4 = geo_nn.GCNConv(hidden_dim, 128).to(device)
        self.conv5 = geo_nn.GCNConv(128, output_dim).to(device)
        self.init_parameters()

    def init_parameters(self):
        # Xavier初始化conv1的权重和偏置
        init.orthogonal_(self.conv1.lin.weight)
        init.zeros_(self.conv1.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv2.lin.weight)
        init.zeros_(self.conv2.bias)

        # # Xavier初始化conv2的权重和偏置
        # init.orthogonal_(self.conv3.lin.weight)
        # init.zeros_(self.conv3.bias)
        #
        # # Xavier初始化conv2的权重和偏置
        # init.xavier_uniform_(self.conv4.lin.weight)
        # init.zeros_(self.conv4.bias)

        # Xavier初始化conv2的权重和偏置
        init.orthogonal_(self.conv5.lin.weight)
        init.zeros_(self.conv5.bias)

    def forward(self, x, edge_index, edge_attr):
        residual = x  # 保存原始输入作为残差连接
        x = self.conv1(x, edge_index, edge_attr)
        x = self.relu(x)
        x = self.conv2(x, edge_index, edge_attr)
        x = self.relu(x)
        # x = self.conv3(x, edge_index, edge_attr)
        # x = self.relu(x)
        # x = self.conv4(x, edge_index, edge_attr)
        # x = self.relu(x)
        x = self.conv5(x, edge_index, edge_attr)
        x += residual  # 添加残差连接
        return x


class Discriminator(nn.Module):
    def __init__(self, en_graph_dim, user_information_dim, state_dim, action_dim, device):
        super(Discriminator, self).__init__()
        # 对状态信息进行特征提取
        self.gcn = GraphNetwork(en_graph_dim, hidden_dim=128, output_dim=5, device=device)  # 采用图卷积提取边缘节点的特征

        # self.feature_extractor = nn.Sequential(  # 采用全连接神经网络提取用户的信息特征
        #     nn.Linear(user_information_dim, 128).to(device),
        #     nn.LeakyReLU(),
        #     nn.Linear(128, 4).to(device)
        # )
        #
        self.feature_extractor2 = nn.Sequential(  # 采用全连接神经网络提取图卷积后的信息特征
            nn.Linear(25 * 5, 256).to(device),
            nn.LeakyReLU(),
            nn.Linear(256, 128).to(device),
            nn.LeakyReLU(),
            nn.Linear(128, 64).to(device),
            nn.LeakyReLU(),
            nn.Linear(64, 32).to(device),
        )

        self.fc1 = torch.nn.Linear(32 + 8 + action_dim, 128)
        self.fc2 = torch.nn.Linear(128, 128)
        self.fc3 = torch.nn.Linear(128, 128)
        # self.fc4 = torch.nn.Linear(128, 128)
        # self.fc5 = torch.nn.Linear(256, 256)
        # self.fc6 = torch.nn.Linear(256, 256)
        # self.fc7 = torch.nn.Linear(256, 256)
        self.fc8 = torch.nn.Linear(128, 1)

        # 初始化参数
        self.init_parameters()

    def init_parameters(self):
        def init_weights(m):
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

        self.apply(init_weights)

    def forward(self, x, a):
        graph_data, user_information = x[0], x[1]
        nodes_ferature, edge_index, edge_attr = graph_data.x, graph_data.edge_index, graph_data.edge_attr
        batchsize = int(nodes_ferature.shape[0] / 25)
        # print(f'nodes_ferature-->{nodes_ferature}')
        # print(f'edge_index-->{edge_index}')
        # print(f'edge_attr-->{edge_attr}')
        # print(f'batchsize-->{batchsize}')

        # output1 = self.gcn(nodes_ferature, edge_index, edge_attr)  # output1-->torch.Size([25, 64])
        # # print(f'output1-->{output1.shape}')
        # output2 = self.feature_extractor(user_information)  # output2-->torch.Size([64])
        #
        # # 将特征图展品 3300*16--->52800
        # output6 = output1.clone().view(batchsize, -1)
        # # print(f'output6-->{output6.shape}')
        # # output3 = output6.clone().view(batchsize,-1)  # output1-->torch.Size([1600])
        # output3 = output6.clone()  # output1-->torch.Size([1600])
        #
        # # 对展平后的向量提取特征
        # output4 = self.feature_extractor2(output3.clone())
        # # print(f'output4-->{output4.shape}')
        # # print(f'output2-->{output2.shape}')
        # # 进行向量拼接 (192,)
        # output5 = torch.cat((output4, output2), dim=-1)  # 特征融合后的状态信息 torch.Size([192])
        # # print(f'output5-->{output5.shape}')
        # print(output5.shape)
        # print(a.shape)
        # # breakpoint()
        # cat = torch.cat([output5, a], dim=1)

        output1 = self.gcn(nodes_ferature, edge_index, edge_attr)  # output1-->torch.Size([25, 64])

        # 将特征图展品 3300*16--->52800
        output6 = output1.clone().view(batchsize, -1)
        output3 = output6.clone()  # output1-->torch.Size([1600])
        output4 = self.feature_extractor2(output3.clone())
        output5 = torch.cat((output4, user_information), dim=-1)  # 特征融合后的状态信息 torch.Size([192])
        # print(output5.shape)
        # print(a.shape)
        # breakpoint()
        cat = torch.cat([output5, a], dim=1)

        x = F.relu(self.fc1(cat))  # ReLU激活函数
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        # x = F.relu(self.fc4(x))
        # x = F.relu(self.fc5(x))
        # x = F.relu(self.fc6(x))
        # x = F.relu(self.fc7(x))
        return self.fc8(x)


class GAIL:
    def __init__(self, agent, args, device):
        self.discriminator = Discriminator(args.en_graph_dim, args.user_information_dim, args.state_dim, args.action_dim,
                                           device).to(device)
        self.discriminator_optimizer = torch.optim.RMSprop(self.discriminator.parameters(), lr=args.discriminator_lr, )
        self.agent = agent
        self.device = device
        self.disc_scheduler = ExponentialLR(self.discriminator_optimizer, gamma=0.98)

    def calculate_gradient_penalty(self, real_data, fake_data, expert_actions, agent_actions):
        batch_size = real_data.shape[0]
        alpha = torch.rand(batch_size, 1).to(self.device)
        alpha = alpha.expand(batch_size, real_data.nelement() // batch_size).contiguous().view(*real_data.shape)
        interpolates = alpha * real_data + (1 - alpha) * fake_data
        interpolates.requires_grad_(True)

        disc_interpolates = self.discriminator(interpolates, agent_actions)
        gradients = torch.autograd.grad(outputs=disc_interpolates, inputs=interpolates,
                                        grad_outputs=torch.ones(disc_interpolates.size()).to(self.device),
                                        create_graph=True, retain_graph=True, only_inputs=True)[0]
        gradients = gradients.view(batch_size, -1)
        gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
        return gradient_penalty

    # def learn(self, expert_s_user, expert_s_graph, expert_s_en_bw, expert_a, expert_s_edge_indexs,
    #           agent_s_user, agent_s_graph, agent_s_en_bw, agent_a,
    #           next_s_user,next_s_graph,next_s_en_bw, dones):
    def learn(self, expert_s_user, expert_s_graph, expert_s_en_bw, expert_a, expert_s_edge_indexs,
              replay_buffer,count_special):
        expert_states_user = torch.tensor(expert_s_user, dtype=torch.float).to(self.device)
        expert_states_graph = torch.tensor(expert_s_graph, dtype=torch.float).to(self.device)
        expert_states_en_bw = torch.tensor(expert_s_en_bw, dtype=torch.float).to(self.device)
        expert_actions = torch.tensor(expert_a, dtype=torch.int64).to(self.device)

        state_user, state_graph, state_en_bw, action, action_logprob, reward, next_state_user, next_state_graph, next_state_en_bw, dw, done, mask, edge_index = replay_buffer.numpy_to_tensor()  # Get training data
        agent_states_user = state_user
        agent_states_graph = state_graph
        agent_states_en_bw = state_en_bw
        # print(expert_s_edge_indexs[0])
        # breakpoint()
        edge_index = torch.tensor(expert_s_edge_indexs[0], dtype=torch.long).to(self.device)  # torch.Size([114, 2])
        edge_index_ = edge_index.clone().t().contiguous()  # 边索引 torch.Size([2, 114])
        agent_actions = action.squeeze()

        expert_actions = F.one_hot(expert_actions, num_classes=26).float()
        agent_actions = F.one_hot(agent_actions, num_classes=26).float()

        states_graph_data_list = []
        for state_id in range(expert_states_user.shape[0]):
            # edge_nodes_feature = torch.tensor(data=expert_states_graph[state_id], dtype=torch.float).to(
            # self.device)  # torch.Size([25, 5])
            edge_nodes_feature = expert_states_graph[state_id].clone().detach().to(torch.float).to(self.device)

            edge_attr = expert_states_en_bw[state_id].clone().detach().to(torch.float).to(self.device)

            # edge_attr = torch.tensor(expert_states_en_bw[state_id], dtype=torch.float).to(self.device)  # 边权重,带宽

            en_graph_data = Data(x=edge_nodes_feature, edge_index=edge_index_,
                                 edge_attr=edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
            en_graph_data = en_graph_data.to(self.device)
            states_graph_data_list.append(en_graph_data)
        expert_states_batch = Batch.from_data_list(states_graph_data_list)
        expert_states = [expert_states_batch, expert_states_user]

        agent_states_graph_data_list = []
        for state_id in range(agent_states_user.shape[0]):
            agent_edge_nodes_feature = agent_states_graph[state_id].clone().detach().to(torch.float).to(self.device)

            agent_edge_attr = agent_states_en_bw[state_id].clone().detach().to(torch.float).to(self.device)
            # agent_edge_nodes_feature = torch.tensor(data=agent_states_graph[state_id], dtype=torch.float).to(
            #     self.device)  # torch.Size([25, 5])

            # agent_edge_attr = torch.tensor(agent_states_en_bw[state_id], dtype=torch.float).to(self.device)  # 边权重,带宽

            agent_en_graph_data = Data(x=agent_edge_nodes_feature, edge_index=edge_index_,
                                       edge_attr=agent_edge_attr)  # Data(x=[25,5], edge_index=[2, 114])
            agent_en_graph_data = agent_en_graph_data.to(self.device)
            agent_states_graph_data_list.append(agent_en_graph_data)
        agent_states_batch = Batch.from_data_list(agent_states_graph_data_list)
        agent_states = [agent_states_batch, agent_states_user]

        # num_discriminator_updates
        if count_special > 80:
            update_times1 = 2
        else:
            update_times1 = 2
        for _ in range(update_times1): # 默认判别器2 生成器 2
            # for index in BatchSampler(SubsetRandomSampler(range(agent_states_user.size(0))), 512, False):
            # expert_states_graph_mini_batch = Batch.from_data_list(expert_states_batch[index])
            # expert_states_mini_batch = [expert_states_graph_mini_batch, expert_states_user[index]]
            # expert_prob = self.discriminator(expert_states, expert_actions)
            #
            # agent_states_graph_mini_batch = Batch.from_data_list(agent_states_batch[index])
            # agent_states_mini_batch  = [agent_states_graph_mini_batch, agent_states_user[index]]
            #
            # agent_prob = self.discriminator(agent_states_mini_batch, agent_actions[index])

            expert_prob = self.discriminator(expert_states, expert_actions)
            agent_prob = self.discriminator(agent_states, agent_actions)

            # 计算 Wasserstein GAN 损失
            self.discriminator_loss = -(torch.mean(expert_prob) - torch.mean(agent_prob))

            # 计算梯度惩罚（Wasserstein 梯度惩罚）
            # alpha = torch.rand(expert_states_user[index].size(0), 1, device=self.device)
            # interpolates_user = alpha * expert_states_user[index] + (1 - alpha) * agent_states_user[index]
            # interpolates_user.requires_grad_(True)
            # interpolates_graph_data_list = []
            # for state_id in range(interpolates_user.shape[0]):
            #     interpolates_edge_nodes_feature = agent_states_graph[state_id].clone().detach().to(torch.float).to(
            #         self.device)
            #     interpolates_edge_attr = agent_states_en_bw[state_id].clone().detach().to(torch.float).to(self.device)
            #     interpolates_en_graph_data = Data(x=interpolates_edge_nodes_feature, edge_index=edge_index_,
            #                                       edge_attr=interpolates_edge_attr)
            #     interpolates_en_graph_data = interpolates_en_graph_data.to(self.device)
            #     interpolates_graph_data_list.append(interpolates_en_graph_data)
            # interpolates_batch = Batch.from_data_list(interpolates_graph_data_list)
            # interpolates = [interpolates_batch, interpolates_user]
            # interpolates_prob = self.discriminator(interpolates, agent_actions)
            # gradients = autograd.grad(outputs=interpolates_prob, inputs=interpolates_user,
            #                           grad_outputs=torch.ones(interpolates_prob.size(), device=self.device),
            #                           create_graph=True, retain_graph=True, only_inputs=True)[0]
            # gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
            # self.discriminator_loss += 10 * gradient_penalty
            #
            # alpha = torch.rand(expert_states_user[index].size(0), 1, device=self.device)
            # expert_states_copy = [list(aa) for aa in expert_states]
            # agent_states_mini_batch_copy = [list(bb) for bb in agent_states_mini_batch]
            # interpolates = alpha * expert_states_copy + (1 - alpha) * agent_states_mini_batch_copy
            # interpolates.requires_grad_(True)
            # interpolates_prob = self.discriminator(interpolates, agent_actions)
            # gradients = autograd.grad(outputs=interpolates_prob, inputs=interpolates,
            #                           grad_outputs=torch.ones(interpolates_prob.size(), device=self.device),
            #                           create_graph=True, retain_graph=True, only_inputs=True)[0]
            # gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
            # self.discriminator_loss += 10 * gradient_penalty

            # self.discriminator_loss =  nn.BCELoss()(expert_prob, torch.zeros_like(expert_prob)) + nn.BCELoss()(agent_prob, torch.ones_like(agent_prob))

            self.discriminator_optimizer.zero_grad()
            self.discriminator_loss.backward()

            # torch.nn.utils.clip_grad_norm_(self.discriminator.parameters(), 1.0)  # 对梯度进行裁剪
            self.discriminator_optimizer.step()
            # 对判别器的权重进行裁剪（梯度裁剪）
            for p in self.discriminator.parameters():
                # p.data.clamp_(-0.005, 0.005)
                p.data.clamp_(-0.005, 0.005)


        # rewards = -torch.log(agent_prob).detach().cpu().numpy()
        # rewards = -agent_prob.clone().detach().cpu().numpy()
        rewards = -(expert_prob - agent_prob).clone().detach().cpu().numpy()
        # rewards = -agent_prob.clone().detach().cpu().numpy()
        print(f"智能体奖励{rewards}")
        # 将NumPy的打印选项设置为显示所有元素
        # np.set_printoptions(threshold=np.inf)
        # print(np.array(rewards))
        # breakpoint()
        # # 计算交叉熵损失
        # cross_entropy_loss = nn.CrossEntropyLoss(reduction='none')
        # rewards = -cross_entropy_loss(agent_prob.log(),
        #                              expert_prob.argmax(dim=1)).detach().cpu().numpy()
        replay_buffer.reward = rewards
        # self.agent.update(transition_dict)
        if count_special > 80:
            update_times2 = 2
        else:
            update_times2 = 1
        for _ in range(update_times2):
            self.agent.update(replay_buffer)
            self.disc_scheduler.step()
