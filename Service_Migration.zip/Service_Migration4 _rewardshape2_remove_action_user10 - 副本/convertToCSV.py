import csv

input_file = "user100.if"  # 输入的.if文件名
output_file = "User100_Trajectory.csv"  # 转换后的CSV文件名

with open(input_file, "r") as if_file:
    lines = if_file.readlines()

# 解析.if文件并保存为CSV格式
csv_data = []
line_num = 0
for line in lines:
    # 跳过前25行，前25行为无用数据
    if line_num < 104:
        line_num += 1
        continue
    # 使用空格作为分隔符，如果使用制表符分隔，可以将下面的split参数改为'\t'
    data = line.strip().split()
    csv_data.append(data)


# 将数据保存为CSV文件
with open(output_file, "w", newline="") as csv_file:
    writer = csv.writer(csv_file)
    writer.writerows(csv_data)

print("转换完成！")