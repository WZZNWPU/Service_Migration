import math

import numpy as np
from GS_test2 import GaleShapleyUser

from StableMatch import utils
from StableMatch.utils import generate_network_bandwidth
from dijkstra import dijkstra

user_file = '../user.csv'
en_file = '../en.csv'
num_file = '../num.csv'
traj_file = '../../Trajectory.csv'
# t=0时，先读取用户，EN的各类参数
np.random.seed(40)
gs = GaleShapleyUser(user_file, en_file, num_file, traj_file)

# 用一个列表存储所有用户的服务是否完成:t = 0时，默认所有都未完成
is_complete = [False for i in range(gs.u_num)]

time_slot = 100
match_num = 1  # 当前匹配次数
system_time = 0  # 记录当前的系统时间

'''
用户按泊松分布到达
'''
arrival_rate = 0.005  # 用户到达的平均频率
start_time = 200  # 区间的起始时间
end_time = 1000  # 区间的结束时间

interval_length = end_time - start_time  # 区间的长度

expected_arrivals = arrival_rate * interval_length  # 期望到达次数

arrivals = np.random.poisson(expected_arrivals)  # 生成到达次数
arrival_times = np.sort(np.random.uniform(start_time, end_time, arrivals))
arrival_index = 0
print(arrival_times)

# 当有用户的服务没有完成时，不断循环
while not all(is_complete):
    print(f'-----------------------------第{match_num}轮匹配------------------------------------------')
    gs.match()
    for i in range(gs.en_num):
        print(
            f'边缘服务器{i}当前托管的用户为：{[u.id for u in gs.EN_group[i].currentUsers]},当前占用资源{gs.EN_group[i].curConsumeResources}/{gs.EN_group[i].Capacity}')
    print()
    print('----------------------------------------------------------------------------------------')
    match_num += 1

    # TODO:更新系统时间
    system_time += time_slot

    # TODO:更新用户新的坐标
    for u in range(gs.u_num):
        gs.user_group[u].last_loc = gs.user_group[u].loc
        gs.user_group[u].loc = gs.user_group[u].traj[int(gs.user_group[u].t / time_slot) + 1]

    # TODO:网络产生随机波动
    gs.en_bw = generate_network_bandwidth(mean=80, std_dev=25, n=gs.valid_num)
    for en in range(gs.en_num):
        gs.EN_group[en].bw = float(generate_network_bandwidth(mean=80, std_dev=25, n=1)) * math.pow(10, 6)
    # print(gs.en_bw)

    '''
     # 判断当前系统时间是否有用户到达，有用户到达则添加到用户组
    '''
    # print(f"第{match_num}轮匹配")
    # print(f"系统时间{system_time}")
    # print(f'help{arrival_times[arrival_index] < system_time and arrival_index < arrival_times.size}')
    while arrival_times[arrival_index] < system_time and arrival_index < arrival_times.size:  # 表明新用户到达
        arrival_index, is_complete = utils.new_user_arrival(traj_file, arrival_index, gs, is_complete)

    # 假设每 timeslot 毫秒检查一次用户服务是否需要迁移
    gs.ap_set_for_u, gs.dist_set = gs.ap_set_for_user()
    gs.ap_for_user = gs.chooseAP()

    for u in range(gs.u_num):
        '''
        # 对于新到达的用户，其还没有托管其服务，先不需要迁移，先为其选择托管服务的边缘服务器
        '''
        if gs.user_group[u].cur_en == np.inf:
            gs.generate_user_favorite_list(gs.user_group[u].id)
            print('---------------------------------------------------------')
            continue
        '''
         # 对于不是新到达的用户，判断是否需要迁移
        '''
        print(f'-----------------------------用户{u}是否需要迁移------------------')
        # 更新2毫秒后用户还需要计算的数据大小，还有用户的位置
        # gs.user_group[u].last_loc = gs.user_group[u].loc
        gs.user_group[u].t += time_slot
        last_ds = gs.user_group[u].data_size
        print(f"原始数据大小：{gs.user_group[u].data_size}")
        print(f"用户当前接入的AP：{gs.user_group[u].cur_ap}")
        print(f"用户当前接入的EN：{gs.user_group[u].cur_en}")

        gs.user_group[u].last_dl_del = gs.user_group[u].cur_dl_del

        # 2毫秒服务器可以计算的服务数据的大小为
        # done_ds = gs.EN_group[gs.user_group[u].cur_en].comp_power * gs.user_group[u].cpu_circle * time_slot
        # print(gs.EN_group[gs.user_group[u].cur_en].comp_power)
        print(gs.user_group[u].cpu_circle * 8)
        if gs.user_group[u].cur_en != np.inf:
            done_ds = gs.user_group[u].cpu_circle / gs.EN_group[gs.user_group[u].cur_en].comp_power * 8
            print(f'done_ds -----> {done_ds}')
        # 如果用户剩余数据<一个时隙服务器可以计算的服务数据,则说明用户服务已经完成
        if gs.user_group[u].data_size <= done_ds:
            gs.user_group[u].done = True
            gs.user_group[u].data_size = 0
            is_complete[u] = True
            # continue
        else:
            gs.user_group[u].data_size -= done_ds
            print(f'剩余数据大小 -----> {gs.user_group[u].data_size}')
            # gs.user_group[u].last_com_del = gs.user_group[u].cur_com_del - gs.user_group[u].last_com_del + time_slot

            gs.user_group[u].last_com_del = gs.user_group[u].last_com_del + time_slot \
                if gs.user_group[u].estimated_remaining_time > time_slot else gs.user_group[u].last_com_del + \
                                                                              gs.user_group[
                                                                                  u].estimated_remaining_time

            gs.user_group[u].estimated_remaining_time = \
                (gs.user_group[u].estimated_remaining_time - time_slot) if gs.user_group[
                                                                               u].estimated_remaining_time > time_slot else 0

            # 如果t==0，用户不可能发生迁移
            if gs.user_group[u].t == 0:
                gs.user_group[u].last_mig_del = 0
            else:
                if gs.user_group[u].this_mig_time <= time_slot:
                    gs.user_group[u].refuse_mig = False
                    gs.user_group[u].this_mig_time = 0
                    gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del
                else:
                    gs.user_group[u].refuse_mig = True
                    gs.user_group[u].this_mig_time -= time_slot
                    gs.user_group[u].last_mig_del = gs.user_group[u].cur_mig_del

            # 更新用户新的坐标
            # gs.user_group[u].loc = np.random.uniform(low=1000, high=2500, size=2)
            # print(f'{gs.user_group[u].loc}' )
            # 主动迁移因子设置为0.9
            v = 0.9
            # 判断用户是否需要迁移
            print(f"上次位置：{gs.user_group[u].last_loc}")
            print(f"这次位置：{gs.user_group[u].loc}")
            print(f'类型-->{gs.user_group[u].class_for_del}')
            str1 = "软延迟" if gs.user_group[u].class_for_del == False else "硬延迟"
            print(f"用户{gs.user_group[u].id}服务类型：{str1}")
            if np.array_equal(gs.user_group[u].loc, gs.user_group[u].last_loc):  # 用户没有移动
                gs.user_group[u].favorNum = []  # 不需要迁移
                print(f"用户{gs.user_group[u].id}没有移动，不需要迁移")
            else:
                a2u_down_del = gs.user_group[u].res_size / (utils.tr_BU(B=gs.EN_group[gs.ap_for_user[u]].bw,
                                                                        h=gs.EN_group[gs.ap_for_user[u]].h,
                                                                        sigma=1.5 * math.pow(10, -11),
                                                                        p_b=gs.EN_group[gs.ap_for_user[u]].p,
                                                                        r=np.linalg.norm(ord=2, x=np.array(
                                                                            gs.EN_group[
                                                                                gs.ap_for_user[
                                                                                    u]].loc) - np.array(
                                                                            gs.user_group[u].loc))) / math.pow(10,
                                                                                                               3))

                down_TDM = utils.get_TDM(gs.en_num, gs.en_bw, gs.EN_group, gs.user_group[u].res_size)
                down_distance, down_path = dijkstra(down_TDM, gs.ap_for_user[u], gs.user_group[u].cur_en)

                gs.user_group[u].cur_dl_del = a2u_down_del + down_distance[gs.user_group[u].cur_en]
                print(gs.user_group[u].loc)

                # print(
                #     f'dist{np.linalg.norm(ord=2, x=np.array(gs.EN_group[gs.ap_for_user[u]].loc) - np.array(gs.user_group[u].loc))}')

                print(f'a2u_down_del-->{a2u_down_del}')
                print(f' gs.user_group[u].cur_dl_del-->{gs.user_group[u].cur_dl_del}')
                print(f' gs.user_group[u].last_dl_del-->{gs.user_group[u].last_dl_del}')

                # 如果总延迟超过了用户能接受的最大延迟，则发生迁移
                print(f'onload_del-->{gs.user_group[u].onload_del}')
                print(f'cur_com_del-->{gs.user_group[u].cur_com_del}')
                print(f'cur_mig_del-->{gs.user_group[u].cur_mig_del}')
                print(f'cur_dl_del-->{gs.user_group[u].cur_dl_del}')

                delay = gs.user_group[u].onload_del + gs.user_group[u].cur_com_del + gs.user_group[u].cur_mig_del + \
                        gs.user_group[u].cur_dl_del
                print(
                    f'delay{delay}-->max{gs.user_group[u].max_serv_del},stat{gs.user_group[u].satisfied_serv_del}')
                print()

                '''
                # 分情况讨论：
                # 1.如果用户服务是软服务且服务执行程度超过50%,且在软服务最大延迟接收范围内，则可以不迁移
                # 2.如果用户服务是硬服务，则一旦超越满意延迟范围，则必须迁移
                '''
                if gs.user_group[u].class_for_del == 0 and \
                        (gs.user_group[u].init_data_size - gs.user_group[u].data_size) / gs.user_group[
                    u].init_data_size >= 0.5 \
                        and delay <= gs.user_group[u].max_serv_del:
                    print(f'软延迟服务，执行程度超过50%，不需要迁移')
                    continue
                elif gs.user_group[u].class_for_del == 0 and delay <= gs.user_group[u].satisfied_serv_del:
                    print(f'软延迟服务，未超过最优服务体验范围，不需要迁移')
                    continue
                elif gs.user_group[u].class_for_del == 1 and delay <= gs.user_group[u].satisfied_serv_del:
                    print(f'硬延迟服务，未超过延迟范围，不需要迁移')
                    continue
                else:
                    # if delay > gs.user_group[u].max_serv_del:
                    print(f'{gs.user_group[u].id}-->发生迁移')
                    '''
                        # 修改用户和托管其服务的原服务器的状态
                    '''
                    utils.modify_state(gs, u)

                    '''
                        重新计算用户的偏好列表
                    '''
                    gs.generate_user_favor_list_ignore_onload_latency(u,time_slot)

        print(f"用户{gs.user_group[u].id}剩余数据大小：{last_ds}--->{gs.user_group[u].data_size}")

    print(is_complete)
    print('------------------------------------------------------------------------------------------')

    gs.insert_user_favor()
    # break

total_del_list = []

for u in range(gs.u_num):
    total_del_list.append(gs.user_group[u].total_del)
print(np.array(total_del_list))
print(np.mean(np.array(total_del_list)))